<%@ page import="com.mycompany.model.User" %>
<%@ page import="com.mycompany.model.Resident" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.mycompany.controller.DBConnect" %>
<%@ page import="com.mycompany.controller.resident.MyComplaintController" %>
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Complaints | Apartment Chempaka</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Navigation */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
            line-height: 1;
            overflow: hidden;
        }

        .user-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .user-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Complaints Container */
        .complaints-container {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-header h2 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-header h2 i {
            color: var(--primary);
        }

        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--gray);
        }

        .filter-select {
            padding: 10px 15px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            background: white;
            color: var(--dark);
            font-size: 0.95rem;
            transition: all 0.3s ease;
            min-width: 180px;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        /* Complaints Table */
        .complaints-table-container {
            overflow-x: auto;
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .complaints-table thead {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
        }

        .complaints-table th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: white;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .complaints-table th i {
            margin-right: 8px;
        }

        .complaints-table tbody tr {
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .complaints-table tbody tr:hover {
            background-color: #f9f9ff;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .complaints-table td {
            padding: 20px;
            color: var(--dark);
        }

        .complaint-title {
            font-weight: 600;
            font-size: 1.05rem;
            color: var(--dark);
        }

        .complaint-description {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .category-badge {
            display: inline-block;
            padding: 6px 12px;
            background: #e8f6f3;
            color: #00b894;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
            text-transform: capitalize;
        }

        .status-pending {
            background-color: #fff4e6;
            color: #f39c12;
        }

        .status-in_progress {
            background-color: #e3f2fd;
            color: #0984e3;
        }

        .status-resolved {
            background-color: #e8f6f3;
            color: #00b894;
        }

        .status-rejected {
            background-color: #ffeaea;
            color: #d63031;
        }

        .date-cell {
            color: var(--gray);
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .assigned-staff {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--gray);
            font-size: 0.9rem;
        }

        .staff-avatar {
            width: 30px;
            height: 30px;
            background: var(--light-gray);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark);
            font-size: 0.8rem;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .action-btn {
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .view-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
        }

        .view-btn:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .update-btn {
            background: #fff4e6;
            color: #f39c12;
        }

        .update-btn:hover {
            background: #fdebd0;
            transform: translateY(-2px);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
            color: var(--primary-light);
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 30px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        .action-links {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 30px;
        }

        .primary-action {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            padding: 15px 30px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .primary-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .secondary-action {
            background: white;
            color: var(--primary);
            padding: 15px 30px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            border: 2px solid var(--primary-light);
        }

        .secondary-action:hover {
            background: #f0eeff;
            transform: translateY(-3px);
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .sidebar-header, .user-info, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .filter-section {
                flex-direction: column;
            }
            
            .filter-select {
                min-width: 100%;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .complaints-container {
                padding: 20px;
            }
            
            .action-links {
                flex-direction: column;
                align-items: center;
            }
            
            .primary-action, .secondary-action {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .complaints-table th, 
            .complaints-table td {
                padding: 15px 10px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 8px;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar Navigation -->
<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-building-circle-check"></i>
            <div class="logo-text">
                <h2>Chempaka</h2>
                <p>Resident Portal</p>
            </div>
        </div>
        
        <div class="user-profile">
            <div class="user-avatar">
                ${residentName != null && !residentName.isEmpty() ? residentName.charAt(0) : username.charAt(0)}
            </div>
            <div class="user-info">
                <h4>${residentName != null ? residentName : username}</h4>
                <p>Resident</p>
            </div>
        </div>
    </div>
    
    <ul class="nav-menu">
        <li class="nav-item">
            <a href="<%= request.getContextPath() %>/dashboard" class="nav-link">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<%= request.getContextPath() %>/resident/submitComplaint" class="nav-link">
                <i class="fas fa-plus-circle"></i>
                <span>New Complaint</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<%= request.getContextPath() %>/resident/myComplaint" class="nav-link active">
                <i class="fas fa-list-alt"></i>
                <span>My Complaints</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="<%= request.getContextPath() %>/profile" class="nav-link">
                <i class="fas fa-user-cog"></i>
                <span>Profile</span>
            </a>
        </li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="page-title">
            <h1>My Complaints</h1>
            <p>View and manage all your submitted complaints</p>
        </div>
        
        <button class="logout-btn" onclick="window.location.href='<%= request.getContextPath() %>/logout'">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </div>

    <!-- Complaints Container -->
    <div class="complaints-container">
        <div class="section-header">
            <h2><i class="fas fa-clipboard-list"></i> All Complaints</h2>
        </div>

        <!-- Filter Section (REMOVED SORT BY DATE) -->
        <div class="filter-section">
            <div class="filter-group">
                <label class="filter-label">Filter by Status</label>
                <select class="filter-select" id="statusFilter">
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label class="filter-label">Filter by Category</label>
                <select class="filter-select" id="categoryFilter">
                    <option value="all">All Categories</option>
                    <option value="Plumbing">Plumbing</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Cleanliness">Cleanliness</option>
                    <option value="Security">Security</option>
                    <option value="Others">Others</option>
                </select>
            </div>
        </div>

        <c:choose>
            <c:when test="${not empty complaints}">
                <!-- Complaints Table -->
                <div class="complaints-table-container">
                    <table class="complaints-table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-heading"></i> Title & Description</th>
                                <th><i class="fas fa-tag"></i> Category</th>
                                <th><i class="fas fa-info-circle"></i> Status</th>
                                <th><i class="fas fa-calendar"></i> Date Submitted</th>
                                <th><i class="fas fa-tools"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="complaint" items="${complaints}">
                                <tr>
                                    <td>
                                        <div class="complaint-title">${complaint.title}</div>
                                        <div class="complaint-description">
                                            ${complaint.description != null ? complaint.description : 'No description provided'}
                                        </div>
                                    </td>
                                    <td>
                                        <span class="category-badge">${complaint.category_name}</span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-${complaint.status}">
                                            ${complaint.status.replace("_", " ")}
                                        </span>
                                    </td>
                                    <td class="date-cell">
                                        <fmt:formatDate value="${complaint.created_at}" pattern="dd MMM yyyy" />
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}" 
                                               class="action-btn view-btn">
                                               <i class="fas fa-eye"></i> View Details
                                            </a>                                            
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </c:when>
            <c:otherwise>
                <!-- Empty State -->
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No Complaints Yet</h3>
                    <p>You haven't submitted any complaints yet. Submit your first complaint to get started!</p>
                    
                    <div class="action-links">
                        <a href="<%= request.getContextPath() %>/resident/submitComplaint" class="primary-action">
                            <i class="fas fa-plus-circle"></i> Submit New Complaint
                        </a>
                        <a href="<%= request.getContextPath() %>/resident/dashboard" class="secondary-action">
                            <i class="fas fa-tachometer-alt"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <!-- Bottom Action Links (Only show if there are complaints) -->
    <c:if test="${not empty complaints}">
        <div class="action-links" style="justify-content: center; margin-top: 30px;">
            <a href="<%= request.getContextPath() %>/resident/submitComplaint" class="primary-action">
                <i class="fas fa-plus-circle"></i> Submit New Complaint
            </a>
        </div>
    </c:if>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Filter functionality (SIMPLIFIED - NO SORTING)
        const statusFilter = document.getElementById('statusFilter');
        const categoryFilter = document.getElementById('categoryFilter');
        const tableRows = document.querySelectorAll('.complaints-table tbody tr');
        
        function filterComplaints() {
            const statusValue = statusFilter.value;
            const categoryValue = categoryFilter.value;
            
            // Filter rows
            tableRows.forEach(row => {
                const status = row.querySelector('.status-badge').classList[1].replace('status-', '');
                const category = row.querySelector('.category-badge').textContent.trim();
                
                let showRow = true;
                
                // Status filter
                if (statusValue !== 'all' && status !== statusValue) {
                    showRow = false;
                }
                
                // Category filter
                if (categoryValue !== 'all' && category !== categoryValue) {
                    showRow = false;
                }
                
                if (showRow) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Add event listeners to filters
        statusFilter.addEventListener('change', filterComplaints);
        categoryFilter.addEventListener('change', filterComplaints);
        
        // Add hover effects to table rows
        tableRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.transition = 'all 0.3s ease';
            });
        });
        
        // Format dates on load
        document.querySelectorAll('.date-cell script').forEach(script => {
            const dateText = script.textContent;
            const date = new Date(dateText);
            const formattedDate = date.toLocaleDateString('en-MY', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            script.parentElement.textContent = formattedDate;
        });
    });
</script>

</body>
</html>