<%@ page import="com.mycompany.model.User" %>
<%@ page import="com.mycompany.model.Resident" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.mycompany.controller.DBConnect" %>
<%@ page import="java.util.*" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Complaint | Apartment Chempaka</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Navigation */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
            line-height: 1; /* prevents text stretching */
            overflow: hidden;
        }

        .user-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .user-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Complaint Form Container */
        .form-container {
            background: white;
            border-radius: var(--card-radius);
            padding: 40px;
            box-shadow: var(--shadow);
            max-width: 800px;
            margin: 0 auto;
        }

        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .form-header i {
            font-size: 3rem;
            color: var(--primary-light);
            margin-bottom: 20px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .form-header h2 {
            font-size: 1.8rem;
            color: var(--dark);
            margin-bottom: 10px;
        }

        .form-header p {
            color: var(--gray);
            font-size: 1.1rem;
        }

        /* Form Elements */
        .form-row {
            display: flex;
            gap: 30px;
            margin-bottom: 25px;
        }

        .form-group {
            flex: 1;
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--dark);
            font-size: 1rem;
        }

        .form-label .required {
            color: #e74c3c;
            margin-left: 4px;
        }

        .form-input, .form-textarea, .form-select {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: white;
        }

        .form-input:focus, .form-textarea:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(108, 92, 231, 0.1);
        }

        .form-input[readonly] {
            background-color: #f8f9fa;
            color: var(--gray);
            cursor: not-allowed;
        }

        .form-textarea {
            min-height: 150px;
            resize: vertical;
            font-family: inherit;
        }

        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236c5ce7' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 20px center;
            background-size: 15px;
            padding-right: 50px;
        }

        /* Category Cards */
        .category-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }

        .category-card {
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .category-card:hover {
            border-color: var(--primary-light);
            background-color: #f9f9ff;
            transform: translateY(-3px);
        }

        .category-card.selected {
            border-color: var(--primary);
            background-color: #f0eeff;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.1);
        }

        .category-card input[type="radio"] {
            position: absolute;
            opacity: 0;
        }

        .category-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .category-name {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 8px;
            font-size: 1.1rem;
        }

        .category-desc {
            color: var(--gray);
            font-size: 0.9rem;
            line-height: 1.5;
        }

        /* File Upload */
        .file-upload-container {
            border: 2px dashed var(--light-gray);
            border-radius: 12px;
            padding: 40px 20px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            margin-top: 10px;
        }

        .file-upload-container:hover {
            border-color: var(--primary);
            background-color: #f9f9ff;
        }

        .file-upload-container.dragover {
            border-color: var(--primary);
            background-color: #f0eeff;
            transform: scale(1.02);
        }

        .file-upload-icon {
            font-size: 3rem;
            color: var(--primary-light);
            margin-bottom: 15px;
        }

        .file-upload-text h4 {
            color: var(--dark);
            margin-bottom: 10px;
        }

        .file-upload-text p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-bottom: 15px;
        }

        .file-input {
            display: none;
        }

        .file-info {
            margin-top: 15px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            display: none;
        }

        .file-info.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        .file-preview {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
            margin-top: 10px;
            display: none;
        }

        .file-preview.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Form Actions */
        .form-actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 1px solid var(--light-gray);
        }

        .submit-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            border: none;
            padding: 18px 40px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .submit-btn:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .cancel-btn {
            background: white;
            color: var(--dark);
            border: 2px solid var(--light-gray);
            padding: 18px 40px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .cancel-btn:hover {
            background: #f8f9fa;
            border-color: var(--primary-light);
            transform: translateY(-3px);
        }

        /* Status Messages */
        .status-message {
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            text-align: center;
            animation: slideIn 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #f5c6cb;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .sidebar-header, .user-info, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .form-container {
                padding: 30px 20px;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .form-header h2 {
                font-size: 1.5rem;
            }
            
            .category-cards {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .submit-btn, .cancel-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<!-- Sidebar Navigation -->
<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-building-circle-check"></i>
            <div class="logo-text">
                <h2>Chempaka</h2>
                <p>Resident Portal</p>
            </div>
        </div>
        
        <div class="user-profile">
            <div class="user-avatar">
                ${resident.name != null && !resident.name.isEmpty() ? resident.name.charAt(0) : resident.user.username.charAt(0)}
            </div>
            <div class="user-info">
                <h4>${resident.name}</h4>
                <p>Resident</p>
            </div>
        </div>
    </div>
    
    <ul class="nav-menu">
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/dashboard" class="nav-link">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/resident/submitComplaint" class="nav-link active">
                <i class="fas fa-plus-circle"></i>
                <span>New Complaint</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/resident/myComplaint" class="nav-link">
                <i class="fas fa-list-alt"></i>
                <span>My Complaints</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/profile" class="nav-link">
                <i class="fas fa-user-cog"></i>
                <span>Profile</span>
            </a>
        </li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="page-title">
            <h1>Submit Complaint</h1>
            <p>Report an issue or request maintenance for your unit</p>
        </div>
        
        <button class="logout-btn" onclick="window.location.href='${pageContext.request.contextPath}/logout'">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </div>

    <!-- Status Messages -->
    <c:if test="${param.status == 'success'}">
        <div class="status-message success-message">
            <i class="fas fa-check-circle"></i>
            <div>
                <h3>Complaint Submitted Successfully!</h3>
                <p>Your complaint has been submitted and is now pending review.</p>
            </div>
        </div>
    </c:if>

    <c:if test="${param.status == 'error'}">
        <div class="status-message error-message">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                <h3>Submission Failed</h3>
                <p>
                    <c:choose>
                        <c:when test="${not empty param.message}">
                            ${param.message}
                        </c:when>
                        <c:otherwise>
                            Please try again or contact support.
                        </c:otherwise>
                    </c:choose>
                </p>
            </div>
        </div>
    </c:if>


    <!-- Complaint Form -->
    <div class="form-container">
        <div class="form-header">
            <i class="fas fa-exclamation-triangle"></i>
            <h2>Report an Issue</h2>
            <p>Fill in the details below to submit your complaint</p>
        </div>

        <form action="${pageContext.request.contextPath}/resident/submitComplaint" method="post" enctype="multipart/form-data" id="complaintForm">
            <input type="hidden" name="resident_id" value="${resident.resident_id}"/>
            <input type="hidden" name="unit_id" value="${resident.unit.unit_id}"/>
            
            <!-- Resident Info -->
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Resident Name</label>
                    <input type="text" class="form-input" value="${resident.name}" readonly>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Your Unit</label>
                    <input type="text" class="form-input" value="Block ${resident.unit.block} | Floor ${resident.unit.floor} | Unit ${resident.unit.unit_number} (Auto-detected)" readonly>
                    <small style="color: var(--gray); font-size: 0.9rem; margin-top: 5px; display: block;">
                        <i class="fas fa-info-circle"></i> Your unit is automatically detected from your profile
                    </small>
                </div>
            </div>

            <!-- Complaint Category -->
            <div class="form-group">
                <label class="form-label">Select Category <span class="required">*</span></label>
                <div class="category-cards" id="categoryCards">
                    <c:forEach var="category" items="${categories}" varStatus="status">
                        <label class="category-card" for="category-${category.category_id}">
                            <!-- Radio Button -->
                            <input type="radio" id="category-${category.category_id}" name="category_id"
                                   value="${category.category_id}" class="category-radio" required>

                            <!-- Icon -->
                            <div class="category-icon">
                                <i class="fas
                                    <c:choose>
                                        <c:when test="${status.index % 5 == 0}"> fa-broom</c:when>
                                        <c:when test="${status.index % 5 == 1}"> fa-bolt</c:when>
                                        <c:when test="${status.index % 5 == 2}"> fa-question-circle</c:when>
                                        <c:when test="${status.index % 5 == 3}"> fa-faucet-drip</c:when>
                                        <c:otherwise> fa-shield-alt</c:otherwise>
                                    </c:choose>"></i>
                            </div>

                            <!-- Category Name -->
                            <div class="category-name">${category.category_name}</div>

                            <!-- Category Description -->
                            <div class="category-desc">
                                <c:out value="${category.description != null ? category.description : 'General issue category'}"/>
                            </div>
                        </label>
                    </c:forEach>
                </div>
            </div>




            <!-- Complaint Title -->
            <div class="form-group">
                <label class="form-label">Complaint Title <span class="required">*</span></label>
                <input type="text" class="form-input" name="title" placeholder="Brief summary of the issue" required>
            </div>

            <!-- Complaint Description -->
            <div class="form-group">
                <label class="form-label">Detailed Description <span class="required">*</span></label>
                <textarea class="form-textarea" name="description" placeholder="Please provide detailed information about the issue..." required></textarea>
            </div>

            <!-- File Upload -->
            <div class="form-group">
                <label class="form-label">Attach Image (Optional)</label>
                <div class="file-upload-container" id="fileUploadContainer">
                    <div class="file-upload-icon">
                        <i class="fas fa-cloud-upload-alt"></i>
                    </div>
                    <div class="file-upload-text">
                        <h4>Upload an Image</h4>
                        <p>Drag & drop or click to browse</p>
                        <p style="font-size: 0.8rem; color: var(--gray);">Supports JPG, PNG up to 5MB</p>
                    </div>
                    <input type="file" class="file-input" name="image" id="imageInput" accept="image/*">
                </div>
                <div class="file-info" id="fileInfo">
                    <strong>Selected file:</strong> <span id="fileName"></span> (<span id="fileSize"></span>)
                </div>
                <img class="file-preview" id="filePreview" alt="Preview">
            </div>

            <!-- Form Actions -->
            <div class="form-actions">
                <button type="submit" class="submit-btn">
                    <i class="fas fa-paper-plane"></i> Submit Complaint
                </button>
                <a href="${pageContext.request.contextPath}/dashboard" class="cancel-btn">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Category card selection
        const categoryCards = document.querySelectorAll('.category-card');
        const categoryRadios = document.querySelectorAll('.category-radio');
        
        categoryCards.forEach(card => {
            card.addEventListener('click', function() {
                // Remove selected class from all cards
                categoryCards.forEach(c => c.classList.remove('selected'));
                // Add selected class to clicked card
                this.classList.add('selected');
                // Check the radio button inside
                const radio = this.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                }
            });
        });
        
        // Update card selection when radio changes
        categoryRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                categoryCards.forEach(card => {
                    card.classList.remove('selected');
                    const cardRadio = card.querySelector('input[type="radio"]');
                    if (cardRadio && cardRadio.checked) {
                        card.classList.add('selected');
                    }
                });
            });
        });

        // File upload handling
        const fileUploadContainer = document.getElementById('fileUploadContainer');
        const imageInput = document.getElementById('imageInput');
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const filePreview = document.getElementById('filePreview');

        fileUploadContainer.addEventListener('click', () => imageInput.click());

        imageInput.addEventListener('change', function(e) {
            if (this.files.length > 0) {
                const file = this.files[0];
                
                // Check file size (5MB limit)
                const maxSize = 5 * 1024 * 1024; // 5MB in bytes
                if (file.size > maxSize) {
                    alert('File size exceeds 5MB limit. Please choose a smaller file.');
                    this.value = ''; // Clear the input
                    return;
                }
                
                // Check file type
                const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!validTypes.includes(file.type)) {
                    alert('Please select a valid image file (JPG, PNG, GIF).');
                    this.value = '';
                    return;
                }
                
                // Update file info
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                fileInfo.classList.add('active');
                
                // Show preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    filePreview.src = e.target.result;
                    filePreview.classList.add('active');
                }
                reader.readAsDataURL(file);
            }
        });

        // Drag and drop functionality
        fileUploadContainer.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });

        fileUploadContainer.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
        });

        fileUploadContainer.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            
            if (e.dataTransfer.files.length > 0) {
                imageInput.files = e.dataTransfer.files;
                imageInput.dispatchEvent(new Event('change'));
            }
        });

        // Form submission validation
        const form = document.getElementById('complaintForm');
        form.addEventListener('submit', function(e) {
            const title = this.querySelector('input[name="title"]').value.trim();
            const description = this.querySelector('textarea[name="description"]').value.trim();
            const category = this.querySelector('input[name="category_id"]:checked');
            
            if (!category) {
                e.preventDefault();
                alert('Please select a category for your complaint.');
                return;
            }
            
            if (title.length < 5) {
                e.preventDefault();
                alert('Please enter a more descriptive title (at least 5 characters).');
                return;
            }
            
            if (description.length < 10) {
                e.preventDefault();
                alert('Please provide a more detailed description (at least 10 characters).');
                return;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('.submit-btn');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            submitBtn.disabled = true;
        });

        // Helper function to format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Auto-clear success message after 5 seconds
        const successMessage = document.querySelector('.success-message');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.opacity = '0';
                successMessage.style.transform = 'translateY(-10px)';
                successMessage.style.transition = 'all 0.5s ease';
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 500);
            }, 5000);
        }
    });
</script>

</body>
</html>