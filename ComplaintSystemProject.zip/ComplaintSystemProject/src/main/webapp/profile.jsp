<%@ page import="java.sql.*" %>
<%@ page import="com.mycompany.controller.DBConnect" %>
<%@ page import="com.mycompany.model.User" %>
<%@ page import="com.mycompany.model.Resident" %>
<%@ page import="com.mycompany.model.Staff" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Apartment Chempaka</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Navigation */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
            line-height: 1;
            overflow: hidden;
        }

        .user-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .user-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Profile Container */
        .profile-container {
            max-width: 800px;
            margin: 0 auto;
        }

        /* Status Messages */
        .status-message {
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            text-align: center;
            animation: slideIn 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #f5c6cb;
        }

        /* Profile Header */
        .profile-header {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: var(--card-radius) var(--card-radius) 0 0;
            padding: 40px;
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .profile-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            flex-shrink: 0;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 3rem;
            line-height: 1;
            color: white;
            border: 4px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(10px);
            overflow: hidden;
        }

        .profile-header h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .profile-role {
            display: inline-block;
            padding: 6px 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            text-transform: capitalize;
            backdrop-filter: blur(5px);
            margin-top: 10px;
        }

        /* Profile Info Cards */
        .profile-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .info-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
        }

        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .info-card-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .info-card-header i {
            font-size: 1.5rem;
            color: var(--primary);
            width: 50px;
            height: 50px;
            background: #f0eeff;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .info-card-header h3 {
            font-size: 1.3rem;
            color: var(--dark);
            font-weight: 600;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }

        .info-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .info-label {
            font-weight: 600;
            color: var(--gray);
            font-size: 0.95rem;
            min-width: 120px;
        }

        .info-value {
            flex: 1;
            text-align: right;
            color: var(--dark);
            font-size: 1rem;
            word-break: break-word;
        }

        .badge {
            display: inline-block;
            padding: 6px 12px;
            background: #e8f6f3;
            color: #00b894;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
        }

        .edit-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            border: none;
            padding: 15px 35px;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .edit-btn:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .back-btn {
            background: white;
            color: var(--dark);
            border: 2px solid var(--light-gray);
            padding: 15px 35px;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .back-btn:hover {
            background: #f8f9fa;
            border-color: var(--primary-light);
            transform: translateY(-3px);
        }

        /* ==================== */
        /* MODAL STYLES WITH SCROLLBAR */
        /* ==================== */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(3px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: var(--card-radius);
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            animation: slideUp 0.4s ease;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }

        @keyframes slideUp {
            from { transform: translateY(50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 25px 30px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            border-radius: var(--card-radius) var(--card-radius) 0 0;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 1.6rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header .close {
            font-size: 1.8rem;
            cursor: pointer;
            color: white;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
            font-weight: 300;
        }

        .modal-header .close:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(90deg);
        }

        .modal-scrollable {
            flex: 1;
            overflow-y: auto;
            padding: 0 30px;
            max-height: calc(90vh - 120px);
        }

        /* Custom scrollbar for modal */
        .modal-scrollable::-webkit-scrollbar {
            width: 6px;
        }

        .modal-scrollable::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .modal-scrollable::-webkit-scrollbar-thumb {
            background: var(--primary-light);
            border-radius: 3px;
        }

        .modal-scrollable::-webkit-scrollbar-thumb:hover {
            background: var(--primary);
        }

        /* Form Sections */
        .form-section {
            margin: 25px 0;
            padding: 20px;
            background: #f8f9ff;
            border-radius: 12px;
            border-left: 4px solid var(--primary);
        }

        .form-section h4 {
            color: var(--primary);
            margin: 0 0 20px 0;
            font-size: 1.1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-section:first-child {
            margin-top: 30px;
        }

        .form-section:last-child {
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
            font-size: 0.95rem;
        }

        .form-label .required {
            color: #ff4757;
        }

        .form-input, .form-select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: white;
        }

        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236c5ce7' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 15px;
            padding-right: 45px;
        }

        .password-note {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .password-note i {
            color: var(--primary);
        }

        .modal-actions {
            display: flex;
            gap: 15px;
            padding: 25px 0 30px 0;
            border-top: 1px solid #eee;
            margin-top: 20px;
            position: sticky;
            bottom: 0;
            background: white;
        }

        .update-btn, .cancel-btn {
            flex: 1;
            padding: 14px 20px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: none;
        }

        .update-btn {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
        }

        .update-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .cancel-btn {
            background: #f1f3f9;
            color: #666;
            border: 2px solid #e0e0e0;
        }

        .cancel-btn:hover {
            background: #e4e8f7;
            color: #333;
        }

        /* Form loading state */
        .form-loading {
            opacity: 0.7;
            pointer-events: none;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .sidebar-header, .user-info, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .profile-info-grid {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .edit-btn, .back-btn {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .profile-header {
                padding: 30px 20px;
            }
            
            .profile-avatar {
                width: 100px;
                height: 100px;
                font-size: 2.5rem;
            }
            
            .modal-content {
                max-width: 95%;
                margin: 0;
            }
            
            .modal-header {
                padding: 20px;
            }
            
            .modal-scrollable {
                padding: 0 20px;
            }
            
            .form-section {
                padding: 15px;
            }
            
            .modal-actions {
                flex-direction: column;
                gap: 10px;
            }
            
            .update-btn, .cancel-btn {
                width: 100%;
            }
            
            /* For very long forms on small screens */
            .modal-scrollable {
                max-height: 70vh;
            }
        }

        @media (max-width: 576px) {
            .info-item {
                flex-direction: column;
                gap: 8px;
            }
            
            .info-label, .info-value {
                text-align: left;
                width: 100%;
            }
            
            .profile-header h2 {
                font-size: 1.5rem;
            }
            
            .modal-content {
                max-height: 85vh;
            }
        }
    </style>
</head>
<body>



<!-- Sidebar Navigation -->
<div class="sidebar">
    <div class="sidebar-header">
         <div class="logo">
                <i class="fas fa-building-circle-check"></i>
                <div class="logo-text">
                    <h2>Chempaka</h2>
                    <p><c:choose>
                        <c:when test="${user.role == 'resident'}">Resident Portal</c:when>
                        <c:otherwise>Staff Portal</c:otherwise>
                   </c:choose>
                    </p>
                </div>
            </div>

        <div class="user-profile">
            <div class="user-avatar">
                <c:choose>
                    <c:when test="${profile != null}">${profile.name.substring(0,1)}</c:when>
                    <c:otherwise>${user.username.substring(0,1)}</c:otherwise>
                </c:choose>
            </div>
            <div class="user-info">
                <h4><c:choose>
                    <c:when test="${profile != null}">${profile.name}</c:when>
                    <c:otherwise>${user.username}</c:otherwise>
                </c:choose></h4>
                <p>${user.role.substring(0,1).toUpperCase()}${user.role.substring(1)}</p>
            </div>
        </div>
    </div>

    <ul class="nav-menu">
        <c:choose>
            <c:when test="${user.role == 'resident'}">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/dashboard" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/resident/submitComplaint" class="nav-link"><i class="fas fa-plus-circle"></i> New Complaint</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/resident/myComplaint" class="nav-link"><i class="fas fa-list-alt"></i> My Complaints</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/profile" class="nav-link active"><i class="fas fa-user-cog"></i> Profile</a></li>
            </c:when>
            <c:otherwise>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/dashboard" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/staff/staff-complaints" class="nav-link"><i class="fas fa-clipboard-list"></i> Assigned Complaints</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/profile" class="nav-link active"><i class="fas fa-user-cog"></i> Profile</a></li>
            </c:otherwise>
        </c:choose>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="page-title">
            <h1>My Profile</h1>
            <p>View and manage your account information</p>
        </div>
        <button class="logout-btn" onclick="window.location.href='${pageContext.request.contextPath}/logout'"><i class="fas fa-sign-out-alt"></i> Logout</button>
    </div>

    <!-- Status Messages -->
    <c:if test="${success == '1'}">
        <div class="status-message success-message">
            <i class="fas fa-check-circle"></i>
            <div>
                <h3>Profile Updated Successfully!</h3>
            </div>
        </div>
    </c:if>
    <c:if test="${error == '1'}">
        <div class="status-message error-message">
            <i class="fas fa-exclamation-circle"></i>
            <div>
                <h3>Update Failed</h3>
            </div>
        </div>
    </c:if>

    <!-- Profile Container -->
    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <c:choose>
                    <c:when test="${profile != null}">${profile.name.substring(0,1)}</c:when>
                    <c:otherwise>${user.username.substring(0,1)}</c:otherwise>
                </c:choose>
            </div>
            <h2><c:choose>
                    <c:when test="${profile != null}">${profile.name}</c:when>
                    <c:otherwise>${user.username}</c:otherwise>
                </c:choose></h2>
            <div class="profile-role">${user.role.substring(0,1).toUpperCase()}${user.role.substring(1)}</div>
        </div>

        <!-- Profile Info Grid -->
        <div class="profile-info-grid">
            <!-- Account Info -->
            <div class="info-card">
                <div class="info-card-header"><h3>Account Information</h3></div>
                <div class="info-item">Username: ${user.username}</div>
                <div class="info-item">Role: ${user.role.substring(0,1).toUpperCase()}${user.role.substring(1)}</div>
            </div>

            <!-- Personal Info -->
            <div class="info-card">
                <div class="info-card-header"><h3>Personal Information</h3></div>

                <c:choose>
                    <c:when test="${user.role == 'resident'}">
                        <div class="info-item">Name: ${profile.name}</div>
                        <div class="info-item">Email: ${profile.email}</div>
                        <div class="info-item">Phone: ${profile.phone}</div>
                        <div class="info-item">
                            Unit: Block ${profile.unit.block} - Floor ${profile.unit.floor} - ${profile.unit.unit_number}
                        </div>
                    </c:when>
                    <c:when test="${user.role == 'staff'}">
                        <div class="info-item">Name: ${profile.name}</div>
                        <div class="info-item">Phone: ${profile.phone}</div>
                        <div class="info-item">Position: ${profile.role.role_name}</div>
                        <div class="info-item">
                            Department: <c:out value="${profile.category != null ? profile.category.category_name : ''}" />
                        </div>
                    </c:when>
                </c:choose>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <button class="edit-btn" id="editBtn"><i class="fas fa-edit"></i> Edit Profile</button>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-edit"></i> Edit Profile</h3>
                <span class="close" id="closeModal">&times;</span>
            </div>

            <form action="${pageContext.request.contextPath}/updateProfile" method="post" id="profileForm">
                <input type="hidden" name="user_id" value="${user.user_id}"/>
                <input type="hidden" name="role" value="${user.role}"/>

                <!-- Account Info -->
                <div class="form-section">
                    <h4>Account Information</h4>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" value="${user.username}" required/>
                    </div>
                    <div class="form-group">
                        <label>Password (Optional)</label>
                        <input type="password" name="password" placeholder="Leave blank to keep current"/>
                    </div>
                </div>

                <!-- Personal Info -->
                <c:choose>
                    <c:when test="${user.role == 'resident'}">
                        <div class="form-section">
                            <h4>Resident Info</h4>
                            <div class="form-group"><label>Name</label><input type="text" name="name" value="${profile.name}" required/></div>
                            <div class="form-group"><label>Email</label><input type="email" name="email" value="${profile.email}" required/></div>
                            <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="${profile.phone}" required/></div>
                            <div class="form-group">
                                <label>Apartment Unit</label>
                                <select name="unit_id" required>
                                    <c:forEach var="unit" items="${units}">
                                        <option value="${unit.unit_id}" 
                                            <c:if test="${profile.unit.unit_id == unit.unit_id}">selected</c:if>>
                                            Block ${unit.block} - Floor ${unit.floor} - ${unit.unit_number}
                                        </option>
                                    </c:forEach>
                                </select>
                            </div>
                        </div>
                    </c:when>
                    <c:when test="${user.role == 'staff'}">
                        <div class="form-section">
                            <h4>Staff Info</h4>
                            <div class="form-group"><label>Name</label><input type="text" name="name" value="${profile.name}" required/></div>
                            <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="${profile.phone}" required/></div>
                            <div class="form-group">
                                <label>Role</label>
                                <select name="role_id" required>
                                    <c:forEach var="r" items="${roles}">
                                        <option value="${r.role_id}" 
                                            <c:if test="${profile.role.role_id == r.role_id}">selected</c:if>>
                                            ${r.role_name}
                                        </option>
                                    </c:forEach>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Department</label>
                                <select name="category_id" required>
                                    <c:forEach var="c" items="${categories}">
                                        <option value="${c.category_id}" 
                                            <c:if test="${profile.category.category_id == c.category_id}">selected</c:if>>
                                            ${c.category_name}
                                        </option>
                                    </c:forEach>
                                </select>
                            </div>
                        </div>
                    </c:when>
                </c:choose>

                <div class="modal-actions">
                    <button type="submit">Update Profile</button>
                    <button type="button" id="cancelEdit">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal JS -->
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const editBtn = document.getElementById('editBtn');
        const editModal = document.getElementById('editModal');
        const closeModal = document.getElementById('closeModal');
        const cancelEdit = document.getElementById('cancelEdit');

        const openModal = () => { editModal.classList.add('active'); document.body.style.overflow='hidden'; };
        const closeModalFunc = () => { editModal.classList.remove('active'); document.body.style.overflow='auto'; };

        editBtn.addEventListener('click', openModal);
        closeModal.addEventListener('click', closeModalFunc);
        cancelEdit.addEventListener('click', closeModalFunc);

        window.addEventListener('click', e => { if(e.target === editModal) closeModalFunc(); });
        document.addEventListener('keydown', e => { if(e.key==='Escape') closeModalFunc(); });
    });
</script>


</body>
</html>