<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ page import="com.mycompany.model.User" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Details | ${complaint.title}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #8a4af3;
            --primary-light: #9d5af5;
            --primary-dark: #7a39e1;
            --secondary: #b794f6;
            --accent: #d6bcfa;
            --light-purple: #f5f3ff;
            --dark: #2d3748;
            --gray: #718096;
            --light-gray: #edf2f7;
            --success: #48bb78;
            --warning: #ed8936;
            --danger: #f56565;
            --info: #4299e1;
            --border-radius: 10px;
            --shadow: 0 4px 20px rgba(138, 74, 243, 0.15);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
            background: linear-gradient(135deg, var(--light-purple) 0%, #e9d8fd 100%);
            min-height: 100vh;
            padding: 20px;
            color: var(--dark);
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
        }

        /* Notification Styles */
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        }

        .notification {
            padding: 15px 20px;
            border-radius: var(--border-radius);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            animation: slideInRight 0.3s ease forwards;
            transform: translateX(400px);
            opacity: 0;
        }

        @keyframes slideInRight {
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .notification.success {
            background: linear-gradient(90deg, #48bb78, #38a169);
            color: white;
            border-left: 4px solid #2f855a;
        }

        .notification.error {
            background: linear-gradient(90deg, #f56565, #e53e3e);
            color: white;
            border-left: 4px solid #c53030;
        }

        .notification.warning {
            background: linear-gradient(90deg, #ed8936, #dd6b20);
            color: white;
            border-left: 4px solid #c05621;
        }

        .notification.info {
            background: linear-gradient(90deg, #4299e1, #3182ce);
            color: white;
            border-left: 4px solid #2b6cb0;
        }

        .notification-icon {
            font-size: 20px;
            flex-shrink: 0;
        }

        .notification-content {
            flex: 1;
        }

        .notification-title {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .notification-message {
            font-size: 14px;
            opacity: 0.9;
        }

        .notification-close {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }

        .notification-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        .header h1 {
            color: var(--primary);
            font-size: 26px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header h1 i {
            color: var(--primary-dark);
            background: var(--accent);
            padding: 10px;
            border-radius: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .role-badge {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Main Card */
        .main-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            margin-bottom: 30px;
        }

        .card-header {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            padding: 25px 30px;
        }

        .card-header h2 {
            font-size: 24px;
            margin-bottom: 8px;
            font-weight: 700;
        }

        .complaint-id {
            font-size: 14px;
            opacity: 0.9;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .status-badge {
            display: inline-block;
            margin-left: 15px;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: white;
        }

        .status.pending { color: var(--warning); }
        .status.in_progress { color: var(--info); }
        .status.resolved { color: var(--success); }
        .status.rejected { color: var(--danger); }

        /* Content Layout */
        .content-wrapper {
            padding: 30px;
        }

        /* Data List */
        .data-list {
            list-style: none;
            margin-bottom: 30px;
        }

        .data-list li {
            padding: 18px 20px;
            border-bottom: 1px solid var(--light-gray);
            display: flex;
            align-items: flex-start;
            transition: var(--transition);
        }

        .data-list li:hover {
            background: var(--light-purple);
            transform: translateX(5px);
        }

        .data-list li:last-child {
            border-bottom: none;
        }

        .data-list i {
            color: var(--primary);
            width: 24px;
            margin-right: 15px;
            margin-top: 2px;
            font-size: 18px;
        }

        .data-label {
            font-weight: 600;
            color: var(--dark);
            min-width: 180px;
        }

        .data-value {
            color: var(--gray);
            flex: 1;
            line-height: 1.6;
        }

        /* Image Section */
        .image-section {
            margin: 40px 0;
            padding: 25px;
            background: var(--light-purple);
            border-radius: var(--border-radius);
            border-left: 4px solid var(--primary);
        }

        .image-section h3 {
            color: var(--primary);
            margin-bottom: 20px;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .complaint-image {
            max-width: 100%;
            max-height: 400px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: var(--transition);
            cursor: pointer;
            border: 3px solid white;
        }

        .complaint-image:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        /* Staff Responses (Card Style) */
        .responses-section {
            margin: 40px 0;
        }

        .section-title {
            color: var(--primary);
            margin-bottom: 25px;
            font-size: 22px;
            display: flex;
            align-items: center;
            gap: 12px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--accent);
        }

        .response-cards {
            display: grid;
            gap: 20px;
        }

        .response-card {
            background: white;
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 15px rgba(138, 74, 243, 0.1);
            border-left: 5px solid var(--primary);
            transition: var(--transition);
        }

        .response-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(138, 74, 243, 0.15);
        }

        .response-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
        }

        .response-header i {
            color: var(--primary);
            font-size: 20px;
            background: var(--accent);
            padding: 10px;
            border-radius: 50%;
        }

        .staff-name {
            font-weight: 600;
            color: var(--primary-dark);
            font-size: 16px;
        }

        .response-message {
            color: var(--dark);
            line-height: 1.7;
            padding-left: 10px;
            border-left: 3px solid var(--accent);
            margin-left: 15px;
            padding-left: 15px;
        }

        .no-responses {
            text-align: center;
            padding: 40px;
            color: var(--gray);
            background: var(--light-purple);
            border-radius: var(--border-radius);
            border: 2px dashed var(--accent);
        }

        .no-responses i {
            font-size: 48px;
            margin-bottom: 15px;
            color: var(--secondary);
            opacity: 0.7;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid var(--light-gray);
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            font-size: 15px;
        }

        .btn-back {
            background: var(--gray);
            color: white;
        }

        .btn-back:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(90, 98, 104, 0.3);
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(138, 74, 243, 0.4);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #38a169;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(72, 187, 120, 0.4);
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-warning:hover {
            background: #dd6b20;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(237, 137, 54, 0.4);
        }

        /* Modal Styles (Purple Theme) */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(45, 55, 72, 0.7);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal.active {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background: white;
            border-radius: var(--border-radius);
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(138, 74, 243, 0.2);
            animation: slideUp 0.4s ease;
        }

        @keyframes slideUp {
            from { transform: translateY(50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-header {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            font-size: 20px;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .close-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 50%;
            transition: var(--transition);
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--primary);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 16px;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(138, 74, 243, 0.1);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .modal-footer {
            padding: 20px 30px;
            background: var(--light-purple);
            border-top: 1px solid var(--light-gray);
            text-align: right;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .data-list li {
                flex-direction: column;
                gap: 5px;
            }
            
            .data-label {
                min-width: auto;
                margin-bottom: 5px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .status-badge {
                display: block;
                margin: 10px 0 0 0;
                width: fit-content;
            }
            
            .notification-container {
                top: 10px;
                right: 10px;
                left: 10px;
                max-width: none;
            }
        }

        @media (max-width: 480px) {
            .content-wrapper {
                padding: 20px;
            }
            
            .data-list li {
                padding: 15px;
            }
        }
        
        /* Lightbox Modal Styles */
        .lightbox-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .lightbox-modal.active {
            display: flex;
        }

        .lightbox-content {
            position: relative;
            max-width: 90%;
            max-height: 90%;
            text-align: center;
        }

        #lightbox-image {
            max-width: 100%;
            max-height: 80vh;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
            animation: zoomIn 0.3s ease;
        }

        @keyframes zoomIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .lightbox-close {
            position: absolute;
            top: -40px;
            right: 0;
            color: white;
            font-size: 40px;
            font-weight: 300;
            cursor: pointer;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
        }

        .lightbox-close:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(90deg);
        }

        .lightbox-caption {
            margin-top: 15px;
            color: white;
            font-size: 16px;
            text-align: center;
        }

        .lightbox-caption-text {
            padding: 8px 20px;
            background: rgba(138, 74, 243, 0.8);
            border-radius: 20px;
            display: inline-block;
        }

        /* Form loading state */
        .form-loading .update-btn {
            position: relative;
            pointer-events: none;
        }

        .form-loading .update-btn:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 8px;
        }

        .form-loading .update-btn i {
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Notification Container -->
    <div class="notification-container" id="notificationContainer">
        <c:if test="${not empty successMessage}">
            <div class="notification success">
                <i class="fas fa-check-circle notification-icon"></i>
                <div class="notification-content">
                    <div class="notification-title">Success!</div>
                    <div class="notification-message">${successMessage}</div>
                </div>
                <button class="notification-close" onclick="this.parentElement.remove()">&times;</button>
            </div>
        </c:if>
        
        <c:if test="${not empty errorMessage}">
            <div class="notification error">
                <i class="fas fa-exclamation-circle notification-icon"></i>
                <div class="notification-content">
                    <div class="notification-title">Error!</div>
                    <div class="notification-message">${errorMessage}</div>
                </div>
                <button class="notification-close" onclick="this.parentElement.remove()">&times;</button>
            </div>
        </c:if>
    </div>

    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-file-alt"></i> Complaint Details</h1>
            <div class="user-info">
                <span>Welcome, <strong>${user.username}</strong></span>
                <span class="role-badge">${user.role}</span>
            </div>
        </div>

        <!-- Status Messages -->
        <c:if test="${not empty error}">
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                ${error}
            </div>
        </c:if>
        <c:if test="${not empty success}">
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                ${success}
            </div>
        </c:if>

        <!-- Main Card -->
        <div class="main-card">
            <div class="card-header">
                <h2>${complaint.title}</h2>
                <div class="complaint-id">
                    <span class="status-badge status ${complaint.status}">
                        ${fn:replace(complaint.status, '_', ' ').toUpperCase()}
                    </span>
                </div>
            </div>

            <div class="content-wrapper">
                <!-- Data List -->
                <ul class="data-list">
                    <li>
                        <i class="fas fa-user"></i>
                        <span class="data-label">Resident:</span>
                        <span class="data-value">${resident.name}</span>
                    </li>
                    <li>
                        <i class="fas fa-home"></i>
                        <span class="data-label">Unit:</span>
                        <span class="data-value">
                            Block ${unit.block} - Floor ${unit.floor} - Unit ${unit.unit_number}
                        </span>
                    </li>
                    <li>
                        <i class="fas fa-tag"></i>
                        <span class="data-label">Category:</span>
                        <span class="data-value">
                            <strong>${category.category_name}</strong> - ${category.description}
                        </span>
                    </li>
                    <li>
                        <i class="fas fa-align-left"></i>
                        <span class="data-label">Description:</span>
                        <span class="data-value">${complaint.description}</span>
                    </li>
                    <li>
                        <i class="fas fa-user-tie"></i>
                        <span class="data-label">Assigned Staff:</span>
                        <span class="data-value">
                            <c:choose>
                                <c:when test="${not empty assignedStaffName}">
                                    ${assignedStaffName}
                                </c:when>
                                <c:otherwise>
                                    Not assigned yet
                                </c:otherwise>
                            </c:choose>
                        </span>
                    </li>
                </ul>

                <!-- Image Section -->
                <c:if test="${hasImage}">
                <div class="image-section">
                    <h3><i class="fas fa-image"></i> Complaint Image</h3>
                    <div class="image-container">
                        <img src="${pageContext.request.contextPath}/ImageServlet?id=${complaint.complaint_id}" 
                             class="complaint-image" 
                             alt="Complaint Image"
                             onclick="openLightbox(this.src, '${complaint.title}')">
                        <div class="image-actions">
                            <button class="btn btn-view" onclick="openLightbox('${pageContext.request.contextPath}/ImageServlet?id=${complaint.complaint_id}', '${complaint.title}')">
                                <i class="fas fa-expand"></i> View Full Size
                            </button>
                            <a href="${pageContext.request.contextPath}/ImageServlet?id=${complaint.complaint_id}" 
                               download="complaint_${complaint.complaint_id}.jpg" 
                               class="btn btn-success">
                                <i class="fas fa-download"></i> Download
                            </a>
                        </div>
                    </div>
                </div>
                </c:if>

                <!-- Staff Responses (in cards) -->
                <c:if test="${complaint.status eq 'resolved'}">
                    <div class="responses-section">
                        <h3 class="section-title"><i class="fas fa-comments"></i> Staff Responses</h3>
                        
                        <c:choose>
                            <c:when test="${not empty responses}">
                                <div class="response-cards">
                                    <c:forEach var="resp" items="${responses}">
                                        <div class="response-card">
                                            <div class="response-header">
                                                <i class="fas fa-user-tie"></i>
                                                <span class="staff-name">${assignedStaffName}</span>
                                            </div>
                                            <p class="response-message">${resp.message}</p>
                                        </div>
                                    </c:forEach>
                                </div>
                            </c:when>
                            <c:otherwise>
                                <div class="no-responses">
                                    <i class="fas fa-comment-slash"></i>
                                    <h4>No Responses Available</h4>
                                    <p>This complaint was resolved without any response notes.</p>
                                </div>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </c:if>

                <!-- Action Buttons -->
                <div class="action-buttons">
                    <c:choose>
                        <c:when test="${user.role eq 'resident'}">
                            <c:set var="backUrl" value="${pageContext.request.contextPath}/resident/myComplaint" />
                        </c:when>
                        <c:when test="${user.role eq 'admin'}">
                            <c:set var="backUrl" value="${pageContext.request.contextPath}/admin/admin-complaints" />
                        </c:when>
                        <c:when test="${user.role eq 'staff'}">
                            <c:set var="backUrl" value="${pageContext.request.contextPath}/staff/staff-complaints" />
                        </c:when>
                        <c:otherwise>
                            <c:set var="backUrl" value="${pageContext.request.contextPath}/dashboard" />
                        </c:otherwise>
                    </c:choose>
                    
                    <a href="${backUrl}" class="btn btn-back">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>

                    <c:if test="${user.role eq 'resident' and complaint.status eq 'pending'}">
                        <button class="btn btn-primary" id="editComplaintBtn">
                            <i class="fas fa-edit"></i> Edit Complaint
                        </button>
                    </c:if>

                    <c:if test="${user.role eq 'admin' and complaint.status ne 'resolved' and complaint.status ne 'rejected'}">
                        <button class="btn btn-primary" id="editComplaintBtn">
                            <i class="fas fa-edit"></i> Edit Complaint
                        </button>
                    </c:if>

                    <c:if test="${user.role eq 'admin' and complaint.status ne 'resolved' and complaint.status ne 'rejected'}">
                        <button class="btn btn-success" id="assignStaffBtn">
                            <i class="fas fa-user-tie"></i> Assign Staff
                        </button>
                    </c:if>

                    <c:if test="${user.role eq 'staff' and complaint.status ne 'resolved' and complaint.status ne 'rejected'}">
                        <button class="btn btn-warning" id="responseBtn">
                            <i class="fas fa-reply"></i> Respond
                        </button>
                    </c:if>
                </div>
            </div>
        </div>

        <!-- Edit / Assign Form (Hidden by default, shown in modal) -->
        <div class="card mb-4" style="display: none;" id="editFormCard">
            <div class="card-header">
                <h4>Edit / Assign Complaint</h4>
            </div>
            <div class="card-body">
                <form action="${pageContext.request.contextPath}/complaint/update" method="post" id="editComplaintForm">
                    <input type="hidden" name="complaint_id" value="${complaint.complaint_id}" />

                    <!-- Title -->
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title"
                               value="${complaint.title}" required>
                    </div>

                    <!-- Description -->
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="4"
                                  required>${complaint.description}</textarea>
                    </div>

                    <!-- Status -->
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending" <c:if test="${complaint.status == 'pending'}">selected</c:if>>Pending</option>
                            <option value="in_progress" <c:if test="${complaint.status == 'in_progress'}">selected</c:if>>In Progress</option>
                            <option value="resolved" <c:if test="${complaint.status == 'resolved'}">selected</c:if>>Resolved</option>
                            <option value="rejected" <c:if test="${complaint.status == 'rejected'}">selected</c:if>>Rejected</option>
                        </select>
                    </div>

                    <!-- Category Dropdown -->
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-select" id="category" name="category_id" required>
                            <c:forEach var="cat" items="${allCategories}">
                                <option value="${cat.category_id}"
                                    <c:if test="${cat.category_id == complaint.category_id}">selected</c:if>>
                                    ${cat.category_name}
                                </option>
                            </c:forEach>
                        </select>
                    </div>

                    <!-- Unit Dropdown -->
                    <c:if test="${user.role eq 'admin'}">
                    <div class="mb-3">
                        <label for="unit" class="form-label">Unit</label>
                        <select class="form-select" id="unit" name="unit_id" required>
                            <c:forEach var="unitItem" items="${allUnits}">
                                <option value="${unitItem.unit_id}"
                                    <c:if test="${unitItem.unit_id == complaint.unit_id}">selected</c:if>>
                                    Block ${unitItem.block} - Floor ${unitItem.floor} - Unit ${unitItem.unit_number}
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                    </c:if>
                    <c:if test="${user.role ne 'admin'}">
                        <input type="hidden" name="unit_id" value="${complaint.unit_id}">
                    </c:if>

                    <!-- Staff Dropdown -->
                    <div class="mb-3">
                        <label for="staff" class="form-label">Assign Staff</label>
                        <select class="form-select" id="staff" name="staff_id">
                            <option value="">-- Unassigned --</option>
                            <c:forEach var="staff" items="${staffByCategory}">
                                <option value="${staff.staff_id}"
                                    <c:if test="${staff.staff_id == complaint.staff_id}">selected</c:if>>
                                    ${staff.name}
                                </option>
                            </c:forEach>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Update Complaint</button>
                </form>
            </div>
        </div>
    </div>


    <!-- Image Lightbox Modal -->
    <div id="imageLightbox" class="lightbox-modal">
        <div class="lightbox-content">
            <span class="lightbox-close">&times;</span>
            <img id="lightbox-image" src="" alt="Complaint Image">
            <div class="lightbox-caption">
                <span id="lightbox-caption-text">Complaint Image</span>
            </div>
        </div>
    </div>

    <!-- Edit Complaint Modal (Updated with JSTL) -->
    <div id="editComplaintModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Complaint</h3>
                <button class="close-btn" id="closeEditComplaint">&times;</button>
            </div>
            <form id="editComplaintForm" action="${pageContext.request.contextPath}/EditComplaintController" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="complaint_id" value="${complaint.complaint_id}">

                    <div class="form-group">
                        <label for="title"><i class="fas fa-heading"></i> Title</label>
                        <input type="text" id="title" name="title" class="form-control" value="${complaint.title}" required>
                    </div>

                    <div class="form-group">
                        <label for="description"><i class="fas fa-align-left"></i> Description</label>
                        <textarea id="description" name="description" class="form-control" rows="4" required>${complaint.description}</textarea>
                    </div>

                    <c:if test="${user.role eq 'admin'}">
                    <div class="form-group">
                        <label for="unit_id"><i class="fas fa-home"></i> Unit</label>
                        <select id="unit_id" name="unit_id" class="form-control" required>
                            <c:forEach var="unitItem" items="${allUnits}">
                                <option value="${unitItem.unit_id}" ${unitItem.unit_id eq complaint.unit_id ? 'selected' : ''}>
                                    Block ${unitItem.block} - Floor ${unitItem.floor} - Unit ${unitItem.unit_number}
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                    </c:if>
                    
                    <c:if test="${user.role ne 'admin'}">
                        <input type="hidden" name="unit_id" value="${complaint.unit_id}">
                    </c:if>

                    <div class="form-group">
                        <label for="category_id"><i class="fas fa-tags"></i> Category</label>
                        <select id="category_id" name="category_id" class="form-control" required>
                            <c:forEach var="cat" items="${allCategories}">
                                <option value="${cat.category_id}" ${cat.category_id eq complaint.category_id ? 'selected' : ''}>
                                    ${cat.category_name}
                                </option>
                            </c:forEach>
                        </select>
                    </div>

                    <c:if test="${user.role eq 'admin'}">
                        <div class="form-group">
                            <label for="status"><i class="fas fa-tasks"></i> Status</label>
                            <select id="status" name="status" class="form-control" required>
                                <option value="pending" ${complaint.status eq 'pending' ? 'selected' : ''}>Pending</option>
                                <option value="in_progress" ${complaint.status eq 'in_progress' ? 'selected' : ''}>In Progress</option>
                                <option value="resolved" ${complaint.status eq 'resolved' ? 'selected' : ''}>Resolved</option>
                                <option value="rejected" ${complaint.status eq 'rejected' ? 'selected' : ''}>Rejected</option>
                            </select>
                        </div>
                    </c:if>

                    <div class="form-group">
                        <label for="image"><i class="fas fa-image"></i> Upload Image (optional)</label>
                        <input type="file" id="image" name="image" class="form-control" accept="image/*">
                        <small class="text-muted">Leave empty to keep current image</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-back" id="cancelEditComplaint">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary" id="submitEditBtn">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Assign Staff Modal (Updated with JSTL) -->
    <div id="assignStaffModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-tie"></i> Assign Staff</h3>
                <button class="close-btn" id="closeAssignStaff">&times;</button>
            </div>
            <form id="assignStaffForm" action="${pageContext.request.contextPath}/AssignStaffController" method="post">
                <div class="modal-body">
                    <input type="hidden" name="complaint_id" value="${complaint.complaint_id}">
                    
                    <div class="form-group">
                        <label for="staff_id"><i class="fas fa-users"></i> Select Staff Member</label>
                        <select id="staff_id" name="staff_id" class="form-control" required>
                            <option value="">-- Select a staff member --</option>
                            <c:forEach var="staff" items="${staffByCategory}">
                                <option value="${staff.staff_id}" ${staff.staff_id eq complaint.staff_id ? 'selected' : ''}>
                                    ${staff.name}
                                </option>
                            </c:forEach>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-back" id="cancelAssignStaff">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success" id="submitAssignBtn">
                        <i class="fas fa-check"></i> Assign Staff
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Staff Response Modal -->
    <div id="responseModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-reply"></i> Complaint Response</h3>
                <button class="close-btn" id="closeResponse">&times;</button>
            </div>
            <form method="post" action="${pageContext.request.contextPath}/staff/ComplaintResponseController">
                <div class="modal-body">
                    <input type="hidden" name="complaint_id" value="${complaint.complaint_id}">
                    
                    <div class="form-group">
                        <label for="response_message"><i class="fas fa-comment-dots"></i> Response Message</label>
                        <textarea id="response_message" name="response_message" class="form-control" rows="6" 
                                  placeholder="Enter your response to this complaint..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-back" id="cancelResponse">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-paper-plane"></i> Submit Response
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>       
        // Show notifications if they exist
        document.addEventListener('DOMContentLoaded', function() {
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(notification => {
                // Auto-remove notifications after 5 seconds
                setTimeout(() => {
                    if (notification.parentElement) {
                        notification.style.opacity = '0';
                        notification.style.transform = 'translateX(400px)';
                        notification.style.transition = 'all 0.3s ease';
                        setTimeout(() => {
                            if (notification.parentElement) {
                                notification.parentElement.removeChild(notification);
                            }
                        }, 300);
                    }
                }, 5000);
            });
        });

        // Modal handling
        const editModal = document.getElementById('editComplaintModal');
        const editBtn = document.getElementById('editComplaintBtn');
        const closeEdit = document.getElementById('closeEditComplaint');
        const cancelEdit = document.getElementById('cancelEditComplaint');

        if(editBtn) {
            editBtn.onclick = function() {
                editModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }

        function closeEditModal() {
            editModal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        if(closeEdit) closeEdit.onclick = closeEditModal;
        if(cancelEdit) cancelEdit.onclick = closeEditModal;

        // Assign Staff Modal
        const assignModal = document.getElementById('assignStaffModal');
        const assignBtn = document.getElementById('assignStaffBtn');
        const closeAssign = document.getElementById('closeAssignStaff');
        const cancelAssign = document.getElementById('cancelAssignStaff');

        if(assignBtn) {
            assignBtn.onclick = function() {
                assignModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }

        function closeAssignModal() {
            assignModal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        if(closeAssign) closeAssign.onclick = closeAssignModal;
        if(cancelAssign) cancelAssign.onclick = closeAssignModal;

        // Response Modal
        const responseModal = document.getElementById('responseModal');
        const responseBtn = document.getElementById('responseBtn');
        const closeResponse = document.getElementById('closeResponse');
        const cancelResponse = document.getElementById('cancelResponse');

        if(responseBtn) {
            responseBtn.onclick = function() {
                responseModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }

        function closeResponseModal() {
            responseModal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        if(closeResponse) closeResponse.onclick = closeResponseModal;
        if(cancelResponse) cancelResponse.onclick = closeResponseModal;

        // Close modals when clicking outside or pressing Escape
        window.onclick = function(event) {
            if(event.target == editModal) closeEditModal();
            if(event.target == assignModal) closeAssignModal();
            if(event.target == responseModal) closeResponseModal();
        }

        document.addEventListener('keydown', function(event) {
            if(event.key === 'Escape') {
                closeEditModal();
                closeAssignModal();
                closeResponseModal();
            }
        });
        
        // Form submission loading states
        const editForm = document.getElementById('editComplaintForm');
        const assignForm = document.getElementById('assignStaffForm');
        
        if (editForm) {
            editForm.addEventListener('submit', function(e) {
                console.log("=== FORM SUBMISSION DEBUG ===");
                console.log("Unit ID selected:", document.getElementById('unit_id')?.value);
                console.log("Complaint ID:", document.querySelector('input[name="complaint_id"]')?.value);
                console.log("Title:", document.getElementById('title')?.value);
                console.log("User Role:", "${user.role}");
                console.log("=============================");
                
                const submitBtn = this.querySelector('#submitEditBtn');
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                submitBtn.disabled = true;
                this.classList.add('form-loading');
            });
        }
        
        if (assignForm) {
            assignForm.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('#submitAssignBtn');
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Assigning...';
                submitBtn.disabled = true;
                this.classList.add('form-loading');
            });
        }
        
        // Lightbox functionality
        function openLightbox(imageSrc, caption) {
            const lightbox = document.getElementById('imageLightbox');
            const lightboxImage = document.getElementById('lightbox-image');
            const lightboxCaption = document.getElementById('lightbox-caption-text');

            lightboxImage.src = imageSrc;
            lightboxCaption.textContent = caption || 'Complaint Image';
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeLightbox() {
            const lightbox = document.getElementById('imageLightbox');
            lightbox.classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        // Add event listeners for lightbox
        document.addEventListener('DOMContentLoaded', function() {
            const lightbox = document.getElementById('imageLightbox');
            const closeBtn = document.querySelector('.lightbox-close');

            if (closeBtn) {
                closeBtn.addEventListener('click', closeLightbox);
            }

            // Close lightbox when clicking outside the image
            lightbox.addEventListener('click', function(event) {
                if (event.target === lightbox) {
                    closeLightbox();
                }
            });

            // Close lightbox with Escape key
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && lightbox.classList.contains('active')) {
                    closeLightbox();
                }
            });

            // Prevent image clicks from closing the lightbox
            const lightboxImage = document.getElementById('lightbox-image');
            if (lightboxImage) {
                lightboxImage.addEventListener('click', function(event) {
                    event.stopPropagation();
                });
            }
        });
        
        // Show a notification (fixed version)
        function showNotification(type, title, message) {
            const container = document.getElementById('notificationContainer');
            const notification = document.createElement('div');
            notification.className = 'notification ' + type;
            
            // Determine icon based on type
            let icon = 'info-circle';
            if (type === 'success') icon = 'check-circle';
            else if (type === 'error') icon = 'exclamation-circle';
            else if (type === 'warning') icon = 'exclamation-triangle';
            
            notification.innerHTML = [
                '<i class="fas fa-' + icon + ' notification-icon"></i>',
                '<div class="notification-content">',
                '    <div class="notification-title">' + title + '</div>',
                '    <div class="notification-message">' + message + '</div>',
                '</div>',
                '<button class="notification-close" onclick="this.parentElement.remove()">&times;</button>'
            ].join('');
            
            container.appendChild(notification);
            
            // Auto-remove after 5 seconds
            setTimeout(function() {
                notification.style.opacity = '0';
                notification.style.transform = 'translateX(400px)';
                notification.style.transition = 'all 0.3s ease';
                setTimeout(function() {
                    if (notification.parentElement) {
                        notification.parentElement.removeChild(notification);
                    }
                }, 300);
            }, 5000);
        }
    </script>
</body>
</html>