<%@ page import="com.mycompany.model.User" %>
<%@ page import="java.util.*" %>
<%@ page import="java.sql.*" %>
<%@ page import="com.mycompany.controller.DBConnect" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<c:if test="${empty sessionScope.user or sessionScope.user.role ne 'admin'}">
    <c:redirect url="/login" />
</c:if>

<!DOCTYPE html>
<html>
<head>
    <title>Analytics Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
            display: flex;
        }

        /* Sidebar Styles - Matching previous design */
        .admin-sidebar {
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow);
            padding: 25px 0;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
            height: 100vh;
            position: sticky;
            top: 0;
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        .admin-nav-link.active::after {
            content: '';
            position: absolute;
            right: -10px;
            top: 50%;
            transform: translateY(-50%);
            width: 0;
            height: 0;
            border-top: 10px solid transparent;
            border-bottom: 10px solid transparent;
            border-right: 10px solid var(--primary);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
            max-width: calc(100% - 280px);
        }

        /* Header */
        .header {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header h1 i {
            font-size: 1.8rem;
        }

        .header p {
            color: var(--gray);
            font-size: 1.1rem;
            max-width: 600px;
            line-height: 1.6;
            margin-top: 10px;
        }

        /* Stats Summary */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-item {
            background: white;
            border-radius: var(--card-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-icon.pending { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-icon.in-progress { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-icon.resolved { background: linear-gradient(135deg, #00b894, #00a085); }
        .stat-icon.today { background: linear-gradient(135deg, #a29bfe, #6c5ce7); }
        .stat-icon.week { background: linear-gradient(135deg, #00cec9, #00b894); }
        .stat-icon.category { background: linear-gradient(135deg, #fd79a8, #e84393); }
        .stat-icon.staff { background: linear-gradient(135deg, #fdcb6e, #f39c12); }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--dark);
            line-height: 1;
        }

        .stat-content p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Charts Container */
        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-header h3 {
            font-size: 1.2rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .chart-header h3 i {
            color: var(--primary);
        }

        .chart-wrapper {
            position: relative;
            height: 300px;
            width: 100%;
        }

        /* Filters */
        .filters {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .filter-btn {
            padding: 12px 24px;
            background: white;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-weight: 600;
            color: var(--dark);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-btn:hover {
            border-color: var(--primary-light);
            background: rgba(108, 92, 231, 0.05);
            transform: translateY(-2px);
        }

        .filter-btn.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            border-color: var(--primary);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .search-box {
            position: relative;
            min-width: 300px;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 1.1rem;
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        .table-header {
            padding: 25px 30px;
            border-bottom: 1px solid var(--light-gray);
            background: rgba(108, 92, 231, 0.02);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .table-header h3 {
            font-size: 1.2rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table-header h3 i {
            color: var(--primary);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }

        th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
        }

        th:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 25%;
            height: 50%;
            width: 1px;
            background: rgba(255, 255, 255, 0.3);
        }

        tbody tr {
            transition: var(--transition);
            border-bottom: 1px solid var(--light-gray);
        }

        tbody tr:hover {
            background-color: rgba(108, 92, 231, 0.03);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td {
            padding: 20px;
            color: var(--dark);
            vertical-align: middle;
        }

        /* Status Badges */
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: capitalize;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-width: 120px;
            justify-content: center;
        }

        .status-badge i {
            font-size: 0.8rem;
        }

        .status-pending {
            background: rgba(253, 203, 110, 0.1);
            color: #f39c12;
            border: 1px solid rgba(243, 156, 18, 0.2);
        }

        .status-in_progress {
            background: rgba(116, 185, 255, 0.1);
            color: #0984e3;
            border: 1px solid rgba(9, 132, 227, 0.2);
        }

        .status-resolved {
            background: rgba(0, 184, 148, 0.1);
            color: #00b894;
            border: 1px solid rgba(0, 184, 148, 0.2);
        }

        .status-rejected {
            background: rgba(225, 112, 85, 0.1);
            color: #e17055;
            border: 1px solid rgba(225, 112, 85, 0.2);
        }

        /* Category Badge */
        .category-badge {
            padding: 8px 16px;
            background: rgba(108, 92, 231, 0.1);
            color: var(--primary);
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        /* Date Styling */
        .date-time {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .date {
            font-weight: 500;
            color: var(--dark);
        }

        .time {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* No Data */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
        }

        .no-data h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        /* Print Section Styles */
        .print-section {
            display: none;
        }

        @media print {
            /* Hide everything except print-section */
            body * {
                visibility: hidden;
            }

            /* Show only the print section */
            .print-section, .print-section * {
                visibility: visible;
            }

            .print-section {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                display: block !important;
            }

            /* Remove page margins for printing */
            @page {
                margin: 0.5in;
            }
            
            /* Ensure charts print properly */
            .print-chart {
                page-break-inside: avoid;
                max-width: 100% !important;
            }
            
            /* Force black text for better printing */
            .print-section h1, 
            .print-section h2, 
            .print-section h3, 
            .print-section p, 
            .print-section td, 
            .print-section th {
                color: #000 !important;
            }
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 992px) {
            body {
                flex-direction: column;
            }
            
            .admin-sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px 0;
            }
            
            .main-content {
                max-width: 100%;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 20px;
            }
            
            .filters {
                flex-direction: column;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .stats-summary {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .chart-card {
                padding: 20px;
            }
            
            .chart-wrapper {
                height: 250px;
            }
            
            .table-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        @media (max-width: 576px) {
            .stats-summary {
                grid-template-columns: 1fr;
            }
            
            .chart-wrapper {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    ${sessionScope.user.username.substring(0, 1).toUpperCase()}
                </div>
                <div class="admin-info">
                    <h4>${sessionScope.user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link active">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header with Print Button -->
        <div class="header">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1><i class="fas fa-chart-line"></i> Analytics Dashboard</h1>
                    <p>Real-time analytics and insights based on complaint data.</p>
                </div>
                <button class="action-btn btn-primary" onclick="printReport()">
                    <i class="fas fa-print"></i> Print Report
                </button>
            </div>
        </div>
        
        <!-- Hidden Print Section (Only visible when printing) -->
        <div class="print-section">
            <div style="text-align: center; margin-bottom: 30px; padding: 20px;">
                <h1 style="color: var(--primary); margin-bottom: 10px;">Analytics Report</h1>
                <p style="color: var(--gray);">Apartment Chempaka Management System</p>
                <p style="color: var(--gray);">Generated on: <span id="printDate"></span></p>
            </div>
            
            <!-- Print Stats Summary -->
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem;">${totalComplaints}</h3>
                    <p style="color: var(--gray);">Total Complaints</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: #f39c12; font-size: 1.8rem;">${pendingCount}</h3>
                    <p style="color: var(--gray);">Pending Review</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: #0984e3; font-size: 1.8rem;">${inProgressCount}</h3>
                    <p style="color: var(--gray);">In Progress</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: #00b894; font-size: 1.8rem;">${resolvedCount}</h3>
                    <p style="color: var(--gray);">Resolved</p>
                </div>
            </div>
            
            <!-- Print Additional Stats -->
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem;">${analytics.todayComplaints}</h3>
                    <p style="color: var(--gray);">Today's Complaints</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem;">${analytics.thisWeekComplaints}</h3>
                    <p style="color: var(--gray);">This Week</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem;">${analytics.topCategoryCount}</h3>
                    <p style="color: var(--gray);">Top Category: ${analytics.topCategory}</p>
                </div>
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <h3 style="color: var(--primary); font-size: 1.8rem;">${analytics.mostActiveStaffCount}</h3>
                    <p style="color: var(--gray);">Most Active: ${analytics.mostActiveStaff}</p>
                </div>
            </div>
            
            <!-- Charts for Printing -->
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px;">
                <!-- Status Distribution Chart -->
                <div style="background: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd; page-break-inside: avoid;">
                    <h3 style="text-align: center; margin-bottom: 15px; color: var(--dark);">Complaint Status Distribution</h3>
                    <div id="printStatusChart" style="height: 300px; width: 100%;">
                        <!-- Chart will be rendered here as image -->
                        <img id="printStatusChartImg" style="width: 100%; height: auto; max-height: 300px;" />
                    </div>
                </div>
                
                <!-- Category Chart -->
                <div style="background: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd; page-break-inside: avoid;">
                    <h3 style="text-align: center; margin-bottom: 15px; color: var(--dark);">Complaints by Category</h3>
                    <div id="printCategoryChart" style="height: 300px; width: 100%;">
                        <!-- Chart will be rendered here as image -->
                        <img id="printCategoryChartImg" style="width: 100%; height: auto; max-height: 300px;" />
                    </div>
                </div>
            </div>
            
            <!-- Monthly Trend Chart -->
            <div style="background: white; padding: 20px; border-radius: 10px; border: 1px solid #ddd; margin-bottom: 30px; page-break-inside: avoid;">
                <h3 style="text-align: center; margin-bottom: 15px; color: var(--dark);">Monthly Complaint Trend (Last 6 Months)</h3>
                <div id="printTrendChart" style="height: 300px; width: 100%;">
                    <!-- Chart will be rendered here as image -->
                    <img id="printTrendChartImg" style="width: 100%; height: auto; max-height: 300px;" />
                </div>
            </div>
            
            <!-- Print Table -->
            <h3 style="color: var(--dark); margin-bottom: 20px;">Recent Complaints</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px; margin-bottom: 30px;">
                <thead>
                    <tr style="background: var(--primary); color: white;">
                        <th style="padding: 12px; text-align: left;">Complaint Details</th>
                        <th style="padding: 12px; text-align: left;">Resident</th>
                        <th style="padding: 12px; text-align: left;">Category</th>
                        <th style="padding: 12px; text-align: left;">Status</th>
                        <th style="padding: 12px; text-align: left;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="c" items="${complaints}" end="19">
                        <tr style="border-bottom: 1px solid #ddd;">
                            <td style="padding: 10px;">
                                <div style="font-weight: 600;">${c.title}</div>
                                <c:if test="${not empty c.description}">
                                    <div style="font-size: 0.85rem; color: var(--gray); margin-top: 5px;">
                                        ${fn:substring(c.description, 0, 60)}${fn:length(c.description) > 60 ? '...' : ''}
                                    </div>
                                </c:if>
                            </td>
                            <td style="padding: 10px;">${c.residentName}</td>
                            <td style="padding: 10px;">${c.categoryName}</td>
                            <td style="padding: 10px;">
                                <c:choose>
                                    <c:when test="${c.status == 'pending'}">
                                        <span style="color: #f39c12; font-weight: 600;">Pending</span>
                                    </c:when>
                                    <c:when test="${c.status == 'in_progress'}">
                                        <span style="color: #0984e3; font-weight: 600;">In Progress</span>
                                    </c:when>
                                    <c:when test="${c.status == 'resolved'}">
                                        <span style="color: #00b894; font-weight: 600;">Resolved</span>
                                    </c:when>
                                    <c:when test="${c.status == 'rejected'}">
                                        <span style="color: #e17055; font-weight: 600;">Rejected</span>
                                    </c:when>
                                </c:choose>
                            </td>
                            <td style="padding: 10px;">
                                <fmt:formatDate value="${c.created_at}" pattern="dd MMM yyyy"/>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
            
            <div style="margin-top: 40px; text-align: center; font-size: 0.9em; color: var(--gray); border-top: 1px solid #ddd; padding-top: 20px;">
                <p>Report generated by: ${sessionScope.user.username}</p>
                <p>© <span id="currentYear"></span> Apartment Chempaka Management System</p>
            </div>
        </div>
        
        <!-- Stats Summary -->
        <div class="stats-summary">
            <div class="stat-item">
                <div class="stat-icon total">
                    <i class="fas fa-folder-open"></i>
                </div>
                <div class="stat-content">
                    <h3>${totalComplaints}</h3>
                    <p>Total Complaints</p>
                </div>
            </div>
            <div class="stat-item">
                <div class="stat-icon pending">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-content">
                    <h3>${pendingCount}</h3>
                    <p>Pending Review</p>
                </div>
            </div>
            <div class="stat-item">
                <div class="stat-icon in-progress">
                    <i class="fas fa-spinner"></i>
                </div>
                <div class="stat-content">
                    <h3>${inProgressCount}</h3>
                    <p>In Progress</p>
                </div>
            </div>
            <div class="stat-item">
                <div class="stat-icon resolved">
                    <i class="fas fa-check"></i>
                </div>
                <div class="stat-content">
                    <h3>${resolvedCount}</h3>
                    <p>Resolved</p>
                </div>
            </div>
        </div>

        <!-- Additional Stats -->
        <div class="stats-summary">
            <div class="stat-item">
                <div class="stat-icon today">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="stat-content">
                    <h3>${analytics.todayComplaints}</h3>
                    <p>Today's Complaints</p>
                </div>
            </div>
            
            <div class="stat-item">
                <div class="stat-icon week">
                    <i class="fas fa-calendar-week"></i>
                </div>
                <div class="stat-content">
                    <h3>${analytics.thisWeekComplaints}</h3>
                    <p>This Week</p>
                </div>
            </div>
            
            <div class="stat-item">
                <div class="stat-icon category">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-content">
                    <h3>${analytics.topCategoryCount}</h3>
                    <p>Top Category: ${analytics.topCategory}</p>
                </div>
            </div>
            
            <div class="stat-item">
                <div class="stat-icon staff">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="stat-content">
                    <h3>${analytics.mostActiveStaffCount}</h3>
                    <p>Most Active: ${analytics.mostActiveStaff}</p>
                </div>
            </div>
        </div>

        <!-- Charts Container -->
        <div class="charts-container">
            <!-- Status Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fas fa-chart-pie"></i> Complaint Status Distribution</h3>
                    <div class="chart-actions">
                        <select id="statusChartType" class="filter-select" onchange="updateChartType('statusChart', this.value)">
                            <option value="pie">Pie Chart</option>
                            <option value="doughnut">Doughnut</option>
                            <option value="bar">Bar Chart</option>
                        </select>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>

            <!-- Category Chart -->
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fas fa-chart-bar"></i> Complaints by Category</h3>
                    <div class="chart-actions">
                        <select id="categoryChartType" class="filter-select" onchange="updateChartType('categoryChart', this.value)">
                            <option value="bar">Bar Chart</option>
                            <option value="line">Line Chart</option>
                            <option value="pie">Pie Chart</option>
                        </select>
                    </div>
                </div>
                <div class="chart-wrapper">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Monthly Trend Chart -->
        <div class="chart-card">
            <div class="chart-header">
                <h3><i class="fas fa-chart-line"></i> Monthly Complaint Trend (Last 6 Months)</h3>
            </div>
            <div class="chart-wrapper">
                <canvas id="trendChart"></canvas>
            </div>
        </div>
        
        <!-- Complaints Table -->
        <div class="table-container">
            <div class="table-header">
                <h3><i class="fas fa-list"></i> Recent Complaints</h3>
            </div>
            
            <c:choose>
                <c:when test="${not empty complaints}">
                    <table id="complaintsTable">
                        <thead>
                            <tr>
                                <th>Complaint Details</th>
                                <th>Resident</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Assigned To</th>
                                <th>Date & Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="c" items="${complaints}">
                                <tr class="complaint-row" data-status="${c.status}">
                                    <td>
                                        <div style="font-weight: 600; color: var(--dark); display: flex; align-items: center; gap: 10px;">
                                            <i class="fas fa-file-alt" style="color: var(--primary);"></i>
                                            ${c.title}
                                        </div>
                                        <c:if test="${not empty c.description}">
                                            <div style="font-size: 0.85rem; color: var(--gray); margin-top: 5px;">
                                                ${fn:substring(c.description, 0, 60)}${fn:length(c.description) > 60 ? '...' : ''}
                                            </div>
                                        </c:if>
                                    </td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <i class="fas fa-user" style="color: var(--primary); margin-right: 5px;"></i>
                                            <span>${c.residentName}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="category-badge">${c.categoryName}</span>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${c.status == 'pending'}">
                                                <span class="status-badge status-pending">
                                                    <i class="fas fa-clock"></i> Pending
                                                </span>
                                            </c:when>
                                            <c:when test="${c.status == 'in_progress'}">
                                                <span class="status-badge status-in_progress">
                                                    <i class="fas fa-spinner"></i> In Progress
                                                </span>
                                            </c:when>
                                            <c:when test="${c.status == 'resolved'}">
                                                <span class="status-badge status-resolved">
                                                    <i class="fas fa-check-circle"></i> Resolved
                                                </span>
                                            </c:when>
                                            <c:when test="${c.status == 'rejected'}">
                                                <span class="status-badge status-rejected">
                                                    <i class="fas fa-ban"></i> Rejected
                                                </span>
                                            </c:when>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty c.staffName}">
                                                <div style="display: flex; align-items: center; gap: 8px;">
                                                    <i class="fas fa-user-tie" style="color: var(--primary); margin-right: 5px;"></i>
                                                    <span>${c.staffName}</span>
                                                </div>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color: var(--gray); font-style: italic;">Not Assigned</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <div class="date-time">
                                            <span class="date">
                                                <fmt:formatDate value="${c.created_at}" pattern="dd MMM yyyy"/>
                                            </span>
                                            <span class="time">
                                                <fmt:formatDate value="${c.created_at}" pattern="hh:mm a"/>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:when>
                <c:otherwise>
                    <div class="no-data">
                        <i class="fas fa-chart-bar"></i>
                        <h3>No Complaints Data</h3>
                        <p>There are no complaints in the system yet.</p>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <script>
        // Initialize charts
        let statusChart, categoryChart, trendChart;
        let chartImagesReady = false;
        
        function initializeCharts() {
            // Status Chart
            const statusCtx = document.getElementById('statusChart').getContext('2d');
            const statusLabels = [
                <c:forEach var="entry" items="${statusCount}" varStatus="s">
                    '${entry.key.replace("_", " ").toUpperCase()}'<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            const statusData = [
                <c:forEach var="entry" items="${statusCount}" varStatus="s">
                    ${entry.value}<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            
            statusChart = new Chart(statusCtx, {
                type: 'pie',
                data: {
                    labels: statusLabels,
                    datasets: [{
                        data: statusData,
                        backgroundColor: [
                            '#fdcb6e', '#74b9ff', '#00b894', '#e17055', '#a29bfe', '#fd79a8'
                        ],
                        borderWidth: 2,
                        borderColor: 'white',
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                padding: 20,
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        }
                    }
                }
            });
            
            // Category Chart
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            const categoryLabels = [
                <c:forEach var="entry" items="${categoryCount}" varStatus="s">
                    '${entry.key}'<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            const categoryData = [
                <c:forEach var="entry" items="${categoryCount}" varStatus="s">
                    ${entry.value}<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            
            categoryChart = new Chart(categoryCtx, {
                type: 'bar',
                data: {
                    labels: categoryLabels,
                    datasets: [{
                        label: 'Complaints',
                        data: categoryData,
                        backgroundColor: 'rgba(108, 92, 231, 0.8)',
                        borderColor: 'rgba(108, 92, 231, 1)',
                        borderWidth: 1,
                        borderRadius: 8,
                        hoverBackgroundColor: 'rgba(108, 92, 231, 1)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                stepSize: 1
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                maxRotation: 45
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            // Trend Chart
            const trendCtx = document.getElementById('trendChart').getContext('2d');
            const trendLabels = [
                <c:forEach var="entry" items="${monthlyTrend}" varStatus="s">
                    '${entry.key}'<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            const trendData = [
                <c:forEach var="entry" items="${monthlyTrend}" varStatus="s">
                    ${entry.value}<c:if test="${!s.last}">,</c:if>
                </c:forEach>
            ];
            
            trendChart = new Chart(trendCtx, {
                type: 'line',
                data: {
                    labels: trendLabels,
                    datasets: [{
                        label: 'Complaints',
                        data: trendData,
                        borderColor: 'rgba(108, 92, 231, 1)',
                        backgroundColor: 'rgba(108, 92, 231, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.3,
                        pointBackgroundColor: 'rgba(108, 92, 231, 1)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            // Generate chart images for printing after charts are rendered
            setTimeout(generateChartImages, 1000);
        }
        
        // Generate chart images for printing
        function generateChartImages() {
            if (!statusChart || !categoryChart || !trendChart) return;
            
            // Convert charts to images
            const statusChartImg = statusChart.toBase64Image();
            const categoryChartImg = categoryChart.toBase64Image();
            const trendChartImg = trendChart.toBase64Image();
            
            // Set the images in print section
            document.getElementById('printStatusChartImg').src = statusChartImg;
            document.getElementById('printCategoryChartImg').src = categoryChartImg;
            document.getElementById('printTrendChartImg').src = trendChartImg;
            
            chartImagesReady = true;
        }
        
        // Update chart type
        function updateChartType(chartId, newType) {
            if (chartId === 'statusChart' && statusChart) {
                statusChart.config.type = newType;
                statusChart.update();
                // Regenerate image after chart update
                setTimeout(() => {
                    document.getElementById('printStatusChartImg').src = statusChart.toBase64Image();
                }, 500);
            } else if (chartId === 'categoryChart' && categoryChart) {
                categoryChart.config.type = newType;
                categoryChart.update();
                // Regenerate image after chart update
                setTimeout(() => {
                    document.getElementById('printCategoryChartImg').src = categoryChart.toBase64Image();
                }, 500);
            }
        }
        
        // Print report with charts
        function printReport() {
            // Ensure chart images are ready
            if (!chartImagesReady) {
                generateChartImages();
            }
            
            // Update print date
            const now = new Date();
            document.getElementById('printDate').textContent = now.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            document.getElementById('currentYear').textContent = now.getFullYear();
            
            // Wait a moment for images to load, then print
            setTimeout(() => {
                window.print();
            }, 500);
        }
        
        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            initializeCharts();
            
            // Add hover effects to table rows
            const rows = document.querySelectorAll('.complaint-row');
            rows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
                });
                
                row.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.boxShadow = '';
                });
            });
        });
        
        // Also generate chart images when window loads completely
        window.addEventListener('load', function() {
            setTimeout(generateChartImages, 1500);
        });
    </script>   
</body>
</html>