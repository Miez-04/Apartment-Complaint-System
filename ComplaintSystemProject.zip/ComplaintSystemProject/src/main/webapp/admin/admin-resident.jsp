<%@page import="com.mycompany.model.User"%>
<%@page import="com.mycompany.model.Resident"%>
<%@page import="com.mycompany.model.ApartmentUnit"%>
<%@ page session="true" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resident Management | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
            overflow-x: hidden;
        }

        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1001;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 12px;
            font-size: 1.2rem;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        /* Sidebar */
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 1000;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            transition: var(--transition);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header */
        .page-header {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .header-content h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .header-content h1 i {
            font-size: 1.8rem;
        }

        .header-content p {
            color: var(--gray);
            font-size: 1.1rem;
            max-width: 600px;
            line-height: 1.6;
        }

        /* Stats Cards */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-icon.occupied { background: linear-gradient(135deg, #00b894, #00a085); }
        .stat-icon.vacant { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-icon.block-a { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-icon.block-b { background: linear-gradient(135deg, #a29bfe, #6c5ce7); }
        .stat-icon.block-c { background: linear-gradient(135deg, #00cec9, #00b894); }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--dark);
            line-height: 1;
        }

        .stat-content p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Action Bar */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
            background: white;
            padding: 20px;
            border-radius: var(--card-radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .search-box {
            position: relative;
            min-width: 300px;
            flex: 1;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 1.1rem;
        }

        .action-buttons {
            display: flex;
            gap: 12px;
        }

        .btn-primary {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
            text-decoration: none;
            font-size: 0.95rem;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
        }

        .btn-secondary {
            background: white;
            color: var(--primary);
            padding: 14px 28px;
            border: 2px solid var(--primary-light);
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-secondary:hover {
            background: rgba(108, 92, 231, 0.05);
            transform: translateY(-2px);
        }

        /* Residents Table */
        .table-container {
            background: white;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
            position: relative;
            min-height: 400px;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid var(--light-gray);
            background: rgba(108, 92, 231, 0.02);
        }

        .table-header h3 {
            font-size: 1.2rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }

        th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        th i {
            margin-right: 8px;
        }

        tbody tr {
            transition: var(--transition);
            border-bottom: 1px solid var(--light-gray);
        }

        tbody tr:hover {
            background-color: rgba(108, 92, 231, 0.03);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td {
            padding: 20px;
            color: var(--dark);
            vertical-align: middle;
        }

        .resident-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .resident-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .resident-details {
            display: flex;
            flex-direction: column;
        }

        .resident-name {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 4px;
        }

        .resident-id {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light-gray);
            padding: 2px 8px;
            border-radius: 4px;
            display: inline-block;
            width: fit-content;
        }

        .unit-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: white;
            width: fit-content;
        }

        .block-a { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .block-b { background: linear-gradient(135deg, #a29bfe, #6c5ce7); }
        .block-c { background: linear-gradient(135deg, #00cec9, #00b894); }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .contact-email, .contact-phone {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }

        .contact-email i, .contact-phone i {
            color: var(--primary);
            width: 16px;
        }

        .table-actions {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
            cursor: pointer;
        }

        .btn-edit {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .btn-edit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        .btn-delete {
            background: linear-gradient(135deg, #e17055, #d63031);
            color: white;
            box-shadow: 0 4px 10px rgba(225, 112, 85, 0.2);
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(214, 48, 49, 0.3);
            background: linear-gradient(135deg, #d63031, #c0392b);
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .no-data h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        .no-data p {
            font-size: 1rem;
            color: var(--gray);
            margin-bottom: 20px;
        }

        /* Modals */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            border-radius: var(--card-radius);
            width: 500px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 25px 30px;
            border-bottom: 1px solid var(--light-gray);
            background: linear-gradient(135deg, rgba(108, 92, 231, 0.05), rgba(162, 155, 254, 0.05));
        }

        .modal-header h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header h3 i {
            color: var(--primary);
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray);
            cursor: pointer;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-btn:hover {
            background: var(--light-gray);
            color: var(--danger);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group label i {
            color: var(--primary);
            width: 16px;
        }

        .form-control {
            width: 100%;
            padding: 14px;
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 25px;
        }

        .btn-submit {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex: 1;
            font-size: 1rem;
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .btn-cancel {
            background: white;
            color: var(--gray);
            padding: 15px;
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex: 1;
            font-size: 1rem;
        }

        .btn-cancel:hover {
            background: var(--light-gray);
            color: var(--dark);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .main-content {
                padding: 20px;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 992px) {
            .admin-sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .admin-sidebar-header, .admin-info, .admin-nav-link span {
                display: none;
            }
            
            .admin-logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .admin-logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .admin-nav-link {
                justify-content: center;
                padding: 20px 0;
            }
            
            .admin-nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .stats-summary {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }
            
            .admin-sidebar.mobile-open {
                transform: translateX(0);
            }
            
            .mobile-menu-btn {
                display: flex;
            }
            
            .main-content {
                margin-left: 0 !important;
                padding: 15px !important;
            }
            
            .page-header {
                padding: 20px;
                flex-direction: column;
                align-items: flex-start;
            }
            
            .action-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .action-buttons {
                width: 100%;
                justify-content: stretch;
            }
            
            .btn-primary, .btn-secondary {
                flex: 1;
                justify-content: center;
            }
            
            .stats-summary {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            border-radius: var(--card-radius);
            color: white;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 3000;
            animation: slideInRight 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .toast.success {
            background: linear-gradient(135deg, var(--success), #00a085);
        }

        .toast.error {
            background: linear-gradient(135deg, var(--danger), #c0392b);
        }

        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        /* =========================================== */
        /* NOTIFICATION STYLES */
        /* =========================================== */
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            max-width: 400px;
        }

        .notification-toast {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-left: 5px solid;
            display: flex;
            align-items: center;
            gap: 15px;
            transform: translateX(120%);
            transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            animation: slideIn 0.5s forwards;
            position: relative;
            overflow: hidden;
        }

        .notification-toast::before {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 4px;
            background: currentColor;
            opacity: 0.2;
        }

        @keyframes slideIn {
            to {
                transform: translateX(0);
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
            }
            to {
                transform: translateX(120%);
            }
        }

        .notification-toast.hide {
            animation: slideOut 0.5s forwards;
        }

        .toast-icon {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .toast-message {
            font-size: 0.95rem;
            color: var(--gray);
            line-height: 1.5;
        }

        .toast-close {
            background: none;
            border: none;
            color: var(--gray);
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
            transition: var(--transition);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toast-close:hover {
            background: rgba(0, 0, 0, 0.05);
            color: var(--dark);
        }

        /* Success Toast */
        .notification-success {
            border-left-color: var(--success);
            background: linear-gradient(135deg, rgba(0, 184, 148, 0.05), rgba(0, 184, 148, 0.02));
        }

        .notification-success .toast-icon {
            background: linear-gradient(135deg, var(--success), #00a085);
            color: white;
        }

        /* Error Toast */
        .notification-error {
            border-left-color: var(--danger);
            background: linear-gradient(135deg, rgba(225, 112, 85, 0.05), rgba(225, 112, 85, 0.02));
        }

        .notification-error .toast-icon {
            background: linear-gradient(135deg, var(--danger), #d65a3d);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Notification Container -->
    <div class="notification-container" id="notificationContainer">
        <c:if test="${not empty successMessage}">
            <div class="notification-toast notification-success" id="successToast">
                <div class="toast-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Success!</div>
                    <div class="toast-message">${successMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('successToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
        
        <c:if test="${not empty errorMessage}">
            <div class="notification-toast notification-error" id="errorToast">
                <div class="toast-icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Error!</div>
                    <div class="toast-message">${errorMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('errorToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
    </div>
    
    <!-- Mobile Menu Button -->
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <div class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    ${user.username.substring(0, 1).toUpperCase()}
                </div>
                <div class="admin-info">
                    <h4>${user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link active">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <div class="header-content">
                    <h1><i class="fas fa-users"></i> Resident Management</h1>
                    <p>Manage all resident accounts, view details, and update information</p>
                </div>
            </div>

            <!-- Statistics -->
            <div class="stats-summary">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${totalResidents}</h3>
                        <p>Total Residents</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon block-a">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockA}</h3>
                        <p>Block A Residents</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon block-b">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockB}</h3>
                        <p>Block B Residents</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon block-c">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockC}</h3>
                        <p>Block C Residents</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search residents by name, email, or unit...">
                </div>
                <div class="action-buttons">
                    <button class="btn-primary" onclick="openModal('addModal')">
                        <i class="fas fa-user-plus"></i> Add New Resident
                    </button>
                </div>
            </div>

            <!-- Residents Table -->
            <div class="table-container">                
                <c:choose>
                    <c:when test="${not empty residentList}">
                        <table id="residentsTable">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-user"></i> Resident</th>
                                    <th><i class="fas fa-at"></i> Username</th>
                                    <th><i class="fas fa-envelope"></i> Email</th>
                                    <th><i class="fas fa-phone"></i> Phone</th>
                                    <th><i class="fas fa-home"></i> Unit</th>
                                    <th><i class="fas fa-cogs"></i> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="r" items="${residentList}">
                                    <tr>
                                        <td>
                                            <div class="resident-info">
                                                <div class="resident-avatar">
                                                    ${r.name.substring(0, 1).toUpperCase()}
                                                </div>
                                                <div class="resident-details">
                                                    <div class="resident-name">${r.name}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>${r.user.username}</td>
                                        <td>
                                            <div class="contact-info">
                                                <div class="contact-email">
                                                    <i class="fas fa-envelope"></i> ${r.email}
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="contact-info">
                                                <div class="contact-phone">
                                                    <i class="fas fa-phone"></i> ${r.phone}
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="unit-badge block-${r.unit.block.toLowerCase()}">
                                                ${r.unit.block}:${r.unit.floor}${r.unit.unit_number}
                                            </span>
                                        </td>
                                        <td>
                                                <div class="table-actions">
                                                    <button class="action-btn btn-edit" onclick="openUpdateModal(
                                                        ${r.resident_id},
                                                        '${r.user.username}',
                                                        '${r.name}',
                                                        '${r.phone}',
                                                        '${r.email}',
                                                        ${r.unit.unit_id}
                                                    )">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </button>
                                                    <button class="action-btn btn-delete" onclick="confirmDelete(${r.resident_id}, '${r.name}')">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </div>
                                            </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:when>
                    <c:otherwise>
                        <div class="no-data">
                            <i class="fas fa-users-slash"></i>
                            <h3>No Residents Found</h3>
                            <p>There are no residents registered in the system yet.</p>
                            <button class="btn-primary" onclick="openModal('addModal')" style="margin-top: 20px;">
                                <i class="fas fa-user-plus"></i> Add Your First Resident
                            </button>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>

    <!-- Add Resident Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-plus"></i> Add New Resident</h3>
                <button class="close-btn" onclick="closeModal('addModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="addForm" action="${pageContext.request.contextPath}/admin/resident">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username"><i class="fas fa-user"></i> Username</label>
                            <input type="text" id="username" name="username" class="form-control" placeholder="Enter username" required>
                        </div>
                        <div class="form-group">
                            <label for="password"><i class="fas fa-lock"></i> Password</label>
                            <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name"><i class="fas fa-id-card"></i> Full Name</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="Enter full name" required>
                        </div>
                        <div class="form-group">
                            <label for="phone"><i class="fas fa-phone"></i> Phone Number</label>
                            <input type="text" id="phone" name="phone" class="form-control" placeholder="Enter phone number">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" placeholder="Enter email address">
                    </div>
                    
                    <div class="form-group">
                        <label for="unitId"><i class="fas fa-home"></i> Unit Assignment</label>
                        <select id="unitId" name="unitId" class="form-control" required>
                            <option value="">-- Select Unit --</option>
                            <c:forEach var="unit" items="${unitList}">
                                <option value="${unit.unit_id}">${unit.block}-${unit.floor}${unit.unit_number}</option>
                            </c:forEach>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn-cancel" onclick="closeModal('addModal')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-user-plus"></i> Add Resident
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Update Resident Modal -->
    <div id="updateModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-user-edit"></i> Update Resident</h3>
                <button class="close-btn" onclick="closeModal('updateModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="updateForm" action="${pageContext.request.contextPath}/admin/resident">
                    <input type="hidden" name="residentId" id="updateResidentId">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="updateUsername"><i class="fas fa-user"></i> Username</label>
                            <input type="text" id="updateUsername" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="updatePassword"><i class="fas fa-lock"></i> Password</label>
                            <input type="password" id="updatePassword" name="password" class="form-control" placeholder="Leave blank to keep current">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="updateName"><i class="fas fa-id-card"></i> Full Name</label>
                            <input type="text" id="updateName" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="updatePhone"><i class="fas fa-phone"></i> Phone Number</label>
                            <input type="text" id="updatePhone" name="phone" class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="updateEmail"><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" id="updateEmail" name="email" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="updateUnitId"><i class="fas fa-home"></i> Unit Assignment</label>
                        <select id="updateUnitId" name="unitId" class="form-control" required>
                            <option value="">-- Select Unit --</option>
                            <c:forEach var="unit" items="${unitList}">
                                <option value="${unit.unit_id}">${unit.block}-${unit.floor}${unit.unit_number}</option>
                            </c:forEach>
                        </select>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn-cancel" onclick="closeModal('updateModal')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-save"></i> Update Resident
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Confirm Delete</h3>
                <button class="close-btn" onclick="closeModal('deleteModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p style="font-size: 1.1rem; margin-bottom: 15px;">
                    Are you sure you want to delete resident <strong id="deleteResidentName"></strong>?
                </p>
                <div style="background: #ffe6e6; padding: 15px; border-radius: 8px; margin-top: 20px; border-left: 4px solid #e17055;">
                    <i class="fas fa-exclamation-circle" style="color: #e17055; margin-right: 8px;"></i>
                    <strong>Warning:</strong> This action cannot be undone. All associated complaints and data will be permanently removed.
                </div>
            </div>
            <div class="modal-footer" style="display: flex; gap: 15px; margin-top: 20px; padding: 20px 30px; background: rgba(108, 92, 231, 0.02);">
                <button type="button" class="action-btn btn-edit" onclick="closeModal('deleteModal')" style="flex: 1; justify-content: center; padding: 12px; font-size: 0.95rem;">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <form method="post" action="${pageContext.request.contextPath}/admin/resident" style="flex: 1; display: block;">
                    <input type="hidden" name="deleteId" id="deleteResidentId">
                    <button type="submit" class="action-btn btn-delete" style="width: 100%; justify-content: center; padding: 12px; font-size: 0.95rem;">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // ... (keep all your JavaScript) ...
        // Mobile sidebar toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const adminSidebar = document.getElementById('adminSidebar');
        const mainContent = document.getElementById('mainContent');

        mobileMenuBtn.addEventListener('click', () => {
            adminSidebar.classList.toggle('mobile-open');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && !adminSidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                adminSidebar.classList.remove('mobile-open');
            }
        });

        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Open update modal with data
        function openUpdateModal(residentId, username, name, phone, email, unitId) {
            document.getElementById('updateResidentId').value = residentId;
            document.getElementById('updateUsername').value = username;
            document.getElementById('updateName').value = name;
            document.getElementById('updatePhone').value = phone || '';
            document.getElementById('updateEmail').value = email || '';
            document.getElementById('updateUnitId').value = unitId;

            openModal('updateModal');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const filter = this.value.toLowerCase();
                const rows = document.querySelectorAll('#residentsTable tbody tr');

                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(filter) ? '' : 'none';
                });
            });
        }

        // Global variables for delete operation
        let deleteResidentId = null;
        let deleteResidentName = null;

        // Delete Confirmation (opens modal)
        function confirmDelete(residentId, residentName) {
            deleteResidentId = residentId;
            deleteResidentName = residentName;

            // Update modal content
            document.getElementById('deleteResidentName').textContent = residentName;
            document.getElementById('deleteResidentId').value = residentId;

            // Open modal
            openModal('deleteModal');
        }

        // Form validation
        document.getElementById('addForm')?.addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long.');
            }
        });

        // Show success message if redirected from successful operation
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success')) {
                showToast('Resident operation completed successfully!', 'success');
            }
            if (urlParams.has('error')) {
                showToast('An error occurred. Please try again.', 'error');
            }
        };

        // Toast notification (for URL parameter messages)
        function showToast(message, type) {
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `
                <i class="fas fa-${type == 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                ${message}
            `;
            document.body.appendChild(toast);

            setTimeout(() => {
                toast.remove();
            }, 5000);
        }

        // Responsive sidebar adjustment
        function adjustSidebar() {
            if (window.innerWidth <= 768) {
                mainContent.style.marginLeft = '0';
                adminSidebar.classList.remove('mobile-open');
            } else if (window.innerWidth <= 992) {
                mainContent.style.marginLeft = '80px';
            } else {
                mainContent.style.marginLeft = '280px';
            }
        }

        window.addEventListener('resize', adjustSidebar);
        adjustSidebar(); // Initial call

        /**
         * Close notification toast
         */
        function closeNotification(toastId) {
            const toast = document.getElementById(toastId);
            if (toast) {
                toast.classList.add('hide');
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.remove();
                        // Hide container if empty
                        const container = document.getElementById('notificationContainer');
                        if (container && container.children.length === 0) {
                            container.style.display = 'none';
                        }
                    }
                }, 500);
            }
        }

        /**
         * Auto-close notifications after timeout
         */
        function autoCloseNotifications() {
            const successToast = document.getElementById('successToast');
            const errorToast = document.getElementById('errorToast');

            // Auto close success toast after 5 seconds
            if (successToast) {
                setTimeout(() => {
                    closeNotification('successToast');
                }, 5000);
            }

            // Auto close error toast after 7 seconds (give more time to read errors)
            if (errorToast) {
                setTimeout(() => {
                    closeNotification('errorToast');
                }, 7000);
            }
        }

        // Add keyboard support for closing notifications
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                // Close modals
                const modals = document.querySelectorAll('.modal');
                modals.forEach(modal => {
                    if (modal.style.display === 'flex') {
                        closeModal(modal.id);
                    }
                });

                // Close notifications
                const toasts = document.querySelectorAll('.notification-toast');
                toasts.forEach(toast => {
                    if (!toast.classList.contains('hide')) {
                        const toastId = toast.id;
                        if (toastId) {
                            closeNotification(toastId);
                        }
                    }
                });
            }
        });

        // Close notification when clicking on close button
        document.querySelectorAll('.toast-close').forEach(button => {
            button.addEventListener('click', function() {
                const toast = this.closest('.notification-toast');
                if (toast && toast.id) {
                    closeNotification(toast.id);
                }
            });
        });

        // Call autoCloseNotifications on page load
        document.addEventListener('DOMContentLoaded', function() {
            autoCloseNotifications();

            // Ensure notification container is visible if there are notifications
            const container = document.getElementById('notificationContainer');
            const hasNotifications = container && 
                (document.getElementById('successToast') || document.getElementById('errorToast'));

            if (container && hasNotifications) {
                container.style.display = 'block';
            }
        });
    </script>
</body>
</html>