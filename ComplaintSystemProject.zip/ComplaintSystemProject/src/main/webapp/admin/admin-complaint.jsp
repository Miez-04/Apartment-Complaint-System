<%@page import="java.text.SimpleDateFormat"%>
<%@ page import="java.sql.*, com.mycompany.controller.DBConnect, com.mycompany.model.User" %>
<%@ page session="true" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<!DOCTYPE html>
<html>
<head>
    <title>Complaints Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
            display: flex;
        }

        /* Sidebar Styles */
        .admin-sidebar {
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow);
            padding: 25px 0;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
            height: 100vh;
            position: sticky;
            top: 0;
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        .admin-nav-link.active::after {
            content: '';
            position: absolute;
            right: -10px;
            top: 50%;
            transform: translateY(-50%);
            width: 0;
            height: 0;
            border-top: 10px solid transparent;
            border-bottom: 10px solid transparent;
            border-right: 10px solid var(--primary);
        }

        .nav-badge {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
            max-width: calc(100% - 280px);
        }

        /* Header */
        .header {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header h1 i {
            font-size: 1.8rem;
        }

        .header p {
            color: var(--gray);
            font-size: 1.1rem;
            max-width: 600px;
            line-height: 1.6;
        }

        /* Stats */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-item {
            background: white;
            border-radius: var(--card-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-icon.pending { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-icon.progress { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-icon.resolved { background: linear-gradient(135deg, #00b894, #00a085); }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--dark);
            line-height: 1;
        }

        .stat-content p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Controls */
        .controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 30px;
        }

        .filters {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .filter-btn {
            padding: 12px 24px;
            background: white;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-weight: 600;
            color: var(--dark);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-btn:hover {
            border-color: var(--primary-light);
            background: rgba(108, 92, 231, 0.05);
            transform: translateY(-2px);
        }

        .filter-btn.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            border-color: var(--primary);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .search-box {
            position: relative;
            min-width: 300px;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 1.1rem;
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }

        th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
        }

        th:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 25%;
            height: 50%;
            width: 1px;
            background: rgba(255, 255, 255, 0.3);
        }

        tbody tr {
            transition: var(--transition);
            border-bottom: 1px solid var(--light-gray);
        }

        tbody tr:hover {
            background-color: rgba(108, 92, 231, 0.03);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td {
            padding: 20px;
            color: var(--dark);
            vertical-align: middle;
        }

        .complaint-title {
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .complaint-title i {
            color: var(--primary);
            font-size: 0.9rem;
        }

        .resident-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .resident-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .resident-name {
            font-weight: 500;
        }

        .category-badge {
            padding: 8px 16px;
            background: rgba(108, 92, 231, 0.1);
            color: var(--primary);
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: capitalize;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-width: 120px;
            justify-content: center;
        }

        .status-badge i {
            font-size: 0.8rem;
        }

        .status-pending {
            background: rgba(253, 203, 110, 0.1);
            color: #f39c12;
            border: 1px solid rgba(243, 156, 18, 0.2);
        }

        .status-in_progress {
            background: rgba(116, 185, 255, 0.1);
            color: #0984e3;
            border: 1px solid rgba(9, 132, 227, 0.2);
        }

        .status-resolved {
            background: rgba(0, 184, 148, 0.1);
            color: #00b894;
            border: 1px solid rgba(0, 184, 148, 0.2);
        }

        .status-rejected {
            background: rgba(225, 112, 85, 0.1);
            color: #e17055;
            border: 1px solid rgba(225, 112, 85, 0.2);
        }

        .date-time {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .date {
            font-weight: 500;
            color: var(--dark);
        }

        .time {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .unit-info {
            font-size: 0.9rem;
            color: var(--dark);
            font-weight: 500;
        }

        .unit-block {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
            cursor: pointer;
        }

        .btn-view {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        .btn-assign {
            background: linear-gradient(135deg, #fdcb6e, #f39c12);
            color: white;
            box-shadow: 0 4px 10px rgba(243, 156, 18, 0.2);
        }

        .btn-assign:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(243, 156, 18, 0.3);
            background: linear-gradient(135deg, #f39c12, #e67e22);
        }

        /* No Data */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
        }

        .no-data h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Export Section */
        .export-section {
            background: white;
            border-radius: var(--card-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        .export-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .export-header h3 {
            font-size: 1.3rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .export-options {
            display: flex;
            gap: 15px;
        }

        .export-btn {
            padding: 12px 24px;
            background: white;
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            font-weight: 600;
            color: var(--dark);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .export-btn:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateY(-2px);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 992px) {
            body {
                flex-direction: column;
            }
            
            .admin-sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px 0;
            }
            
            .main-content {
                max-width: 100%;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 20px;
            }
            
            .header-top {
                flex-direction: column;
                align-items: flex-start;
                gap: 20px;
            }
            
            .controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filters {
                justify-content: center;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .stats-summary {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }

        @media (max-width: 576px) {
            .stats-summary {
                grid-template-columns: 1fr;
            }
            
            .filter-btn {
                width: 100%;
                justify-content: center;
            }
            
            .export-options {
                flex-direction: column;
            }
            
            .export-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    ${fn:substring(user.username, 0, 1).toUpperCase()}
                </div>
                <div class="admin-info">
                    <h4>${user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link active">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header">
            <div class="header-top">
                <div>
                    <h1><i class="fas fa-file-lines"></i> Complaints Management</h1>
                </div>
            </div>
            
            <!-- Stats Summary -->
            <div class="stats-summary">
                <div class="stat-item">
                    <div class="stat-icon total">
                        <i class="fas fa-folder-open"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.totalComplaints}</h3>
                        <p>Total Complaints</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.pendingCount}</h3>
                        <p>Pending Review</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon progress">
                        <i class="fas fa-spinner"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.inProgressCount}</h3>
                        <p>In Progress</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon resolved">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.resolvedCount}</h3>
                        <p>Resolved</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <div class="controls">
            <div class="filters">
                <button class="filter-btn active" data-filter="all">
                    <i class="fas fa-layer-group"></i> All Complaints
                </button>
                <button class="filter-btn" data-filter="pending">
                    <i class="fas fa-clock"></i> Pending
                </button>
                <button class="filter-btn" data-filter="in_progress">
                    <i class="fas fa-spinner"></i> In Progress
                </button>
                <button class="filter-btn" data-filter="resolved">
                    <i class="fas fa-check"></i> Resolved
                </button>
                <button class="filter-btn" data-filter="rejected">
                    <i class="fas fa-times"></i> Rejected
                </button>
            </div>
            
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="searchInput" placeholder="Search complaints by title, resident, or category...">
            </div>
        </div>

        <!-- Table -->
        <div class="table-container">
            <c:choose>
                <c:when test="${empty complaints}">
                    <div class="no-data">
                        <i class="fas fa-inbox"></i>
                        <h3>No Complaints Found</h3>
                        <p>There are no complaints in the system yet. Check back later.</p>
                    </div>
                </c:when>
                <c:otherwise>
                    <table id="complaintsTable">
                        <thead>
                            <tr>
                                <th>Complaint Details</th>
                                <th>Resident</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Assigned To</th>
                                <th>Date & Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="complaint" items="${complaints}">
                                <tr class="complaint-row" 
                                    data-status="${complaint.status}" 
                                    data-resident="${fn:toLowerCase(complaint.residentName)}"
                                    data-category="${fn:toLowerCase(complaint.categoryName)}"
                                    data-title="${fn:toLowerCase(complaint.title)}"
                                    data-description="${fn:toLowerCase(complaint.description)}">
                                    <td>
                                        <div class="complaint-title">
                                            <i class="fas fa-file-alt"></i>
                                            ${complaint.title}
                                        </div>
                                        <div style="font-size: 0.85rem; color: var(--gray); margin-top: 5px;">
                                            <c:choose>
                                                <c:when test="${fn:length(complaint.description) > 100}">
                                                    ${fn:substring(complaint.description, 0, 100)}...
                                                </c:when>
                                                <c:otherwise>
                                                    ${complaint.description}
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="resident-info">
                                            <div class="resident-name">
                                                <i class="fas fa-user" style="color: var(--primary); margin-right: 5px;"></i>
                                                ${complaint.residentName}
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="category-badge">${complaint.categoryName}</span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-${complaint.status}">
                                            <i class="fas fa-circle"></i> 
                                            ${fn:replace(complaint.status, '_', ' ')}
                                        </span>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty complaint.staffName}">
                                                <div style="font-weight: 500; color: var(--dark);">
                                                    <i class="fas fa-user-tie" style="color: var(--primary); margin-right: 5px;"></i>
                                                    ${complaint.staffName}
                                                </div>
                                            </c:when>
                                            <c:otherwise>
                                                <span style="color: var(--gray); font-style: italic;">
                                                    <i class="fas fa-user-slash" style="margin-right: 5px;"></i> Not assigned
                                                </span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <div class="date-time">
                                            <span class="date">
                                                <fmt:formatDate value="${complaint.created_at}" pattern="dd MMM yyyy" />
                                            </span>
                                            <span class="time">
                                                <fmt:formatDate value="${complaint.created_at}" pattern="hh:mm a" />
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}" 
                                               class="action-btn btn-view" title="View Details">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </c:otherwise>
            </c:choose>
            
            <c:if test="${not empty error}">
                <div class="no-data" style="color: var(--danger);">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Failed to Load Complaints</h3>
                    <p>${error}</p>
                </div>
            </c:if>
        </div>
    </div>

    <script>
        // Filter functionality
        document.addEventListener('DOMContentLoaded', function() {
            const filterBtns = document.querySelectorAll('.filter-btn');
            const searchInput = document.getElementById('searchInput');
            const complaintRows = document.querySelectorAll('.complaint-row');
            
            // Filter by status
            filterBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');
                    
                    // Update active button
                    filterBtns.forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter rows
                    complaintRows.forEach(row => {
                        const status = row.getAttribute('data-status');
                        if(filter === 'all' || status === filter) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            });
            
            // Search functionality
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                complaintRows.forEach(row => {
                    const title = row.getAttribute('data-title');
                    const resident = row.getAttribute('data-resident');
                    const category = row.getAttribute('data-category');
                    const description = row.getAttribute('data-description');
                    
                    if(title.includes(searchTerm) || 
                       resident.includes(searchTerm) || 
                       category.includes(searchTerm) ||
                       description.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
            
            // Add row hover effects
            complaintRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
                });
                
                row.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.boxShadow = '';
                });
            });
        });
        
        // Export functions (same as before)
        function exportToCSV() {
            // Create CSV content
            let csv = [];
            let headers = [];
            
            // Get table headers
            document.querySelectorAll('#complaintsTable th').forEach(th => {
                headers.push(th.textContent.trim());
            });
            csv.push(headers.join(','));
            
            // Get table rows
            document.querySelectorAll('#complaintsTable tbody tr').forEach(row => {
                let rowData = [];
                row.querySelectorAll('td').forEach((cell, index) => {
                    // Skip action buttons column
                    if(index < 7) {
                        let text = cell.textContent.trim();
                        // Remove extra spaces and newlines
                        text = text.replace(/\s+/g, ' ');
                        // Handle commas in CSV
                        if(text.includes(',')) {
                            text = '"' + text + '"';
                        }
                        rowData.push(text);
                    }
                });
                csv.push(rowData.join(','));
            });
            
            // Create and download CSV file
            let csvContent = csv.join('\n');
            let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            let link = document.createElement('a');
            let url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'complaints_export_' + new Date().toISOString().split('T')[0] + '.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        
        function printTable() {
            let printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Print Complaints Report</title>');
            printWindow.document.write('<style>');
            printWindow.document.write('body { font-family: Arial, sans-serif; margin: 20px; }');
            printWindow.document.write('h1 { color: #6c5ce7; margin-bottom: 20px; }');
            printWindow.document.write('table { width: 100%; border-collapse: collapse; margin-top: 20px; }');
            printWindow.document.write('th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }');
            printWindow.document.write('th { background-color: #6c5ce7; color: white; }');
            printWindow.document.write('.print-date { margin-bottom: 20px; color: #666; }');
            printWindow.document.write('</style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h1>Complaints Report - Apartment Chempaka</h1>');
            printWindow.document.write('<div class="print-date">Generated on: ' + new Date().toLocaleString() + '</div>');
            printWindow.document.write(document.getElementById('complaintsTable').outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        }
    </script>
</body>
</html>