<%@page import="com.mycompany.model.User"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="com.mycompany.controller.DBConnect"%>
<%@page import="java.sql.Connection"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page session="true" %>

<!DOCTYPE html>
<html>
<head>
    <title>Apartment Unit Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Styles */
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 1000;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        .nav-badge {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1001;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 12px;
            font-size: 1.2rem;
            cursor: pointer;
            align-items: center;
            justify-content: center;
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            transition: var(--transition);
        }

        @media (max-width: 992px) {
            .admin-sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .admin-sidebar-header, .admin-info, .admin-nav-link span, .nav-badge {
                display: none;
            }
            
            .admin-logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .admin-logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .admin-nav-link {
                justify-content: center;
                padding: 20px 0;
            }
            
            .admin-nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }
            
            .admin-sidebar.mobile-open {
                transform: translateX(0);
            }
            
            .mobile-menu-btn {
                display: flex;
            }
            
            .main-content {
                margin-left: 0 !important;
                padding: 20px 15px !important;
            }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header */
        .header {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .header h1 i {
            font-size: 1.8rem;
        }

        .header p {
            color: var(--gray);
            font-size: 1.1rem;
            max-width: 600px;
            line-height: 1.6;
        }

        /* Stats */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-item {
            background: white;
            border-radius: var(--card-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-icon.block-a { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-icon.block-b { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-icon.block-c { background: linear-gradient(135deg, #00cec9, #00b894); }
        .stat-icon.occupied { background: linear-gradient(135deg, #800020, #d63031); }
        .stat-icon.vacant { background: linear-gradient(135deg, #6c5ce7, #5b4fcf); }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--dark);
            line-height: 1;
        }

        .stat-content p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Action Bar */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .search-box {
            position: relative;
            min-width: 300px;
            flex: 1;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 1.1rem;
        }

        .add-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .add-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }

        th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
        }

        th:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 25%;
            height: 50%;
            width: 1px;
            background: rgba(255, 255, 255, 0.3);
        }

        tbody tr {
            transition: var(--transition);
            border-bottom: 1px solid var(--light-gray);
        }

        tbody tr:hover {
            background-color: rgba(108, 92, 231, 0.03);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td {
            padding: 20px;
            color: var(--dark);
            vertical-align: middle;
        }

        .unit-code {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.2rem;
            margin-right: 15px;
        }

        .unit-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .unit-details {
            display: flex;
            flex-direction: column;
        }

        .unit-name {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
        }

        .unit-location {
            font-size: 0.9rem;
            color: var(--gray);
        }

        .block-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: white;
        }

        .floor-badge {
            padding: 6px 12px;
            background: rgba(108, 92, 231, 0.1);
            color: var(--primary);
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-occupied {
            background: rgba(225, 112, 85, 0.1);
            color: var(--danger);
            border: 1px solid rgba(225, 112, 85, 0.2);
        }

        .status-vacant {
            background: rgba(0, 184, 148, 0.1);
            color: var(--success);
            border: 1px solid rgba(0, 184, 148, 0.2);
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
            cursor: pointer;
        }

        .btn-edit {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .btn-edit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        .btn-delete {
            background: linear-gradient(135deg, #e17055, #d63031);
            color: white;
            box-shadow: 0 4px 10px rgba(225, 112, 85, 0.2);
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(214, 48, 49, 0.3);
            background: linear-gradient(135deg, #d63031, #c0392b);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background: white;
            padding: 40px;
            border-radius: var(--card-radius);
            width: 500px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .modal-header h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header h3 i {
            color: var(--primary);
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray);
            cursor: pointer;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-btn:hover {
            background: var(--light-gray);
            color: var(--danger);
            transform: rotate(90deg);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 14px;
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .submit-btn {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
            font-size: 1rem;
        }

        .submit-btn:hover {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* No Data */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
        }

        .no-data h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 20px;
            }
            
            .action-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .stats-summary {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
                margin-bottom: 40px;
            }

            .stat-item {
                background: white;
                border-radius: var(--card-radius);
                padding: 25px;
                display: flex;
                align-items: center;
                gap: 20px;
                box-shadow: var(--shadow);
                border: 1px solid var(--light-gray);
                transition: var(--transition);
                min-height: 120px;
            }

            .stat-item:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
            }

            .stat-icon {
                width: 60px;
                height: 60px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 1.8rem;
                flex-shrink: 0;
            }

            .stat-content h3 {
                font-size: 2.2rem;
                font-weight: 800;
                color: var(--dark);
                line-height: 1;
                margin-bottom: 5px;
            }

            .stat-content p {
                color: var(--gray);
                font-size: 0.95rem;
                font-weight: 500;
            }

            /* Stat icon colors */
            .stat-icon.total { 
                background: linear-gradient(135deg, var(--primary-light), var(--primary)); 
            }
            .stat-icon.occupied { 
                background: linear-gradient(135deg, #e17055, #d63031); 
            }
            .stat-icon.vacant { 
                background: linear-gradient(135deg, #00b894, #00a085); 
            }
            .stat-icon.block-a { 
                background: linear-gradient(135deg, #74b9ff, #0984e3); 
            }
            .stat-icon.block-b { 
                background: linear-gradient(135deg, #fdcb6e, #f39c12); 
            }
            .stat-icon.block-c { 
                background: linear-gradient(135deg, #00cec9, #00b894); 
            }

            /* Responsive adjustments */
            @media (max-width: 1200px) {
                .stats-summary {
                    grid-template-columns: repeat(2, 1fr);
                    gap: 15px;
                }
            }

            @media (max-width: 768px) {
                .stats-summary {
                    grid-template-columns: 1fr;
                    gap: 15px;
                }

                .stat-item {
                    padding: 20px;
                }

                .stat-icon {
                    width: 50px;
                    height: 50px;
                    font-size: 1.5rem;
                }

                .stat-content h3 {
                    font-size: 1.8rem;
                }
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
            
            .modal-content {
                padding: 25px;
            }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        /* =========================================== */
        /* NOTIFICATION STYLES */
        /* =========================================== */
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            max-width: 400px;
        }

        .notification-toast {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-left: 5px solid;
            display: flex;
            align-items: center;
            gap: 15px;
            transform: translateX(120%);
            transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            animation: slideIn 0.5s forwards;
            position: relative;
            overflow: hidden;
        }

        .notification-toast::before {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 4px;
            background: currentColor;
            opacity: 0.2;
        }

        @keyframes slideIn {
            to {
                transform: translateX(0);
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
            }
            to {
                transform: translateX(120%);
            }
        }

        .notification-toast.hide {
            animation: slideOut 0.5s forwards;
        }

        .toast-icon {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .toast-message {
            font-size: 0.95rem;
            color: var(--gray);
            line-height: 1.5;
        }

        .toast-close {
            background: none;
            border: none;
            color: var(--gray);
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
            transition: var(--transition);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toast-close:hover {
            background: rgba(0, 0, 0, 0.05);
            color: var(--dark);
        }

        /* Success Toast */
        .notification-success {
            border-left-color: var(--success);
            background: linear-gradient(135deg, rgba(0, 184, 148, 0.05), rgba(0, 184, 148, 0.02));
        }

        .notification-success .toast-icon {
            background: linear-gradient(135deg, var(--success), #00a085);
            color: white;
        }

        /* Error Toast */
        .notification-error {
            border-left-color: var(--danger);
            background: linear-gradient(135deg, rgba(225, 112, 85, 0.05), rgba(225, 112, 85, 0.02));
        }

        .notification-error .toast-icon {
            background: linear-gradient(135deg, var(--danger), #d65a3d);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Notification Container -->
    <div class="notification-container" id="notificationContainer">
        <c:if test="${not empty successMessage}">
            <div class="notification-toast notification-success" id="successToast">
                <div class="toast-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Success!</div>
                    <div class="toast-message">${successMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('successToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
        
        <c:if test="${not empty errorMessage}">
            <div class="notification-toast notification-error" id="errorToast">
                <div class="toast-icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Error!</div>
                    <div class="toast-message">${errorMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('errorToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
    </div>

    <!-- Mobile Menu Button -->
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <div class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    <c:choose>
                        <c:when test="${not empty user.username}">
                            ${user.username.substring(0, 1).toUpperCase()}
                        </c:when>
                        <c:otherwise>
                            A
                        </c:otherwise>
                    </c:choose>
                </div>
                <div class="admin-info">
                    <h4>${user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link active">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-building"></i> Apartment Unit Management</h1>
                <p>Manage all apartment units in the system. Add new units, update details, or remove units as needed.</p>
            </div>
            
            <!-- Stats Summary -->
            <div class="stats-summary">
                <div class="stat-item">
                    <div class="stat-icon total">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${totalUnits}</h3>
                        <p>Total Units</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon block-a">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockACount}</h3>
                        <p>Block A Units</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon block-b">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockBCount}</h3>
                        <p>Block B Units</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon block-c">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${blockCCount}</h3>
                        <p>Block C Units</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search units by block, floor, or unit number...">
                </div>
                <button class="add-btn" onclick="openModal('addModal')">
                    <i class="fas fa-plus-circle"></i> Add New Unit
                </button>
            </div>

            <!-- Units Table -->
            <div class="table-container">
                <c:choose>
                    <c:when test="${not empty units}">
                        <table id="unitsTable">
                            <thead>
                                <tr>
                                    <th>Unit Code</th>
                                    <th>Block</th>
                                    <th>Floor</th>
                                    <th>Unit Number</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="unit" items="${units}">
                                    <tr class="unit-row" 
                                        data-block="${unit.block.toLowerCase()}"
                                        data-floor="${unit.floor}"
                                        data-unit="${unit.unit_number.toLowerCase()}">
                                        <td>
                                            <div class="unit-info">
                                                <div class="unit-code">
                                                    ${unit.block}${unit.floor}${unit.unit_number}
                                                </div>
                                                <div class="unit-details">
                                                    <div class="unit-name">${unit.block}-${unit.floor}${unit.unit_number}</div>
                                                    <div class="unit-location">Block ${unit.block}, Floor ${unit.floor}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="block-badge" style="background: linear-gradient(135deg, 
                                                ${unit.block == 'A' ? '#74b9ff, #0984e3' : 
                                                  unit.block == 'B' ? '#fdcb6e, #f39c12' : 
                                                  '#00cec9, #00b894'}); color: white;">
                                                <i class="fas fa-building"></i>
                                                Block ${unit.block}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="floor-badge">
                                                <i class="fas fa-layer-group"></i>
                                                Floor ${unit.floor}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="unit-number">
                                                ${unit.unit_number}
                                            </div>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button type="button" class="action-btn btn-edit"
                                                    onclick="openUpdateModal(
                                                        ${unit.unit_id},
                                                        '${unit.block}',
                                                        ${unit.floor},
                                                        '${unit.unit_number}'
                                                    )">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                <button type="button" class="action-btn btn-delete"
                                                    onclick="confirmDelete(${unit.unit_id}, '${unit.block}${unit.floor}-${unit.unit_number}')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:when>
                    <c:otherwise>
                        <div class="no-data">
                            <i class="fas fa-building"></i>
                            <h3>No Apartment Units Found</h3>
                            <p>There are no apartment units in the system yet. Add your first unit to get started.</p>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>

    <!-- Add Unit Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus-circle"></i> Add New Unit</h3>
                <button class="close-btn" onclick="closeModal('addModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="post" action="${pageContext.request.contextPath}/admin/units" onsubmit="return validateAddForm()">
                <input type="hidden" name="action" value="add">
                <div class="form-row">
                    <div class="form-group">
                        <label for="addBlock">Block *</label>
                        <select id="addBlock" name="block" class="form-control" required>
                            <option value="">-- Select Block --</option>
                            <option value="A">Block A</option>
                            <option value="B">Block B</option>
                            <option value="C">Block C</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="addFloor">Floor *</label>
                        <input type="number" id="addFloor" name="floor" class="form-control" 
                               min="1" max="20" placeholder="Floor number" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="addUnitNumber">Unit Number *</label>
                    <input type="text" id="addUnitNumber" name="unit_number" class="form-control" 
                           placeholder="e.g., 01, 02, 101, 201" required>
                    <small style="color: var(--gray); margin-top: 5px; display: block;">
                        Enter 2-3 digits (e.g., 01, 12, 101)
                    </small>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-plus-circle"></i> Add Unit
                </button>
            </form>
        </div>
    </div>

    <!-- Update Unit Modal -->
    <div id="updateModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Update Unit Details</h3>
                <button class="close-btn" onclick="closeModal('updateModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="post" id="updateForm" action="${pageContext.request.contextPath}/admin/units" onsubmit="return validateUpdateForm()">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="unit_id" id="updateUnitId">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="updateBlock">Block *</label>
                        <select id="updateBlock" name="block" class="form-control" required>
                            <option value="">-- Select Block --</option>
                            <option value="A">Block A</option>
                            <option value="B">Block B</option>
                            <option value="C">Block C</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="updateFloor">Floor *</label>
                        <input type="number" id="updateFloor" name="floor" class="form-control" 
                               min="1" max="20" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="updateUnitNumber">Unit Number *</label>
                    <input type="text" id="updateUnitNumber" name="unit_number" class="form-control" required>
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-save"></i> Update Unit
                </button>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Confirm Delete</h3>
                <button class="close-btn" onclick="closeModal('deleteModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p style="font-size: 1.1rem; margin-bottom: 15px;">
                    Are you sure you want to delete unit <strong id="deleteUnitCode"></strong>?
                </p>
                <div style="background: #ffe6e6; padding: 15px; border-radius: 8px; margin-top: 20px; border-left: 4px solid #e17055;">
                    <i class="fas fa-exclamation-circle" style="color: #e17055; margin-right: 8px;"></i>
                    <strong>Warning:</strong> This action cannot be undone. If this unit has assigned residents or existing complaints, it cannot be deleted.
                </div>
            </div>
            <div class="modal-footer" style="display: flex; gap: 15px; margin-top: 20px;">
                <button type="button" class="action-btn btn-edit" onclick="closeModal('deleteModal')" style="flex: 1;">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <form method="post" action="${pageContext.request.contextPath}/admin/units" style="flex: 1;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="unit_id" id="deleteUnitId">
                    <button type="submit" class="action-btn btn-delete" style="width: 100%;">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.getElementById('adminSidebar');
            
            mobileMenuBtn.addEventListener('click', function() {
                sidebar.classList.toggle('mobile-open');
            });
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                if (window.innerWidth <= 768 && 
                    !sidebar.contains(event.target) && 
                    !mobileMenuBtn.contains(event.target) &&
                    sidebar.classList.contains('mobile-open')) {
                    sidebar.classList.remove('mobile-open');
                }
            });
            
            // Auto-close sidebar when clicking a link on mobile
            const navLinks = document.querySelectorAll('.admin-nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        sidebar.classList.remove('mobile-open');
                    }
                });
            });
        });

        // Modal Functions
        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        // Pre-fill Update Modal
        function openUpdateModal(unitId, block, floor, unitNumber) {
            document.getElementById('updateUnitId').value = unitId;
            document.getElementById('updateBlock').value = block;
            document.getElementById('updateFloor').value = floor;
            document.getElementById('updateUnitNumber').value = unitNumber;
            openModal('updateModal');
        }
        
        // Delete Confirmation
        function confirmDelete(unitId, unitCode) {
            document.getElementById('deleteUnitCode').textContent = unitCode;
            document.getElementById('deleteUnitId').value = unitId;
            openModal('deleteModal');
        }
        
        // Search Functionality
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const unitRows = document.querySelectorAll('.unit-row');
            
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                
                unitRows.forEach(row => {
                    const block = row.getAttribute('data-block');
                    const floor = row.getAttribute('data-floor');
                    const unit = row.getAttribute('data-unit');
                    const resident = row.getAttribute('data-resident');
                    
                    if (block.includes(searchTerm) || 
                        floor.includes(searchTerm) || 
                        unit.includes(searchTerm) || 
                        resident.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target.classList.contains('modal')) {
                    closeModal(event.target.id);
                }
            });
            
            // Add row hover effects
            unitRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
                });
                
                row.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.boxShadow = '';
                });
            });
            
            // Format unit number input
            const unitNumberInput = document.getElementById('addUnitNumber');
            if (unitNumberInput) {
                unitNumberInput.addEventListener('input', function() {
                    this.value = this.value.replace(/\D/g, '');
                    if (this.value.length > 3) {
                        this.value = this.value.slice(0, 3);
                    }
                });
            }
            
            const updateUnitNumberInput = document.getElementById('updateUnitNumber');
            if (updateUnitNumberInput) {
                updateUnitNumberInput.addEventListener('input', function() {
                    this.value = this.value.replace(/\D/g, '');
                    if (this.value.length > 3) {
                        this.value = this.value.slice(0, 3);
                    }
                });
            }
        });
        
        // Form validation
        function validateAddForm() {
            const block = document.getElementById('addBlock').value;
            const floor = document.getElementById('addFloor').value;
            const unitNumber = document.getElementById('addUnitNumber').value;
            
            if (!block || !floor || !unitNumber) {
                alert('Please fill in all required fields');
                return false;
            }
            
            if (floor < 1 || floor > 20) {
                alert('Floor must be between 1 and 20');
                return false;
            }
            
            if (!/^\d{2,3}$/.test(unitNumber)) {
                alert('Unit number should be 2-3 digits (e.g., 01, 101)');
                return false;
            }
            
            return true;
        }
        
        function validateUpdateForm() {
            const block = document.getElementById('updateBlock').value;
            const floor = document.getElementById('updateFloor').value;
            const unitNumber = document.getElementById('updateUnitNumber').value;
            
            if (!block || !floor || !unitNumber) {
                alert('Please fill in all required fields');
                return false;
            }
            
            if (floor < 1 || floor > 20) {
                alert('Floor must be between 1 and 20');
                return false;
            }
            
            if (!/^\d{2,3}$/.test(unitNumber)) {
                alert('Unit number should be 2-3 digits (e.g., 01, 101)');
                return false;
            }
            
            return true;
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const modals = document.querySelectorAll('.modal');
                modals.forEach(modal => {
                    if (modal.style.display === 'flex') {
                        closeModal(modal.id);
                    }
                });
            }
        });
        
        /**
        * Close notification toast
        */
       function closeNotification(toastId) {
           const toast = document.getElementById(toastId);
           if (toast) {
               toast.classList.add('hide');
               setTimeout(() => {
                   if (toast.parentElement) {
                       toast.remove();
                   }
               }, 500);
           }
       }

       /**
        * Auto-close notifications after 5 seconds
        */
       function autoCloseNotifications() {
           const successToast = document.getElementById('successToast');
           const errorToast = document.getElementById('errorToast');

           // Auto close success toast after 5 seconds
           if (successToast) {
               setTimeout(() => {
                   closeNotification('successToast');
               }, 5000);
           }

           // Auto close error toast after 7 seconds (give more time to read errors)
           if (errorToast) {
               setTimeout(() => {
                   closeNotification('errorToast');
               }, 7000);
           }
       }

       // Call autoCloseNotifications on page load
       document.addEventListener('DOMContentLoaded', function() {
           autoCloseNotifications();
       });
    </script>
</body>
</html>