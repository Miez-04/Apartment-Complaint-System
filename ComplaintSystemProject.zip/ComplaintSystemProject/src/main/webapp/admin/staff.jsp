<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Styles */
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 1000;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        .nav-badge {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1001;
            background: var(--primary);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 12px;
            font-size: 1.2rem;
            cursor: pointer;
            align-items: center;
            justify-content: center;
        }

        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            transition: var(--transition);
        }

        @media (max-width: 992px) {
            .admin-sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .admin-sidebar-header, .admin-info, .admin-nav-link span, .nav-badge {
                display: none;
            }
            
            .admin-logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .admin-logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .admin-nav-link {
                justify-content: center;
                padding: 20px 0;
            }
            
            .admin-nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
            }
            
            .admin-sidebar.mobile-open {
                transform: translateX(0);
            }
            
            .mobile-menu-btn {
                display: flex;
            }
            
            .main-content {
                margin-left: 0 !important;
                padding: 20px 15px !important;
            }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header */
        .header {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .header h1 i {
            font-size: 1.8rem;
        }

        .header p {
            color: var(--gray);
            font-size: 1.1rem;
            max-width: 600px;
            line-height: 1.6;
        }

        /* Stats */
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-item {
            background: white;
            border-radius: var(--card-radius);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            transition: var(--transition);
        }

        .stat-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-icon.plumber { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-icon.electrician { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-icon.cleaner { background: linear-gradient(135deg, #00cec9, #00b894); }
        .stat-icon.security { background: linear-gradient(135deg, #800020, #d63031); }
        .stat-icon.maintenance { background: linear-gradient(135deg, #6c5ce7, #5b4fcf); }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--dark);
            line-height: 1;
        }

        .stat-content p {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Action Bar */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .search-box {
            position: relative;
            min-width: 300px;
            flex: 1;
        }

        .search-box input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 2px solid var(--light-gray);
            border-radius: 12px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 1.1rem;
        }

        .add-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .add-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        thead {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
        }

        th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
        }

        th:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 25%;
            height: 50%;
            width: 1px;
            background: rgba(255, 255, 255, 0.3);
        }

        tbody tr {
            transition: var(--transition);
            border-bottom: 1px solid var(--light-gray);
        }

        tbody tr:hover {
            background-color: rgba(108, 92, 231, 0.03);
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        td {
            padding: 20px;
            color: var(--dark);
            vertical-align: middle;
        }

        .staff-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1rem;
            margin-right: 10px;
        }

        .staff-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .staff-details {
            display: flex;
            flex-direction: column;
        }

        .staff-name {
            font-weight: 600;
            color: var(--dark);
        }

        .staff-username {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .role-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: white;
        }

        .category-badge {
            padding: 8px 16px;
            background: rgba(108, 92, 231, 0.1);
            color: var(--primary);
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-active {
            background: rgba(0, 184, 148, 0.1);
            color: var(--success);
            border: 1px solid rgba(0, 184, 148, 0.2);
        }

        .status-inactive {
            background: rgba(225, 112, 85, 0.1);
            color: var(--danger);
            border: 1px solid rgba(225, 112, 85, 0.2);
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 10px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            border: none;
            cursor: pointer;
        }

        .btn-edit {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .btn-edit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(108, 92, 231, 0.3);
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        .btn-delete {
            background: linear-gradient(135deg, #e17055, #d63031);
            color: white;
            box-shadow: 0 4px 10px rgba(225, 112, 85, 0.2);
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(214, 48, 49, 0.3);
            background: linear-gradient(135deg, #d63031, #c0392b);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background: white;
            padding: 40px;
            border-radius: var(--card-radius);
            width: 500px;
            max-width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .modal-header h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-header h3 i {
            color: var(--primary);
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray);
            cursor: pointer;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-btn:hover {
            background: var(--light-gray);
            color: var(--danger);
            transform: rotate(90deg);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 14px;
            border: 2px solid var(--light-gray);
            border-radius: 10px;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        .submit-btn {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            margin-top: 20px;
            font-size: 1rem;
        }

        .submit-btn:hover {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* No Data */
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .no-data i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
        }

        .no-data h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--dark);
        }

        /* Responsive */
        @media (max-width: 1200px) {
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 20px;
            }
            
            .action-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .stats-summary {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .stats-summary {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                padding: 25px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        /* =========================================== */
        /* NOTIFICATION STYLES */
        /* =========================================== */
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            max-width: 400px;
        }

        .notification-toast {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border-left: 5px solid;
            display: flex;
            align-items: center;
            gap: 15px;
            transform: translateX(120%);
            transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            animation: slideIn 0.5s forwards;
            position: relative;
            overflow: hidden;
        }

        .notification-toast::before {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 4px;
            background: currentColor;
            opacity: 0.2;
        }

        @keyframes slideIn {
            to {
                transform: translateX(0);
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
            }
            to {
                transform: translateX(120%);
            }
        }

        .notification-toast.hide {
            animation: slideOut 0.5s forwards;
        }

        .toast-icon {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .toast-message {
            font-size: 0.95rem;
            color: var(--gray);
            line-height: 1.5;
        }

        .toast-close {
            background: none;
            border: none;
            color: var(--gray);
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
            transition: var(--transition);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toast-close:hover {
            background: rgba(0, 0, 0, 0.05);
            color: var(--dark);
        }

        /* Success Toast */
        .notification-success {
            border-left-color: var(--success);
            background: linear-gradient(135deg, rgba(0, 184, 148, 0.05), rgba(0, 184, 148, 0.02));
        }

        .notification-success .toast-icon {
            background: linear-gradient(135deg, var(--success), #00a085);
            color: white;
        }

        /* Error Toast */
        .notification-error {
            border-left-color: var(--danger);
            background: linear-gradient(135deg, rgba(225, 112, 85, 0.05), rgba(225, 112, 85, 0.02));
        }

        .notification-error .toast-icon {
            background: linear-gradient(135deg, var(--danger), #d65a3d);
            color: white;
        }
    </style>
</head>
<body>
    <!-- Notification Container -->
    <div class="notification-container" id="notificationContainer">
        <c:if test="${not empty successMessage}">
            <div class="notification-toast notification-success" id="successToast">
                <div class="toast-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Success!</div>
                    <div class="toast-message">${successMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('successToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
        
        <c:if test="${not empty errorMessage}">
            <div class="notification-toast notification-error" id="errorToast">
                <div class="toast-icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">Error!</div>
                    <div class="toast-message">${errorMessage}</div>
                </div>
                <button class="toast-close" onclick="closeNotification('errorToast')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </c:if>
    </div>
    
    <!-- Mobile Menu Button -->
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <div class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    ${fn:substring(user.username, 0, 1).toUpperCase()}
                </div>
                <div class="admin-info">
                    <h4>${user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link active">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-user-gear"></i> Staff Management</h1>
            </div>
            
            <!-- Stats Summary -->
            <div class="stats-summary">
                <div class="stat-item">
                    <div class="stat-icon total">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.totalStaff}</h3>
                        <p>Total Staff</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon plumber">
                        <i class="fas fa-wrench"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.plumber}</h3>
                        <p>Plumbers</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon electrician">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.electrician}</h3>
                        <p>Electricians</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon cleaner">
                        <i class="fas fa-broom"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.cleaner}</h3>
                        <p>Cleaners</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon security">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.security}</h3>
                        <p>Security Guards</p>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon maintenance">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div class="stat-content">
                        <h3>${stats.maintenance}</h3>
                        <p>Maintenance Staff</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search staff by name, username, or role...">
                </div>
                <button class="add-btn" onclick="openModal('addModal')">
                    <i class="fas fa-user-plus"></i> Add New Staff
                </button>
            </div>

            <!-- Staff Table -->
            <div class="table-container">
                <table id="staffTable">
                    <thead>
                        <tr>
                            <th>Staff Member</th>
                            <th>Contact</th>
                            <th>Role</th>
                            <th>Scope</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="staff" items="${staffList}">
                            <tr class="staff-row" 
                                data-staff-id="${staff.staff_id}"
                                data-name="${fn:toLowerCase(staff.name)}"
                                data-username="${fn:toLowerCase(staff.user.username)}"
                                data-role="${fn:toLowerCase(staff.role.role_name)}"
                                data-category="${fn:toLowerCase(staff.category.category_name)}">
                                <td>
                                    <div class="staff-info">
                                        <div class="staff-avatar">
                                            ${fn:substring(staff.name, 0, 1)}
                                        </div>
                                        <div class="staff-details">
                                            <div class="staff-name">${staff.name}</div>
                                            <div class="staff-username">@${staff.user.username}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <div style="font-weight: 500; margin-bottom: 5px;">${staff.user.username}</div>
                                        <div style="font-size: 0.9rem; color: var(--gray);">
                                            <i class="fas fa-phone" style="margin-right: 5px;"></i>
                                            ${not empty staff.phone ? staff.phone : 'Not provided'}
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${fn:containsIgnoreCase(staff.role.role_name, 'Plumb')}">
                                            <span class="role-badge" style="background: linear-gradient(135deg, #74b9ff, #0984e3); color: white;">
                                                <i class="fas fa-wrench"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:when>
                                        <c:when test="${fn:containsIgnoreCase(staff.role.role_name, 'Electr')}">
                                            <span class="role-badge" style="background: linear-gradient(135deg, #fdcb6e, #f39c12); color: white;">
                                                <i class="fas fa-bolt"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:when>
                                        <c:when test="${fn:containsIgnoreCase(staff.role.role_name, 'Clean')}">
                                            <span class="role-badge" style="background: linear-gradient(135deg, #00cec9, #00b894); color: white;">
                                                <i class="fas fa-broom"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:when>
                                        <c:when test="${fn:containsIgnoreCase(staff.role.role_name, 'Security') || fn:containsIgnoreCase(staff.role.role_name, 'Guard')}">
                                            <span class="role-badge" style="background: linear-gradient(135deg, #800020, #d63031); color: white;">
                                                <i class="fas fa-shield-alt"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:when>
                                        <c:when test="${fn:containsIgnoreCase(staff.role.role_name, 'Maintenance')}">
                                            <span class="role-badge" style="background: linear-gradient(135deg, #DAA520, #CD853F); color: white;">
                                                <i class="fas fa-tools"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="role-badge" style="background: linear-gradient(135deg, #a29bfe, #6c5ce7); color: white;">
                                                <i class="fas fa-user-tie"></i>
                                                ${staff.role.role_name}
                                            </span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>
                                    <span class="category-badge">
                                        <i class="fas fa-tag" style="margin-right: 5px;"></i>
                                        ${staff.category.category_name}
                                    </span>
                                </td>
                                <td>
                                    <span class="status-badge status-active">
                                        <i class="fas fa-circle" style="font-size: 0.6rem;"></i> Active
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button type="button" class="action-btn btn-edit"
                                            onclick="openUpdateModal(
                                                ${staff.staff_id},
                                                '${fn:escapeXml(staff.user.username)}',
                                                '${fn:escapeXml(staff.name)}',
                                                '${fn:escapeXml(staff.phone)}',
                                                ${staff.role.role_id},
                                                ${staff.category.category_id}
                                            )">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button type="button" class="action-btn btn-delete"
                                            onclick="confirmDelete(
                                                ${staff.staff_id},
                                                '${fn:escapeXml(staff.name)}',
                                                '${fn:escapeXml(staff.user.username)}'
                                            )">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>

                <c:if test="${empty staffList}">
                    <div class="no-data">
                        <i class="fas fa-user-slash"></i>
                        <h3>No Staff Members Found</h3>
                        <p>There are no staff members in the system yet. Add your first staff member to get started.</p>
                    </div>
                </c:if>
            </div>
        </div>
    </div>

    <!-- Add Staff Modal -->
<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> Add New Staff</h3>
            <button class="close-btn" onclick="closeModal('addModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="post" action="${pageContext.request.contextPath}/admin/staff" onsubmit="return validateAddStaffForm()">
            <input type="hidden" name="action" value="add">
            <div class="form-row">
                <div class="form-group">
                    <label for="addUsername">Username *</label>
                    <input type="text" id="addUsername" name="username" class="form-control" placeholder="Enter username" required>
                </div>
                <div class="form-group">
                    <label for="addPassword">Password *</label>
                    <input type="password" id="addPassword" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="addName">Full Name *</label>
                    <input type="text" id="addName" name="name" class="form-control" placeholder="Enter full name" required>
                </div>
                <div class="form-group">
                    <label for="addPhone">Phone Number</label>
                    <input type="tel" id="addPhone" name="phone" class="form-control" placeholder="Enter phone number">
                </div>
            </div>
            
            <div class="form-group">
                <label for="addRole">Role / Position *</label>
                <select id="addRole" name="role_id" class="form-control" required>
                    <option value="">-- Select Role --</option>
                    <c:forEach var="role" items="${roles}">
                        <option value="${role.role_id}">${role.role_name}</option>
                    </c:forEach>
                </select>
            </div>
            
            <div class="form-group">
                <label for="addCategory">Scope / Category *</label>
                <select id="addCategory" name="category_id" class="form-control" required>
                    <option value="">-- Select Category --</option>
                    <c:forEach var="category" items="${categories}">
                        <option value="${category.category_id}">${category.category_name}</option>
                    </c:forEach>
                </select>
            </div>
            
            <button type="submit" class="submit-btn">
                <i class="fas fa-user-plus"></i> Add Staff Member
            </button>
        </form>
    </div>
</div>

<!-- Update Staff Modal -->
<div id="updateModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-edit"></i> Update Staff Details</h3>
            <button class="close-btn" onclick="closeModal('updateModal')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="post" id="updateForm" action="${pageContext.request.contextPath}/admin/staff" onsubmit="return validateUpdateStaffForm()">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="staff_id" id="updateStaffId">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="updateUsername">Username *</label>
                    <input type="text" id="updateUsername" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="updatePassword">Password</label>
                    <input type="password" id="updatePassword" name="password" class="form-control" placeholder="Leave blank to keep current">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="updateName">Full Name *</label>
                    <input type="text" id="updateName" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="updatePhone">Phone Number</label>
                    <input type="tel" id="updatePhone" name="phone" class="form-control">
                </div>
            </div>
            
            <div class="form-group">
                <label for="updateRole">Role / Position *</label>
                <select id="updateRole" name="role_id" class="form-control" required>
                    <option value="">-- Select Role --</option>
                    <c:forEach var="role" items="${roles}">
                        <option value="${role.role_id}">${role.role_name}</option>
                    </c:forEach>
                </select>
            </div>
            
            <div class="form-group">
                <label for="updateCategory">Scope / Category</label>
                <select id="updateCategory" name="category_id" class="form-control">
                    <option value="">-- Select Category --</option>
                    <c:forEach var="category" items="${categories}">
                        <option value="${category.category_id}">${category.category_name}</option>
                    </c:forEach>
                </select>
            </div>
            
            <button type="submit" class="submit-btn">
                <i class="fas fa-save"></i> Update Staff Details
            </button>
        </form>
    </div>
</div>

   <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Confirm Delete</h3>
                <button class="close-btn" onclick="closeModal('deleteModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p style="font-size: 1.1rem; margin-bottom: 15px;">
                    Are you sure you want to delete staff member <strong id="deleteStaffName"></strong>?
                </p>
                <div style="background: #ffe6e6; padding: 15px; border-radius: 8px; margin-top: 20px; border-left: 4px solid #e17055;">
                    <i class="fas fa-exclamation-circle" style="color: #e17055; margin-right: 8px;"></i>
                    <strong>Warning:</strong> This action cannot be undone. This staff member will be permanently removed from the system.
                </div>
            </div>
            <div class="modal-footer" style="display: flex; gap: 15px; margin-top: 20px;">
                <button type="button" class="action-btn btn-edit" onclick="closeModal('deleteModal')" style="flex: 1;">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <form method="post" action="${pageContext.request.contextPath}/admin/staff" style="flex: 1;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="deleteId" id="deleteStaffId">
                    <button type="submit" class="action-btn btn-delete" style="width: 100%;">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            const sidebar = document.getElementById('adminSidebar');
            
            mobileMenuBtn.addEventListener('click', function() {
                sidebar.classList.toggle('mobile-open');
            });
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                if (window.innerWidth <= 768 && 
                    !sidebar.contains(event.target) && 
                    !mobileMenuBtn.contains(event.target) &&
                    sidebar.classList.contains('mobile-open')) {
                    sidebar.classList.remove('mobile-open');
                }
            });
            
            // Auto-close sidebar when clicking a link on mobile
            const navLinks = document.querySelectorAll('.admin-nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        sidebar.classList.remove('mobile-open');
                    }
                });
            });
            
            // Auto-remove notifications
            autoCloseNotifications();
            
            // Initialize search
            initSearch();
        });

        // Modal Functions
        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        // Delete Confirmation (opens modal)
        function confirmDelete(staffId, staffName, staffUsername) {
            document.getElementById('deleteStaffName').textContent = staffName + ' (@' + staffUsername + ')';
            document.getElementById('deleteStaffId').value = staffId;
            openModal('deleteModal');
        }
        
        // Pre-fill Update Modal
        function openUpdateModal(staffId, username, name, phone, roleId, categoryId) {
            document.getElementById('updateStaffId').value = staffId;
            document.getElementById('updateUsername').value = username;
            document.getElementById('updatePassword').value = '';
            document.getElementById('updateName').value = name;
            document.getElementById('updatePhone').value = phone || '';
            document.getElementById('updateRole').value = roleId;
            document.getElementById('updateCategory').value = categoryId;
            openModal('updateModal');
        }
        
        // Search Functionality
        function initSearch() {
            const searchInput = document.getElementById('searchInput');
            const staffRows = document.querySelectorAll('.staff-row');
            
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                
                staffRows.forEach(row => {
                    const name = row.getAttribute('data-name');
                    const username = row.getAttribute('data-username');
                    const role = row.getAttribute('data-role');
                    const category = row.getAttribute('data-category');
                    
                    if (name.includes(searchTerm) || 
                        username.includes(searchTerm) || 
                        role.includes(searchTerm) || 
                        category.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target.classList.contains('modal')) {
                    closeModal(event.target.id);
                }
            });
            
            // Add row hover effects
            staffRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                    this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
                });
                
                row.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                    this.style.boxShadow = '';
                });
            });
        }
        
        // Form validation
        function validateAddStaffForm() {
            const username = document.getElementById('addUsername').value;
            const password = document.getElementById('addPassword').value;
            const name = document.getElementById('addName').value;
            const role = document.getElementById('addRole').value;
            
            if (!username || !password || !name || !role) {
                alert('Please fill in all required fields');
                return false;
            }
            
            return true;
        }
        
        function validateUpdateStaffForm() {
            const username = document.getElementById('updateUsername').value;
            const name = document.getElementById('updateName').value;
            const role = document.getElementById('updateRole').value;
            
            if (!username || !name || !role) {
                alert('Please fill in all required fields');
                return false;
            }
            
            return true;
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const modals = document.querySelectorAll('.modal');
                modals.forEach(modal => {
                    if (modal.style.display === 'flex') {
                        closeModal(modal.id);
                    }
                });
            }
        });
        
        // Close notification function
        function closeNotification(toastId) {
            const toast = document.getElementById(toastId);
            if (toast) {
                toast.classList.add('hide');
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.remove();
                    }
                }, 500);
            }
        }

        // Auto-close notifications after 5 seconds
        function autoCloseNotifications() {
            const successToast = document.getElementById('successToast');
            const errorToast = document.getElementById('errorToast');

            if (successToast) {
                setTimeout(() => {
                    closeNotification('successToast');
                }, 5000);
            }

            if (errorToast) {
                setTimeout(() => {
                    closeNotification('errorToast');
                }, 7000);
            }
        }
    </script>
</body>
</html>