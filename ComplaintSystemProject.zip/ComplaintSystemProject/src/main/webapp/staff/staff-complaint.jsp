<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Complaints | Apartment Chempaka</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* All CSS from your interface design */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #e0dbff 0%, #d1c9ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .staff-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .staff-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
        }

        .staff-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .staff-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            text-align: center;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }

        .stat-card.total::before { background: linear-gradient(to bottom, var(--primary-light), var(--primary)); }
        .stat-card.pending::before { background: linear-gradient(to bottom, #fdcb6e, #f39c12); }
        .stat-card.progress::before { background: linear-gradient(to bottom, #74b9ff, #0984e3); }
        .stat-card.resolved::before { background: linear-gradient(to bottom, #00b894, #00a085); }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 1.8rem;
            color: white;
        }

        .stat-card.total .stat-icon { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-card.pending .stat-icon { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-card.progress .stat-icon { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-card.resolved .stat-icon { background: linear-gradient(135deg, #00b894, #00a085); }

        .stat-card h3 {
            font-size: 0.95rem;
            color: var(--gray);
            margin-bottom: 10px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card .value {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .stat-card .trend {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* Complaints Container */
        .complaints-container {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-header h2 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-header h2 i {
            color: var(--primary);
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--gray);
        }

        .filter-select {
            padding: 10px 15px;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            background: white;
            color: var(--dark);
            font-size: 0.95rem;
            transition: all 0.3s ease;
            min-width: 180px;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.1);
        }

        /* Complaints Table */
        .complaints-table-container {
            overflow-x: auto;
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .complaints-table thead {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
        }

        .complaints-table th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: white;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .complaints-table th i {
            margin-right: 8px;
        }

        .complaints-table tbody tr {
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .complaints-table tbody tr:hover {
            background-color: #f9f9ff;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .complaints-table td {
            padding: 18px 20px;
            color: var(--dark);
        }

        .complaint-title {
            font-weight: 600;
            font-size: 1.05rem;
            color: var(--dark);
        }

        .complaint-title a {
            color: var(--dark);
            text-decoration: none;
            transition: all 0.2s;
        }

        .complaint-title a:hover {
            color: var(--primary);
            text-decoration: underline;
        }

        .resident-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .resident-avatar {
            width: 36px;
            height: 36px;
            background: var(--light-gray);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark);
            font-size: 0.9rem;
            font-weight: 600;
        }

        .resident-name {
            font-weight: 500;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
            text-transform: capitalize;
        }

        .status-pending {
            background-color: #fff4e6;
            color: #f39c12;
        }

        .status-in_progress {
            background-color: #e3f2fd;
            color: #0984e3;
        }

        .status-resolved {
            background-color: #e8f6f3;
            color: #00b894;
        }

        .status-rejected {
            background-color: #ffeaea;
            color: #d63031;
        }

        .date-cell {
            color: var(--gray);
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .action-btn {
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .view-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
        }

        .view-btn:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .update-btn {
            background: #fff4e6;
            color: #f39c12;
        }

        .update-btn:hover {
            background: #fdebd0;
            transform: translateY(-2px);
        }

        .resolve-btn {
            background: #e8f6f3;
            color: #00b894;
        }

        .resolve-btn:hover {
            background: #d4efdf;
            transform: translateY(-2px);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
            color: var(--primary-light);
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 30px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Alert Styles */
        .alert {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s ease;
        }

        .alert-error {
            background-color: #ffeaea;
            color: #d63031;
            border-left: 4px solid #d63031;
        }

        .alert-success {
            background-color: #e8f6f3;
            color: #00b894;
            border-left: 4px solid #00b894;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .sidebar-header, .staff-info, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .stats-cards {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .filter-section {
                flex-direction: column;
            }
            
            .filter-select {
                min-width: 100%;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .complaints-container {
                padding: 20px;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 8px;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .complaints-table th, 
            .complaints-table td {
                padding: 15px 10px;
            }
            
            .stat-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <i class="fas fa-building-circle-check"></i>
                <div class="logo-text">
                    <h2>Chempaka</h2>
                    <p>Staff Portal</p>
                </div>
            </div>
            
            <div class="staff-profile">
                <div class="staff-avatar">
                    ${staffName != null && !staffName.isEmpty() ? staffName.charAt(0) : username.charAt(0)}
                </div>
                <div class="staff-info">
                    <h4>${staffName != null ? staffName : username}</h4>
                    <p>Staff</p>
                </div>
            </div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/staff/staff-complaints" class="nav-link active">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Assigned Complaints</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/profile" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h1>Assigned Complaints</h1>
                <p>Manage complaints assigned to you</p>
            </div>
            
            <button class="logout-btn" onclick="window.location.href='${pageContext.request.contextPath}/logout'">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-cards">
            <div class="stat-card total">
                <div class="stat-icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <h3>Total Complaints</h3>
                <div class="value">${statusCounts.total}</div>
            </div>
            
            <div class="stat-card pending">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>Pending</h3>
                <div class="value">${statusCounts.pending}</div>
            </div>
            
            <div class="stat-card progress">
                <div class="stat-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <h3>In Progress</h3>
                <div class="value">${statusCounts.in_progress}</div>
            </div>
            
            <div class="stat-card resolved">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>Resolved</h3>
                <div class="value">${statusCounts.resolved}</div>
            </div>
        </div>

        <!-- Complaints Container -->
        <div class="complaints-container">
            <div class="section-header">
                <h2><i class="fas fa-clipboard-check"></i> All Assigned Complaints</h2>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <div class="filter-group">
                    <label class="filter-label">Filter by Status</label>
                    <select class="filter-select" id="statusFilter">
                        <option value="all">All Statuses</option>
                        <option value="pending">Pending</option>
                        <option value="in_progress">In Progress</option>
                        <option value="resolved">Resolved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Sort by</label>
                    <select class="filter-select" id="sortFilter">
                        <option value="newest">Newest First</option>
                        <option value="oldest">Oldest First</option>
                        <option value="title">Title (A-Z)</option>
                        <option value="resident">Resident (A-Z)</option>
                    </select>
                </div>
            </div>

            <c:if test="${not empty error}">
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> ${error}
                </div>
            </c:if>

            <c:choose>
                <c:when test="${not empty complaints}">
                    <!-- Complaints Table -->
                    <div class="complaints-table-container">
                        <table class="complaints-table">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-heading"></i> Title</th>
                                    <th><i class="fas fa-user"></i> Resident</th>
                                    <th><i class="fas fa-info-circle"></i> Status</th>
                                    <th><i class="fas fa-calendar"></i> Date Created</th>
                                    <th><i class="fas fa-tools"></i> Actions</th>
                                </tr>
                            </thead>
                            <tbody id="complaintsTableBody">
                                <c:forEach var="complaint" items="${complaints}">
                                    <tr data-status="${complaint.status}" 
                                        data-title="${complaint.title}" 
                                        data-resident="${complaint.residentName}"
                                        data-date="${complaint.created_at.time}">
                                        <td class="complaint-title">
                                            <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}&staff_id=${staffId}">
                                                ${complaint.title}
                                            </a>
                                        </td>
                                        <td>
                                            <div class="resident-info">
                                                <div class="resident-avatar">
                                                    ${complaint.residentName != null && !complaint.residentName.isEmpty() ? complaint.residentName.charAt(0) : 'R'}
                                                </div>
                                                <div class="resident-name">
                                                    ${complaint.residentName}
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-${complaint.status}">
                                                <c:choose>
                                                    <c:when test="${complaint.status == 'in_progress'}">In Progress</c:when>
                                                    <c:when test="${complaint.status == 'resolved'}">Resolved</c:when>
                                                    <c:otherwise>${complaint.status}</c:otherwise>
                                                </c:choose>
                                            </span>
                                        </td>
                                        <td class="date-cell">
                                            <fmt:formatDate value="${complaint.created_at}" pattern="dd MMM yyyy" />
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}&staff_id=${staffId}" 
                                                   class="action-btn view-btn">
                                                    <i class="fas fa-eye"></i> View Details
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </c:when>
                <c:otherwise>
                    <!-- Empty State -->
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Complaints Assigned</h3>
                        <p>You don't have any complaints assigned to you at the moment.</p>
                        <div style="margin-top: 20px;">
                            <a href="${pageContext.request.contextPath}/dashboard" 
                               class="action-btn view-btn" 
                               style="padding: 12px 24px; font-size: 1rem;">
                                <i class="fas fa-tachometer-alt"></i> Back to Dashboard
                            </a>
                        </div>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Filter functionality
            const statusFilter = document.getElementById('statusFilter');
            const sortFilter = document.getElementById('sortFilter');
            const tableRows = document.querySelectorAll('#complaintsTableBody tr');
            
            function filterAndSortComplaints() {
                const statusValue = statusFilter.value;
                const sortValue = sortFilter.value;
                
                let visibleRows = [];
                
                // Filter rows
                tableRows.forEach(row => {
                    const status = row.getAttribute('data-status');
                    
                    let showRow = true;
                    
                    // Status filter
                    if (statusValue !== 'all' && status !== statusValue) {
                        showRow = false;
                    }
                    
                    if (showRow) {
                        row.style.display = '';
                        visibleRows.push(row);
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                // Sort rows
                const tbody = document.getElementById('complaintsTableBody');
                const sortedRows = Array.from(visibleRows);
                
                sortedRows.sort((a, b) => {
                    const titleA = a.getAttribute('data-title').toLowerCase();
                    const titleB = b.getAttribute('data-title').toLowerCase();
                    const residentA = a.getAttribute('data-resident').toLowerCase();
                    const residentB = b.getAttribute('data-resident').toLowerCase();
                    const dateA = parseInt(a.getAttribute('data-date'));
                    const dateB = parseInt(b.getAttribute('data-date'));
                    
                    switch(sortValue) {
                        case 'newest':
                            return dateB - dateA;
                        case 'oldest':
                            return dateA - dateB;
                        case 'title':
                            return titleA.localeCompare(titleB);
                        case 'resident':
                            return residentA.localeCompare(residentB);
                        default:
                            return 0;
                    }
                });
                
                // Reorder rows in DOM
                sortedRows.forEach(row => {
                    tbody.appendChild(row);
                });
            }
            
            // Add event listeners to filters
            if (statusFilter) statusFilter.addEventListener('change', filterAndSortComplaints);
            if (sortFilter) sortFilter.addEventListener('change', filterAndSortComplaints);
            
            // Add animation to stat cards
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
            
            // Add ripple effect to action buttons
            const actionBtns = document.querySelectorAll('.action-btn');
            actionBtns.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    const ripple = document.createElement('span');
                    const rect = this.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    const x = e.clientX - rect.left - size/2;
                    const y = e.clientY - rect.top - size/2;
                    
                    ripple.style.cssText = `
                        position: absolute;
                        border-radius: 50%;
                        background: rgba(255, 255, 255, 0.5);
                        transform: scale(0);
                        animation: ripple 0.6s linear;
                        width: ${size}px;
                        height: ${size}px;
                        top: ${y}px;
                        left: ${x}px;
                        pointer-events: none;
                    `;
                    
                    this.appendChild(ripple);
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 600);
                });
            });
            
            // Add CSS for ripple animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes ripple {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }
                
                .action-btn {
                    position: relative;
                    overflow: hidden;
                }
            `;
            document.head.appendChild(style);
            
            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        if (alert.parentNode) {
                            alert.parentNode.removeChild(alert);
                        }
                    }, 500);
                }, 5000);
            });
        });
        
        function resolveComplaint(complaintId) {
            if (confirm('Are you sure you want to mark this complaint as resolved?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '${pageContext.request.contextPath}/staff/staff-complaints';
                
                const complaintIdInput = document.createElement('input');
                complaintIdInput.type = 'hidden';
                complaintIdInput.name = 'complaint_id';
                complaintIdInput.value = complaintId;
                form.appendChild(complaintIdInput);
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'resolve';
                form.appendChild(actionInput);
                
                const messageInput = document.createElement('input');
                messageInput.type = 'hidden';
                messageInput.name = 'message';
                messageInput.value = 'Complaint has been resolved.';
                form.appendChild(messageInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>