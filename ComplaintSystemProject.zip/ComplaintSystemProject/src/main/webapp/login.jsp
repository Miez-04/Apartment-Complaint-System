<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Apartment Chempaka Complaint System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #e0dbff 0%, #d1c9ff 100%);
            min-height: 100vh;
            color: var(--dark);
            color: var(--dark);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(108, 92, 231, 0.1);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .welcome-section {
            flex: 1;
            background: linear-gradient(rgba(139, 128, 249, 0.85), rgba(108, 92, 231, 0.9)), url('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }

        .apartment-badge {
            position: absolute;
            top: 30px;
            left: 30px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .welcome-section h1 {
            font-size: 2.3rem;
            margin-bottom: 15px;
            font-weight: 700;
            line-height: 1.2;
        }

        .welcome-section .highlight {
            color: #fffacd;
            font-weight: 800;
        }

        .welcome-section p {
            font-size: 1.1rem;
            line-height: 1.6;
            opacity: 0.95;
            margin-top: 20px;
        }

        .feature-list {
            margin-top: 30px;
            list-style: none;
        }

        .feature-list li {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            padding: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            backdrop-filter: blur(5px);
        }

        .feature-list i {
            margin-right: 12px;
            color: #d4c2ff;
            font-size: 1.2rem;
            min-width: 24px;
        }

        .login-section {
            flex: 1;
            background-color: white;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            color: #6c5ce7;
        }

        .logo i {
            font-size: 2.5rem;
            margin-right: 15px;
            background: linear-gradient(135deg, #a29bfe, #6c5ce7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2d3436;
        }

        .logo-text p {
            color: #636e72;
            font-size: 0.9rem;
            margin-top: 4px;
        }

        .login-header h3 {
            font-size: 1.8rem;
            color: #2d3436;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .login-header p {
            color: #636e72;
            margin-bottom: 35px;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a29bfe;
            font-size: 1.1rem;
        }

        .input-with-icon input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #dfe6e9;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
        }

        .input-with-icon input:focus {
            outline: none;
            border-color: #a29bfe;
            background-color: white;
            box-shadow: 0 0 0 4px rgba(162, 155, 254, 0.1);
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 0.95rem;
        }

        .remember {
            display: flex;
            align-items: center;
        }

        .remember input {
            margin-right: 8px;
            accent-color: #6c5ce7;
        }

        .forgot-password {
            color: #6c5ce7;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }

        .forgot-password:hover {
            text-decoration: underline;
            color: #5b4fcf;
        }

        .login-button {
            background: linear-gradient(to right, #a29bfe, #6c5ce7);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
            width: 100%;
            margin-top: 10px;
            letter-spacing: 0.5px;
        }

        .login-button:hover {
            background: linear-gradient(to right, #8c7df7, #5b4fcf);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .login-button:active {
            transform: translateY(0);
        }

        .divider {
            text-align: center;
            margin: 30px 0;
            position: relative;
            color: #b2bec3;
            font-size: 0.9rem;
        }

        .divider::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(to right, transparent, #dfe6e9, transparent);
            z-index: 1;
        }

        .divider span {
            background-color: white;
            padding: 0 20px;
            position: relative;
            z-index: 2;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
            color: #636e72;
        }

        .register-link a {
            color: #6c5ce7;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s;
        }

        .register-link a:hover {
            text-decoration: underline;
            color: #5b4fcf;
        }

        .error-message {
            background-color: #ffeaea;
            color: #d63031;
            padding: 14px 18px;
            border-radius: 10px;
            margin-top: 25px;
            text-align: center;
            border-left: 4px solid #d63031;
            display: ${empty error ? 'none' : 'block'};
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .footer-note {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            text-align: center;
            color: #b2bec3;
            font-size: 0.85rem;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                max-width: 500px;
            }
            
            .welcome-section {
                padding: 40px 30px;
                min-height: 300px;
            }
            
            .apartment-badge {
                top: 20px;
                left: 20px;
            }
            
            .login-section {
                padding: 40px 30px;
            }
            
            .footer-note {
                position: relative;
                margin-top: 30px;
                bottom: auto;
            }
        }
    </style>
</head>

<body>

<div class="container">
    <!-- Left Welcome Section -->
    <div class="welcome-section">
        <div class="apartment-badge">
            <i class="fas fa-building"></i>
            Luxury Living
        </div>
        
        <h1>Welcome to <span class="highlight">Apartment Chempaka</span> Complaint System</h1>
        <p>Your comfort is our priority. Report issues, track resolutions, and enhance your living experience with our seamless platform.</p>
        
        <ul class="feature-list">
            <li><i class="fas fa-bolt"></i> Quick complaint submission</li>
            <li><i class="fas fa-history"></i> Real-time status tracking</li>
            <li><i class="fas fa-shield-alt"></i> Secure & confidential platform</li>
        </ul>
    </div>

    <!-- Right Login Section -->
    <div class="login-section">
        <div class="logo">
            <i class="fas fa-building-circle-check"></i>
            <div class="logo-text">
                <h2>Chempaka Portal</h2>
                <p>Resident Login System</p>
            </div>
        </div>

        <div class="login-header">
            <h3>Sign In to Your Account</h3>
            <p>Enter your credentials to access the complaint system</p>
        </div>

        <form action="login" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-with-icon">
                    <i class="fas fa-user-circle"></i>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-with-icon">
                    <i class="fas fa-key"></i>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
            </div>        

            <button type="submit" class="login-button">
                <i class="fas fa-sign-in-alt" style="margin-right: 8px;"></i> Sign In
            </button>
        </form>

        <div class="error-message" id="errorMessage">${error}</div>

        <div class="divider"><span>New to Chempaka Apartments?</span></div>

        <div class="register-link">
            Need an account? <a href="register">Register Here</a>
        </div>
        
        <div class="footer-note">
            © 2025 Apartment Chempaka Complaint System. All rights reserved.
        </div>
    </div>
</div>

<script>
    // Show error message with animation if present
    document.addEventListener('DOMContentLoaded', function() {
        const errorMessage = document.getElementById('errorMessage');
        const errorText = '${error}';
        
        if (errorText && errorText.trim() !== '') {
            errorMessage.style.display = 'block';
        }
        
        // Add focus effects to inputs
        const inputs = document.querySelectorAll('input[type="text"], input[type="password"]');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.parentElement.querySelector('label').style.color = '#6c5ce7';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.parentElement.querySelector('label').style.color = '#555';
                }
            });
        });
        
        // Add some visual feedback on form submission
        const form = document.querySelector('form');
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('.login-button');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...';
            submitBtn.disabled = true;
        });
    });
</script>

</body>
</html>