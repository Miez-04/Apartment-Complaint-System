<%@page import="java.util.List"%>
<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Apartment Chempaka Complaint System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(to right, #a29bfe, #6c5ce7, #a29bfe);
            z-index: 1;
        }

        .container {
            display: flex;
            max-width: 1100px;
            width: 100%;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(108, 92, 231, 0.15);
            animation: fadeIn 0.8s ease-out;
            position: relative;
            z-index: 2;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .illustration-section {
            flex: 1;
            background: linear-gradient(rgba(139, 128, 249, 0.85), rgba(108, 92, 231, 0.9)), 
                        url('https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }

        .illustration-content {
            text-align: center;
        }

        .illustration-content i {
            font-size: 4rem;
            margin-bottom: 25px;
            color: #fffacd;
            opacity: 0.9;
        }

        .illustration-content h1 {
            font-size: 2.2rem;
            margin-bottom: 20px;
            font-weight: 700;
            line-height: 1.3;
        }

        .illustration-content p {
            font-size: 1.1rem;
            line-height: 1.6;
            opacity: 0.95;
            margin-bottom: 30px;
        }

        .benefit-list {
        margin-top: 30px;
        text-align: left;
        list-style: none;
        padding: 0;
    }

    .benefit-list li {
        margin-bottom: 15px;
        display: flex;
        align-items: flex-start; /* Changed from center to flex-start */
        font-size: 1rem;
        padding: 8px 0;
        line-height: 0.5; /* Add line-height for consistent text */
    }

    .benefit-list i {
        font-size: 1.2rem;
        margin-right: 12px;
        color: #d4c2ff;
        min-width: 24px;
        display: flex; /* Add this */
        align-items: center; /* Add this */
        justify-content: center; /* Add this */
        height: 0.5em; /* Match text line-height */
    }

        .register-section {
            flex: 1.2;
            background-color: white;
            padding: 50px 45px;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            max-height: 90vh;
        }

        .register-header {
            margin-bottom: 30px;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            color: #6c5ce7;
        }

        .logo i {
            font-size: 2.3rem;
            margin-right: 15px;
            background: linear-gradient(135deg, #a29bfe, #6c5ce7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.7rem;
            font-weight: 700;
            color: #2d3436;
        }

        .logo-text p {
            color: #636e72;
            font-size: 0.9rem;
            margin-top: 2px;
        }

        .register-header h3 {
            font-size: 1.8rem;
            color: #2d3436;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .register-header .subtitle {
            color: #636e72;
            margin-bottom: 25px;
            font-size: 1rem;
        }

        .form-container {
            flex-grow: 1;
        }

        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .required::after {
            content: " *";
            color: #e74c3c;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a29bfe;
            font-size: 1.1rem;
            z-index: 2;
        }

        .input-with-icon input, 
        .input-with-icon select {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 2px solid #dfe6e9;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
            color: #333;
        }

        .input-with-icon select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236c5ce7' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 15px;
            padding-right: 40px;
        }

        .input-with-icon input:focus,
        .input-with-icon select:focus {
            outline: none;
            border-color: #a29bfe;
            background-color: white;
            box-shadow: 0 0 0 4px rgba(162, 155, 254, 0.1);
        }

        .input-with-icon input::placeholder {
            color: #95a5a6;
        }

        .password-strength {
            margin-top: 8px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #636e72;
        }

        .strength-meter {
            flex-grow: 1;
            height: 6px;
            background-color: #dfe6e9;
            border-radius: 3px;
            overflow: hidden;
        }

        .strength-fill {
            height: 100%;
            width: 0;
            border-radius: 3px;
            transition: width 0.3s ease, background-color 0.3s ease;
        }

        .terms {
            margin: 25px 0;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #a29bfe;
        }

        .terms label {
            display: flex;
            align-items: flex-start;
            font-size: 0.95rem;
            color: #555;
            cursor: pointer;
        }

        .terms input {
            margin-right: 12px;
            margin-top: 3px;
            accent-color: #6c5ce7;
        }

        .terms a {
            color: #6c5ce7;
            text-decoration: none;
            font-weight: 500;
        }

        .terms a:hover {
            text-decoration: underline;
        }

        .register-button {
            background: linear-gradient(to right, #a29bfe, #6c5ce7);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
            width: 100%;
            margin-top: 10px;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .register-button:hover {
            background: linear-gradient(to right, #8c7df7, #5b4fcf);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .register-button:active {
            transform: translateY(0);
        }

        .login-link {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #636e72;
            font-size: 0.95rem;
        }

        .login-link a {
            color: #6c5ce7;
            text-decoration: none;
            font-weight: 600;
            margin-left: 5px;
            transition: all 0.2s;
        }

        .login-link a:hover {
            text-decoration: underline;
            color: #5b4fcf;
        }

        .error-message {
            background-color: #ffeaea;
            color: #d63031;
            padding: 14px 18px;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
            border-left: 4px solid #d63031;
            animation: slideIn 0.5s ease-out;
            display: <%= request.getAttribute("error") != null ? "block" : "none" %>;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 14px 18px;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
            border-left: 4px solid #c3e6cb;
            animation: slideIn 0.5s ease-out;
            display: <%= request.getAttribute("success") != null ? "block" : "none" %>;
        }

        @media (max-width: 900px) {
            .container {
                flex-direction: column;
                max-width: 600px;
            }
            
            .illustration-section {
                padding: 40px 30px;
                min-height: 300px;
            }
            
            .register-section {
                padding: 40px 30px;
                max-height: none;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }

        @media (max-width: 480px) {
            .container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .illustration-section,
            .register-section {
                padding: 30px 20px;
            }
            
            .register-header h3 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>

<div class="container">
    <!-- Left Illustration Section -->
    <div class="illustration-section">
        <div class="illustration-content">
            <i class="fas fa-user-plus"></i>
            <h1>Join Apartment Chempaka Community</h1>
            <p>Register now to access our complaint management system and enjoy harmony life in Apartment Chempaka.</p>
            
            <ul class="benefit-list">
                <li><i class="fas fa-bolt"></i> Quick issue reporting and tracking</li>
                <li><i class="fas fa-clock"></i> Real-time status updates</li>
                <li><i class="fas fa-star"></i> Priority support for registered residents</li>
            </ul>
        </div>
    </div>

    <!-- Right Registration Form -->
    <div class="register-section">
        <div class="register-header">
            <div class="logo">
                <i class="fas fa-building-circle-check"></i>
                <div class="logo-text">
                    <h2>Chempaka Registration</h2>
                    <p>Create Your Resident Account</p>
                </div>
            </div>
            
            <h3>Create Your Account</h3>
            <p class="subtitle">Fill in your details to join our community</p>
        </div>

        <div class="form-container">
            <form action="register" method="post" id="registrationForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="username" class="required">Username</label>
                        <div class="input-with-icon">
                            <i class="fas fa-user-circle"></i>
                            <input type="text" id="username" name="username" placeholder="Choose a username" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="name" class="required">Full Name</label>
                        <div class="input-with-icon">
                            <i class="fas fa-user"></i>
                            <input type="text" id="name" name="name" placeholder="Your full name" required>
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email" class="required">Email Address</label>
                        <div class="input-with-icon">
                            <i class="fas fa-envelope"></i>
                            <input type="email" id="email" name="email" placeholder="your.email@example.com" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone" class="required">Phone Number</label>
                        <div class="input-with-icon">
                            <i class="fas fa-phone"></i>
                            <input type="text" id="phone" name="phone" placeholder="012-3456789" required>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password" class="required">Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Create a secure password" required>
                    </div>
                    <div class="password-strength">
                        <span>Password strength:</span>
                        <div class="strength-meter">
                            <div class="strength-fill" id="strengthFill"></div>
                        </div>
                        <span id="strengthText">Weak</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="unit_id" class="required">Apartment Unit</label>
                    <div class="input-with-icon">
                        <i class="fas fa-home"></i>
                        <select id="unit_id" name="unit_id" required>
                            <option value="">Select Your Unit</option>
                            <%
                                List<com.mycompany.model.ApartmentUnit> units = 
                                    (List<com.mycompany.model.ApartmentUnit>) request.getAttribute("units");
                                if (units != null) {
                                    for (com.mycompany.model.ApartmentUnit unit : units) {
                            %>
                                        <option value="<%= unit.getUnit_id() %>">
                                            Block <%= unit.getBlock() %> | Floor <%= unit.getFloor() %> | Unit <%= unit.getUnit_number() %>
                                        </option>
                            <%      }
                                } else { %>
                                    <option disabled>No units available</option>
                            <% } %>
                        </select>
                    </div>
                </div>

                                
                <button type="submit" class="register-button">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>
            
            <% if (request.getAttribute("error") != null) { %>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <%= request.getAttribute("error") %>
                </div>
            <% } %>
            
            <% if (request.getAttribute("success") != null) { %>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> <%= request.getAttribute("success") %>
                </div>
            <% } %>
            
            <div class="login-link">
                Already have an account? <a href="login">Sign in here</a>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Password strength indicator
        const passwordInput = document.getElementById('password');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            // Check password strength
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            // Update strength meter
            const strengthPercent = strength * 25;
            strengthFill.style.width = strengthPercent + '%';
            
            // Update colors and text
            if (strength === 0) {
                strengthFill.style.backgroundColor = '#e74c3c';
                strengthText.textContent = 'Weak';
                strengthText.style.color = '#e74c3c';
            } else if (strength <= 2) {
                strengthFill.style.backgroundColor = '#f39c12';
                strengthText.textContent = 'Fair';
                strengthText.style.color = '#f39c12';
            } else if (strength === 3) {
                strengthFill.style.backgroundColor = '#3498db';
                strengthText.textContent = 'Good';
                strengthText.style.color = '#3498db';
            } else {
                strengthFill.style.backgroundColor = '#2ecc71';
                strengthText.textContent = 'Strong';
                strengthText.style.color = '#2ecc71';
            }
        });
        
        // Form submission animation
        const form = document.getElementById('registrationForm');
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('.register-button');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
            submitBtn.disabled = true;
        });
        
        // Input focus effects
        const inputs = document.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.borderColor = '#a29bfe';
                this.parentElement.previousElementSibling.style.color = '#6c5ce7';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.borderColor = '#dfe6e9';
                if (!this.value) {
                    this.parentElement.previousElementSibling.style.color = '#555';
                }
            });
        });
        
        // Phone number formatting for format: 011-12345678
        const phoneInput = document.getElementById('phone');
        phoneInput.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');

            if (value.length > 0) {
                // Format as XXX-XXXXXXXX for total 11 digits (3 + 8)
                if (value.length <= 3) {
                    this.value = value;
                } else if (value.length <= 11) {
                    this.value = value.slice(0, 3) + '-' + value.slice(3, 11);
                }
            }
        });

        // Set maxlength to 12 characters (11 digits + 1 dash)
        phoneInput.setAttribute('maxlength', '12');

        // Optional: Add placeholder for user guidance
        phoneInput.setAttribute('placeholder', '012-34567891');
            });
</script>

</body>
</html>