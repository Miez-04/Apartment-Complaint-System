<%@ page import="java.sql.*, java.util.*" %>
<%@ page import="com.mycompany.controller.DBConnect" %>
<%@ page import="com.mycompany.model.User" %>
<%@ page import="com.mycompany.model.Resident" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page session="true" contentType="text/html;charset=UTF-8" %>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Apartment Chempaka Complaint System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar Navigation */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
            line-height: 1; /* prevents text stretching */
            overflow: hidden;
        }



        .user-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .user-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Dashboard Stats */
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }

        .stat-card.total::before { background: linear-gradient(to bottom, var(--primary-light), var(--primary)); }
        .stat-card.pending::before { background: linear-gradient(to bottom, #fdcb6e, #f39c12); }
        .stat-card.progress::before { background: linear-gradient(to bottom, #74b9ff, #0984e3); }
        .stat-card.resolved::before { background: linear-gradient(to bottom, #00b894, #00a085); }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            font-size: 1.8rem;
            color: white;
        }

        .stat-card.total .stat-icon { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-card.pending .stat-icon { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-card.progress .stat-icon { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-card.resolved .stat-icon { background: linear-gradient(135deg, #00b894, #00a085); }

        .stat-card h3 {
            font-size: 0.95rem;
            color: var(--gray);
            margin-bottom: 10px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card .value {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .stat-card .trend {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* Recent Complaints */
        .recent {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .recent h3 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .recent table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .recent th {
            background: #f8f9fa;
            padding: 16px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gray);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid var(--light-gray);
        }

        .recent td {
            padding: 18px 15px;
            border-bottom: 1px solid var(--light-gray);
            color: var(--dark);
        }

        .recent tr:hover {
            background-color: #f9f9ff;
        }

        .recent td a {
            color: var(--dark);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }

        .recent td a:hover {
            color: var(--primary);
            text-decoration: underline;
        }

        .status {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
            text-transform: capitalize;
        }

        .status.pending {
            background-color: #fff4e6;
            color: #f39c12;
        }

        .status.in_progress {
            background-color: #e3f2fd;
            color: #0984e3;
        }

        .status.resolved {
            background-color: #e8f6f3;
            color: #00b894;
        }

        /* Quick Actions */
        .links {
            text-align: center;
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .links a {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin: 10px;
            padding: 15px 25px;
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        .links a:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        .links a i {
            font-size: 1.1rem;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .sidebar-header, .user-info, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .links {
                flex-direction: column;
                align-items: center;
            }
            
            .links a {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .sidebar {
                transform: translateX(-100%);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .recent {
                padding: 20px;
                overflow-x: auto;
            }
            
            .recent table {
                min-width: 500px;
            }
        }

        @media (max-width: 576px) {
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .stat-card {
                padding: 20px;
            }
            
            .recent h3 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>

 <!-- Sidebar Navigation -->
<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-building-circle-check"></i>
            <div class="logo-text">
                <h2>Chempaka</h2>
                <p>Resident Portal</p>
            </div>
        </div>

        <div class="user-profile">
            <div class="user-avatar">
                ${resident.name != null && !resident.name.isEmpty() ? resident.name.charAt(0) : resident.user.username.charAt(0)}
            </div>
            <div class="user-info">
                <h4>${resident.name != null ? resident.name : resident.user.username}</h4>
                <p>Resident</p>
            </div>
        </div>
    </div>

    <ul class="nav-menu">
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/dashboard" class="nav-link active">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/resident/submitComplaint" class="nav-link">
                <i class="fas fa-plus-circle"></i>
                <span>New Complaint</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/resident/myComplaint" class="nav-link">
                <i class="fas fa-list-alt"></i>
                <span>My Complaints</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="${pageContext.request.contextPath}/profile" class="nav-link">
                <i class="fas fa-user-cog"></i>
                <span>Profile</span>
            </a>
        </li>
    </ul>
</div>

<!-- Main Content -->
<div class="main-content">
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="page-title">
            <h1>Welcome back, ${resident.name}!</h1>
            <p>Here's an overview of your complaint status</p>
        </div>
        <button class="logout-btn" onclick="window.location.href='${pageContext.request.contextPath}/logout'">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </div>

    <!-- Dashboard Stats -->
    <div class="dashboard-stats">
        <div class="stat-card total">
            <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
            <h3>Total Complaints</h3>
            <div class="value">${stats.total}</div>
            <div class="trend">All submitted issues</div>
        </div>

        <div class="stat-card pending">
            <div class="stat-icon"><i class="fas fa-clock"></i></div>
            <h3>Pending</h3>
            <div class="value">${stats.pending}</div>
            <div class="trend">Awaiting review</div>
        </div>

        <div class="stat-card progress">
            <div class="stat-icon"><i class="fas fa-tasks"></i></div>
            <h3>In Progress</h3>
            <div class="value">${stats.in_progress}</div>
            <div class="trend">Being addressed</div>
        </div>

        <div class="stat-card resolved">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <h3>Resolved</h3>
            <div class="value">${stats.resolved}</div>
            <div class="trend">Completed issues</div>
        </div>
    </div>

    <!-- Recent Complaints -->
    <div class="recent">
        <h3>Recent Complaints</h3>
        <table>
            <tr>
                <th>Title</th>
                <th>Status</th>
                <th>Date Submitted</th>
            </tr>
            <c:forEach var="complaint" items="${complaints}">
                <tr>
                    <td>
                        <a href="${pageContext.request.contextPath}/resident/complaint-detail?complaint_id=${complaint.complaint_id}">
                            ${complaint.title}
                        </a>
                    </td>
                    <td>
                        <span class="status ${complaint.status}">
                            ${complaint.status.replace("_", " ")}
                        </span>
                    </td>
                    <td>
                        <fmt:formatDate value="${complaint.created_at}" pattern="dd MMM yyyy" />
                    </td>
                </tr>
            </c:forEach>

            <c:if test="${empty complaints}">
                <tr>
                    <td colspan="3" style="text-align: center; padding: 40px; color: var(--gray);">
                        <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                        No complaints submitted yet. Submit your first complaint to get started!
                    </td>
                </tr>
            </c:if>
        </table>
    </div>

    <!-- Quick Action Links -->
    <div class="links">
        <a href="${pageContext.request.contextPath}/resident/submitComplaint">
            <i class="fas fa-plus-circle"></i> Submit New Complaint
        </a>
        <a href="${pageContext.request.contextPath}/resident/myComplaint">
            <i class="fas fa-list-alt"></i> View All Complaints
        </a>
        <a href="${pageContext.request.contextPath}/profile">
            <i class="fas fa-user-cog"></i> Update Profile
        </a>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Animate stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });

        // Hover effect for table rows
        const tableRows = document.querySelectorAll('.recent tr:not(:first-child)');
        tableRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f9f9ff';
            });
            row.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    });
</script>

</body>
</html>