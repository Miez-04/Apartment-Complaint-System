<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard | Apartment Chempaka</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --card-radius: 16px;
        }

        body {
            background: linear-gradient(135deg, #e0dbff 0%, #d1c9ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 260px;
            background: white;
            box-shadow: var(--shadow);
            padding: 25px 0;
            z-index: 100;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .logo i {
            font-size: 2rem;
            margin-right: 12px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text h2 {
            font-size: 1.4rem;
            font-weight: 700;
        }

        .logo-text p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        .staff-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .staff-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.3rem;
        }

        .staff-info h4 {
            font-size: 1rem;
            margin-bottom: 3px;
        }

        .staff-info p {
            font-size: 0.85rem;
            color: var(--gray);
        }

        .nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
            width: 24px;
            color: var(--primary);
        }

        .nav-link:hover {
            background-color: #f0eeff;
            color: var(--primary);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .nav-link.active i {
            color: white;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .page-title h1 {
            font-size: 2rem;
            color: var(--dark);
            font-weight: 700;
        }

        .page-title p {
            color: var(--gray);
            margin-top: 5px;
        }

        .logout-btn {
            background: linear-gradient(to right, #e17055, #d63031);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 5px 15px rgba(225, 112, 85, 0.2);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(225, 112, 85, 0.3);
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: var(--card-radius);
            padding: 40px;
            color: white;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }

        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        }

        .welcome-content {
            position: relative;
            z-index: 2;
        }

        .welcome-content h2 {
            font-size: 2.2rem;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .welcome-content p {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .date-display {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-top: 15px;
            backdrop-filter: blur(5px);
        }

        /* Dashboard Stats */
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 25px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            text-align: center;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }

        .stat-card.total::before { background: linear-gradient(to bottom, var(--primary-light), var(--primary)); }
        .stat-card.pending::before { background: linear-gradient(to bottom, #fdcb6e, #f39c12); }
        .stat-card.progress::before { background: linear-gradient(to bottom, #74b9ff, #0984e3); }
        .stat-card.resolved::before { background: linear-gradient(to bottom, #00b894, #00a085); }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 1.8rem;
            color: white;
        }

        .stat-card.total .stat-icon { background: linear-gradient(135deg, var(--primary-light), var(--primary)); }
        .stat-card.pending .stat-icon { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-card.progress .stat-icon { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-card.resolved .stat-icon { background: linear-gradient(135deg, #00b894, #00a085); }

        .stat-card h3 {
            font-size: 0.95rem;
            color: var(--gray);
            margin-bottom: 10px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card .value {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .stat-card .trend {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* Recent Complaints Section */
        .recent-section {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-header h2 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-header h2 i {
            color: var(--primary);
        }

        .view-all {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: all 0.2s;
        }

        .view-all:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        /* Complaints Table Container */
        .complaints-table-container {
            overflow-x: auto;
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .complaints-table thead {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
        }

        .complaints-table th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            color: white;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .complaints-table th i {
            margin-right: 8px;
        }

        .complaints-table tbody tr {
            border-bottom: 1px solid var(--light-gray);
            transition: all 0.3s ease;
        }

        .complaints-table tbody tr:hover {
            background-color: #f9f9ff;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .complaints-table td {
            padding: 18px 20px;
            color: var(--dark);
        }

        .complaint-title {
            font-weight: 600;
            font-size: 1.05rem;
            color: var(--dark);
        }

        .complaint-title a {
            color: var(--dark);
            text-decoration: none;
            transition: all 0.2s;
        }

        .complaint-title a:hover {
            color: var(--primary);
            text-decoration: underline;
        }

        .resident-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .resident-avatar {
            width: 36px;
            height: 36px;
            background: var(--light-gray);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark);
            font-size: 0.9rem;
            font-weight: 600;
        }

        .resident-name {
            font-weight: 500;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
            text-transform: capitalize;
        }

        .status-pending {
            background-color: #fff4e6;
            color: #f39c12;
        }

        .status-in_progress {
            background-color: #e3f2fd;
            color: #0984e3;
        }

        .status-resolved {
            background-color: #e8f6f3;
            color: #00b894;
        }

        .status-rejected {
            background-color: #ffeaea;
            color: #d63031;
        }

        .date-cell {
            color: var(--gray);
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s ease;
        }

        .view-btn {
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            color: white;
        }

        .view-btn:hover {
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .action-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--dark);
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(108, 92, 231, 0.15);
            background: linear-gradient(to right, #f0eeff, white);
        }

        .action-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 1.8rem;
        }

        .action-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .action-card p {
            color: var(--gray);
            font-size: 0.95rem;
            line-height: 1.5;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
            color: var(--primary-light);
        }

        .empty-state h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--dark);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 30px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Alert Styles */
        .alert {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s ease;
        }

        .alert-error {
            background-color: #ffeaea;
            color: #d63031;
            border-left: 4px solid #d63031;
        }

        .alert-success {
            background-color: #e8f6f3;
            color: #00b894;
            border-left: 4px solid #00b894;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 20px 0;
            }

            .sidebar-header, .staff-info, .nav-link span {
                display: none;
            }

            .logo {
                justify-content: center;
                margin-bottom: 30px;
            }

            .logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }

            .nav-link {
                justify-content: center;
                padding: 18px 0;
            }

            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }

            .main-content {
                margin-left: 80px;
                padding: 20px;
            }

            .dashboard-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 20px 15px;
            }

            .sidebar {
                transform: translateX(-100%);
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .welcome-banner {
                padding: 30px 20px;
            }

            .welcome-content h2 {
                font-size: 1.8rem;
            }

            .dashboard-stats {
                grid-template-columns: 1fr;
            }

            .recent-section {
                padding: 20px;
            }

            .complaints-table {
                min-width: 700px;
            }

            .section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .action-buttons {
                flex-direction: column;
                gap: 8px;
            }

            .action-btn {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .stat-card {
                padding: 20px;
            }

            .action-card {
                padding: 20px;
            }

            .welcome-content h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <i class="fas fa-building-circle-check"></i>
                <div class="logo-text">
                    <h2>Chempaka</h2>
                    <p>Staff Portal</p>
                </div>
            </div>
            
            <div class="staff-profile">
                <div class="staff-avatar">
                    ${staffName != null && !staffName.isEmpty() ? staffName.charAt(0) : username.charAt(0)}
                </div>
                <div class="staff-info">
                    <h4>${staffName != null ? staffName : username}</h4>
                    <p>Staff</p>
                </div>
            </div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="nav-link active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/staff/staff-complaints" class="nav-link">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Assigned Complaints</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/profile" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="page-title">
                <h1>Staff Dashboard</h1>
                <p>Monitor your assigned complaints and performance</p>
            </div>
            
            <button class="logout-btn" onclick="window.location.href='${pageContext.request.contextPath}/logout'">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div class="welcome-content">
                <h2>Welcome Back, ${staffName}!</h2>
                <p>${roleName} 
                    <c:if test="${department != null && !department.isEmpty()}">
                        | ${department} Department
                    </c:if>
                </p>
                <div class="date-display">
                    <i class="fas fa-calendar-alt"></i> ${todayDate}
                </div>
            </div>
        </div>

        <!-- Dashboard Stats -->
        <div class="dashboard-stats">
            <div class="stat-card total">
                <div class="stat-icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
                <h3>Total Complaints</h3>
                <div class="value">${stats.total}</div>
            </div>
            
            <div class="stat-card pending">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>Pending</h3>
                <div class="value">${stats.pending}</div>
            </div>
            
            <div class="stat-card progress">
                <div class="stat-icon">
                    <i class="fas fa-tasks"></i>
                </div>
                <h3>In Progress</h3>
                <div class="value">${stats.in_progress}</div>
            </div>
            
            <div class="stat-card resolved">
                <div class="stat-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>Resolved</h3>
                <div class="value">${stats.resolved}</div>
            </div>
        </div>

        <!-- Recent Complaints -->
        <div class="recent-section">
            <div class="section-header">
                <h2><i class="fas fa-history"></i> Recent Complaints</h2>
                <a href="${pageContext.request.contextPath}/staff/staff-complaints" class="view-all">
                    View All <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <c:choose>
                <c:when test="${not empty recentComplaints}">
                    <div class="complaints-table-container">
                        <table class="complaints-table">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-heading"></i> Complaint</th>
                                    <th><i class="fas fa-user"></i> Resident</th>
                                    <th><i class="fas fa-info-circle"></i> Status</th>
                                    <th><i class="fas fa-calendar"></i> Date</th>
                                    <th><i class="fas fa-tools"></i> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="complaint" items="${recentComplaints}">
                                    <tr>
                                        <td>
                                            <div class="complaint-title">
                                                <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}&staff_id=${staffId}">
                                                    ${complaint.title}
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="resident-info">
                                                <div class="resident-avatar">
                                                    ${complaint.residentName != null && !complaint.residentName.isEmpty() ? complaint.residentName.charAt(0) : 'R'}
                                                </div>
                                                <div class="resident-name">
                                                    ${complaint.residentName}
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-${complaint.status}">
                                                <c:choose>
                                                    <c:when test="${complaint.status == 'in_progress'}">In Progress</c:when>
                                                    <c:when test="${complaint.status == 'resolved'}">Resolved</c:when>
                                                    <c:otherwise>${complaint.status}</c:otherwise>
                                                </c:choose>
                                            </span>
                                        </td>
                                        <td class="date-cell">
                                            <fmt:formatDate value="${complaint.created_at}" pattern="dd MMM yyyy" />
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="${pageContext.request.contextPath}/complaint-detail?complaint_id=${complaint.complaint_id}&staff_id=${staffId}" 
                                                   class="action-btn view-btn">
                                                    <i class="fas fa-eye"></i> View
                                                </a>                                            
                                            </div>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </c:when>
                <c:otherwise>
                    <!-- Empty State -->
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Complaints Assigned</h3>
                        <p>You don't have any complaints assigned to you yet. Check back later or contact your supervisor.</p>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="${pageContext.request.contextPath}/staff/staff-complaint" class="action-card">
                <div class="action-icon">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <h3>Assign Complaints</h3>
                <p>View and update all complaints assigned to you</p>
            </a>
            
            <a href="${pageContext.request.contextPath}/profile" class="action-card">
                <div class="action-icon">
                    <i class="fas fa-user-edit"></i>
                </div>
                <h3>Update Profile</h3>
                <p>Manage your personal information and contact details</p>
            </a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
        // Add animation to stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';

            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });

        // Add hover effects to action cards
        const actionCards = document.querySelectorAll('.action-card');
        actionCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
            });

            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });

        // Add ripple effect to action buttons
        const actionBtns = document.querySelectorAll('.action-btn');
        actionBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size/2;
                const y = e.clientY - rect.top - size/2;

                ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.5);
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    width: ${size}px;
                    height: ${size}px;
                    top: ${y}px;
                    left: ${x}px;
                    pointer-events: none;
                `;

                this.appendChild(ripple);

                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });

        // Add greeting based on time of day
        const hour = new Date().getHours();
        let greeting = '';
        if (hour < 12) greeting = 'Good morning';
        else if (hour < 18) greeting = 'Good afternoon';
        else greeting = 'Good evening';

        // Update welcome message if needed
        const welcomeTitle = document.querySelector('.welcome-content h1');
        if (welcomeTitle) {
            welcomeTitle.innerHTML = `${greeting}, ${document.querySelector('.staff-info h4').textContent}!`;
        }

        // Auto-hide alerts after 5 seconds
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.style.transition = 'opacity 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.parentNode.removeChild(alert);
                    }
                }, 500);
            }, 5000);
        });
    });

    // Add CSS for ripple animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        .action-btn {
            position: relative;
            overflow: hidden;
        }
    `;
    document.head.appendChild(style);
    </script>
</body>
</html>