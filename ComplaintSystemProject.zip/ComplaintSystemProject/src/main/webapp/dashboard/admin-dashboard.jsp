<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6c5ce7;
            --primary-light: #a29bfe;
            --primary-dark: #5b4fcf;
            --secondary: #00cec9;
            --success: #00b894;
            --warning: #fdcb6e;
            --danger: #e17055;
            --info: #0984e3;
            --light: #f8f9fa;
            --dark: #2d3436;
            --gray: #636e72;
            --light-gray: #dfe6e9;
            --shadow: 0 8px 25px rgba(108, 92, 231, 0.1);
            --shadow-dark: 0 8px 25px rgba(108, 92, 231, 0.15);
            --card-radius: 16px;
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #f8f5ff 0%, #eef2ff 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        /* Admin Sidebar */
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 280px;
            background: linear-gradient(180deg, #ffffff 0%, #fafaff 100%);
            box-shadow: var(--shadow-dark);
            padding: 25px 0;
            z-index: 1000;
            border-right: 1px solid var(--light-gray);
            overflow-y: auto;
            transition: var(--transition);
        }

        .admin-sidebar-header {
            padding: 0 25px 25px;
            border-bottom: 1px solid var(--light-gray);
            margin-bottom: 20px;
        }

        .admin-logo {
            display: flex;
            align-items: center;
            color: var(--primary);
            margin-bottom: 20px;
            padding: 10px 0;
        }

        .admin-logo i {
            font-size: 2.2rem;
            margin-right: 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text h2 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-logo-text p {
            font-size: 0.85rem;
            color: var(--gray);
            font-weight: 500;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(108, 92, 231, 0.05);
            border-radius: 12px;
            border: 1px solid var(--light-gray);
        }

        .admin-avatar {
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.4rem;
            border: 3px solid white;
            box-shadow: 0 4px 10px rgba(108, 92, 231, 0.2);
        }

        .admin-info h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--dark);
        }

        .admin-info p {
            font-size: 0.8rem;
            color: var(--gray);
            background: var(--light);
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            font-weight: 600;
        }

        .admin-nav-menu {
            list-style: none;
            padding: 0 15px;
        }

        .admin-nav-item {
            margin-bottom: 8px;
            position: relative;
        }

        .admin-nav-link {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            color: var(--dark);
            text-decoration: none;
            border-radius: 12px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .admin-nav-link i {
            margin-right: 15px;
            font-size: 1.3rem;
            width: 24px;
            color: var(--primary);
            transition: var(--transition);
        }

        .admin-nav-link span {
            font-weight: 500;
            transition: var(--transition);
        }

        .admin-nav-link:hover {
            background-color: rgba(108, 92, 231, 0.08);
            color: var(--primary-dark);
            transform: translateX(8px);
        }

        .admin-nav-link:hover i {
            transform: scale(1.1);
        }

        .admin-nav-link.active {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
        }

        .admin-nav-link.active i {
            color: white;
            transform: scale(1.1);
        }

        .nav-badge {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        /* Admin Main Content */
        .admin-main-content {
            margin-left: 280px;
            padding: 30px;
            min-height: 100vh;
            transition: var(--transition);
        }

        /* Top Bar */
        .admin-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-gray);
        }

        .admin-page-title h1 {
            font-size: 2.2rem;
            color: var(--dark);
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .admin-page-title p {
            color: var(--gray);
            margin-top: 8px;
            font-size: 1rem;
            max-width: 600px;
        }

        .admin-user-badge {
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            padding: 12px 25px;
            border-radius: 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(108, 92, 231, 0.2);
            border: 2px solid white;
            transition: var(--transition);
        }

        .admin-user-badge:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(108, 92, 231, 0.3);
        }

        /* Stats Grid */
        .admin-stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 50px;
            margin-bottom: 40px;
        }

        .admin-stat-card {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            border: 1px solid var(--light-gray);
        }

        .admin-stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(108, 92, 231, 0.15);
            border-color: var(--primary-light);
        }

        .admin-stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 6px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-light), var(--primary));
        }

        .admin-stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .admin-stat-icon {
            width: 65px;
            height: 65px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-residents .admin-stat-icon { background: linear-gradient(135deg, #6c5ce7, #5b4fcf); }
        .stat-complaints .admin-stat-icon { background: linear-gradient(135deg, #e17055, #d63031); }
        .stat-pending .admin-stat-icon { background: linear-gradient(135deg, #fdcb6e, #f39c12); }
        .stat-resolved .admin-stat-icon { background: linear-gradient(135deg, #00b894, #00a085); }
        .stat-apartments .admin-stat-icon { background: linear-gradient(135deg, #74b9ff, #0984e3); }
        .stat-staff .admin-stat-icon { background: linear-gradient(135deg, #a29bfe, #6c5ce7); }

        .admin-stat-card h3 {
            font-size: 0.9rem;
            color: var(--gray);
            margin-bottom: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .admin-stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--dark);
            margin-bottom: 10px;
            line-height: 1;
        }

        /* Charts Grid */
        .charts-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }

        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }

        .chart-box {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            border: 1px solid var(--light-gray);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
        }

        .chart-header h3 {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .chart-header h3 i {
            color: var(--primary);
        }

        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }

        /* Recent Activity */
        .recent-activity {
            background: white;
            border-radius: var(--card-radius);
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 40px;
        }

        .recent-activity h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--light-gray);
            transition: var(--transition);
        }

        .activity-item:hover {
            background: #f9f9ff;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: white;
            font-size: 1.2rem;
        }

        .activity-content {
            flex: 1;
        }

        .activity-content p {
            margin-bottom: 5px;
            font-weight: 500;
        }

        .activity-time {
            font-size: 0.85rem;
            color: var(--gray);
        }

        /* Footer */
        .admin-footer {
            text-align: center;
            padding: 25px;
            color: var(--gray);
            font-size: 0.9rem;
            background: white;
            border-radius: var(--card-radius);
            box-shadow: var(--shadow);
        }

        /* Responsive */
        @media (max-width: 992px) {
            .admin-sidebar {
                width: 80px;
                padding: 20px 0;
            }
            
            .admin-sidebar-header, .admin-info, .admin-nav-link span {
                display: none;
            }
            
            .admin-logo {
                justify-content: center;
                margin-bottom: 30px;
            }
            
            .admin-logo i {
                margin-right: 0;
                font-size: 2.5rem;
            }
            
            .admin-nav-link {
                justify-content: center;
                padding: 20px 0;
            }
            
            .admin-nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .admin-main-content {
                margin-left: 80px;
                padding: 20px;
            }
            
            .admin-top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .admin-main-content {
                margin-left: 0;
                padding: 20px 15px;
            }
            
            .admin-sidebar {
                transform: translateX(-100%);
            }
            
            .admin-stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .chart-box {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .admin-stats-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-stat-card {
                padding: 25px;
            }
        }
    </style>
</head>
<body>
    <!-- Admin Sidebar -->
    <div class="admin-sidebar">
        <div class="admin-sidebar-header">
            <div class="admin-logo">
                <i class="fas fa-shield-alt"></i>
                <div class="admin-logo-text">
                    <h2>Admin Panel</h2>
                    <p>Apartment Chempaka</p>
                </div>
            </div>
            
            <div class="admin-profile">
                <div class="admin-avatar">
                    <c:choose>
                        <c:when test="${not empty user.username}">
                            ${fn:substring(user.username, 0, 1).toUpperCase()}
                        </c:when>
                        <c:otherwise>
                            A
                        </c:otherwise>
                    </c:choose>
                </div>
                <div class="admin-info">
                    <h4>${user.username}</h4>
                    <p>Administrator</p>
                </div>
            </div>
        </div>

        <ul class="admin-nav-menu">
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/dashboard" class="admin-nav-link active">
                    <i class="fas fa-gauge-high"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/admin-complaints" class="admin-nav-link">
                    <i class="fas fa-file-lines"></i>
                    <span>Complaints</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/categories" class="admin-nav-link">
                    <i class="fas fa-list-check"></i>
                    <span>Complaint Categories</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/staff" class="admin-nav-link">
                    <i class="fas fa-user-gear"></i>
                    <span>Staff</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/roles" class="admin-nav-link">
                    <i class="fas fa-user-tag"></i>
                    <span>Staff Roles</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/resident" class="admin-nav-link">
                    <i class="fas fa-users"></i>
                    <span>Residents</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/units" class="admin-nav-link">
                    <i class="fas fa-building"></i>
                    <span>Apartment Units</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/admin/report" class="admin-nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="admin-nav-item">
                <a href="${pageContext.request.contextPath}/logout" class="admin-nav-link">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="admin-main-content">
        <!-- Top Bar -->
        <div class="admin-top-bar">
            <div class="admin-page-title">
                <h1>Admin Dashboard</h1>
                <p>Welcome back, ${user.username}. Here's what's happening with your complaint management system.</p>
            </div>
            
            <div class="admin-user-badge">
                <i class="fas fa-user-shield"></i>
                ${user.username}
            </div>
        </div>

        <!-- Stats Grid -->
        <div class="admin-stats-grid">
            <div class="admin-stat-card stat-complaints">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-folder-open"></i>
                    </div>
                </div>
                <h3>Total Complaints</h3>
                <div class="stat-value">${stats.totalComplaints}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    All time complaints
                </div>
            </div>

            <div class="admin-stat-card stat-pending">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
                <h3>Pending Complaints</h3>
                <div class="stat-value">${stats.pending}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    <i class="fas fa-exclamation-circle" style="color: var(--warning); margin-right: 5px;"></i> Requires attention
                </div>
            </div>

            <div class="admin-stat-card stat-resolved">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
                <h3>Resolved Complaints</h3>
                <div class="stat-value">${stats.resolved}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    <i class="fas fa-trophy" style="color: var(--success); margin-right: 5px;"></i> Completed cases
                </div>
            </div>

            <div class="admin-stat-card stat-apartments">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
                <h3>Apartment Units</h3>
                <div class="stat-value">${stats.totalUnits}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    <i class="fas fa-chart-pie" style="margin-right: 5px;"></i> Blocks A, B, C
                </div>
            </div>
                
            <div class="admin-stat-card stat-residents">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <h3>Total Residents</h3>
                <div class="stat-value">${stats.totalResidents}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    <i class="fas fa-home" style="margin-right: 5px;"></i> Occupied units
                </div>
            </div>

            <div class="admin-stat-card stat-staff">
                <div class="admin-stat-header">
                    <div class="admin-stat-icon">
                        <i class="fas fa-user-tie"></i>
                    </div>
                </div>
                <h3>Staff Members</h3>
                <div class="stat-value">${stats.totalStaff}</div>
                <div style="font-size: 0.85rem; color: var(--gray); margin-top: 10px;">
                    <i class="fas fa-user-check" style="margin-right: 5px;"></i> Active personnel
                </div>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="charts-grid">
            <div class="chart-box">
                <div class="chart-header">
                    <h3><i class="fas fa-chart-pie"></i> Complaints by Category</h3>
                </div>
                <div class="chart-container">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
            
            <div class="chart-box">
                <div class="chart-header">
                    <h3><i class="fas fa-chart-bar"></i> Status Distribution</h3>
                </div>
                <div class="chart-container">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="recent-activity">
            <h3><i class="fas fa-history"></i> Recent Activity</h3>
            <ul class="activity-list">
                <c:set var="colors" value="${['#6c5ce7', '#e17055', '#00b894', '#fdcb6e', '#0984e3']}" />
                <c:set var="icons" value="${['fa-plus', 'fa-file-alt', 'fa-check-circle', 'fa-user-plus', 'fa-comment']}" />
                
                <c:if test="${not empty recentComplaints}">
                    <c:forEach var="complaint" items="${recentComplaints}" varStatus="loop">
                        <c:set var="statusColor" value="" />
                        <c:choose>
                            <c:when test="${complaint.status == 'pending'}">
                                <c:set var="statusColor" value="#f39c12" />
                            </c:when>
                            <c:when test="${complaint.status == 'in_progress'}">
                                <c:set var="statusColor" value="#0984e3" />
                            </c:when>
                            <c:when test="${complaint.status == 'resolved'}">
                                <c:set var="statusColor" value="#00b894" />
                            </c:when>
                            <c:otherwise>
                                <c:set var="statusColor" value="#e17055" />
                            </c:otherwise>
                        </c:choose>
                        
                        <li class="activity-item">
                            <div class="activity-icon" style="background: linear-gradient(135deg, ${colors[loop.index]}, ${colors[loop.index]}88);">
                                <i class="fas ${icons[loop.index]}"></i>
                            </div>
                            <div class="activity-content">
                                <p><strong>${complaint.residentName}</strong> submitted a new complaint: "${complaint.title}"</p>
                                <div class="activity-time">
                                    <i class="far fa-clock"></i> ${complaint.timeAgo}
                                    <span style="color: ${statusColor}">
                                        <i class="fas fa-circle" style="font-size: 0.6rem;"></i> 
                                        ${fn:replace(complaint.status, '_', ' ')}
                                    </span>
                                </div>
                            </div>
                        </li>
                    </c:forEach>
                </c:if>
                <c:if test="${empty recentComplaints}">
                    <li class="activity-item">
                        <div class="activity-content">
                            <p>No recent complaints found.</p>
                        </div>
                    </li>
                </c:if>
            </ul>
        </div>

        <!-- Footer -->
        <div class="admin-footer">
            <p>© 2025 Apartment Chempaka Complaint Management System | v2.1.0</p>
        </div>
    </div>
                
<!-- DEBUG: Show raw data values -->
<div style="position: fixed; bottom: 10px; left: 10px; background: rgba(0,0,0,0.9); color: white; padding: 10px; z-index: 10000; border-radius: 5px; max-width: 300px; font-size: 12px; display: none;">
    <h4 style="margin-top: 0;">Debug Data:</h4>
    
    <strong>Category Data:</strong>
    <c:choose>
        <c:when test="${not empty categoryData}">
            <c:forEach var="entry" items="${categoryData}" varStatus="loop">
                <div>${loop.index + 1}. ${entry.key}: ${entry.value}</div>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <div>No category data</div>
        </c:otherwise>
    </c:choose>
    
    <hr style="margin: 5px 0;">
    
    <strong>Status Data:</strong>
    <c:choose>
        <c:when test="${not empty statusData}">
            <c:forEach var="entry" items="${statusData}" varStatus="loop">
                <div>${loop.index + 1}. ${entry.key}: ${entry.value}</div>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <div>No status data</div>
        </c:otherwise>
    </c:choose>
    
    <button onclick="this.parentElement.style.display='none'" style="margin-top: 10px; padding: 2px 8px; font-size: 10px;">Hide</button>
</div>

    <script>
        // Store data directly from JSTL to JavaScript
        const categoryDataMap = {
            <c:forEach var="entry" items="${categoryData}" varStatus="loop">
            "${fn:escapeXml(entry.key)}": ${entry.value}<c:if test="${!loop.last}">,</c:if>
            </c:forEach>
        };

        const statusDataMap = {
            <c:forEach var="entry" items="${statusData}" varStatus="loop">
            "${fn:escapeXml(entry.key)}": ${entry.value}<c:if test="${!loop.last}">,</c:if>
            </c:forEach>
        };

        console.log("Category Data Map:", categoryDataMap);
        console.log("Status Data Map:", statusDataMap);
        console.log("Category Data Keys:", Object.keys(categoryDataMap));
        console.log("Status Data Keys:", Object.keys(statusDataMap));

        document.addEventListener('DOMContentLoaded', function() {
            console.log("Dashboard loaded, initializing charts...");

            // Prepare chart data
            const categoryLabels = Object.keys(categoryDataMap);
            const categoryCounts = Object.values(categoryDataMap);

            const statusLabels = [];
            const statusCounts = [];
            const statusColors = [];

            // Process status data
            for (const [key, value] of Object.entries(statusDataMap)) {
                let displayStatus = '';
                let color = '';

                if (key === 'pending') {
                    color = "#fdcb6e";
                    displayStatus = "PENDING";
                } else if (key === 'in_progress') {
                    color = "#74b9ff";
                    displayStatus = "IN PROGRESS";
                } else if (key === 'resolved') {
                    color = "#00b894";
                    displayStatus = "RESOLVED";
                } else if (key === 'rejected') {
                    color = "#e17055";
                    displayStatus = "REJECTED";
                } else {
                    color = "#636e72";
                    displayStatus = key.toUpperCase();
                }

                statusLabels.push(displayStatus);
                statusCounts.push(value);
                statusColors.push(color);
            }

            console.log("Final Category Data:", categoryLabels, categoryCounts);
            console.log("Final Status Data:", statusLabels, statusCounts);

            // Register the datalabels plugin
            Chart.register(ChartDataLabels);

            // Create Category Chart
            createCategoryChart(categoryLabels, categoryCounts);

            // Create Status Chart
            createStatusChart(statusLabels, statusCounts, statusColors);

            setupMobileMenu();
        });

        function createCategoryChart(labels, data) {
            const ctx = document.getElementById('categoryChart');
            if (!ctx) {
                console.error("Category chart canvas not found!");
                return;
            }

            if (labels.length === 0 || data.length === 0) {
                console.warn("No category data available");
                // Show placeholder message
                ctx.getContext('2d').fillText('No category data available', 10, 50);
                return;
            }

            try {
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: data,
                            backgroundColor: [
                                '#6c5ce7', '#a29bfe', '#00cec9', '#0984e3', '#00b894', 
                                '#fdcb6e', '#e17055', '#fd79a8', '#636e72', '#74b9ff'
                            ].slice(0, labels.length),
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    color: '#2d3436'
                                }
                            },
                            tooltip: {
                                enabled: true  // Enable for debugging
                            },
                            datalabels: {
                                color: '#fff',
                                font: { weight: 'bold', size: 12 },
                                formatter: function(value, context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                    return percentage >= 10 ? percentage + '%' : '';
                                }
                            }
                        },
                        cutout: '65%'
                    }
                });
                console.log("✅ Category chart created successfully");
            } catch (error) {
                console.error("❌ Error creating category chart:", error);
            }
        }

        function createStatusChart(labels, data, colors) {
            const ctx = document.getElementById('statusChart');
            if (!ctx) {
                console.error("Status chart canvas not found!");
                return;
            }

            if (labels.length === 0 || data.length === 0) {
                console.warn("No status data available");
                // Show placeholder message
                ctx.getContext('2d').fillText('No status data available', 10, 50);
                return;
            }

            try {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Number of Complaints',
                            data: data,
                            backgroundColor: colors.map(color => {
                                if (color.startsWith('#')) {
                                    const r = parseInt(color.slice(1, 3), 16);
                                    const g = parseInt(color.slice(3, 5), 16);
                                    const b = parseInt(color.slice(5, 7), 16);
                                    return `rgba(${r}, ${g}, ${b}, 0.8)`;
                                }
                                return color;
                            }),
                            borderColor: colors,
                            borderWidth: 2,
                            borderRadius: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: { enabled: true },  // Enable for debugging
                            datalabels: {
                                color: '#fff',
                                font: { weight: 'bold', size: 12 },
                                anchor: 'end',
                                align: 'top',
                                formatter: function(value) {
                                    return value > 0 ? value : '';
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { precision: 0 }
                            }
                        }
                    }
                });
                console.log("✅ Status chart created successfully");
            } catch (error) {
                console.error("❌ Error creating status chart:", error);
            }
        }

        function setupMobileMenu() {
            const sidebarToggle = document.createElement('button');
            sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
            sidebarToggle.style.cssText = 'position: fixed; top: 20px; left: 20px; z-index: 1001; background: var(--primary); color: white; border: none; width: 50px; height: 50px; border-radius: 12px; font-size: 1.2rem; cursor: pointer; display: none;';
            document.body.appendChild(sidebarToggle);

            sidebarToggle.addEventListener('click', function() {
                const sidebar = document.querySelector('.admin-sidebar');
                sidebar.style.transform = sidebar.style.transform === 'translateX(0px)' ? 'translateX(-100%)' : 'translateX(0px)';
            });

            if (window.innerWidth <= 768) {
                sidebarToggle.style.display = 'flex';
                sidebarToggle.style.alignItems = 'center';
                sidebarToggle.style.justifyContent = 'center';
            }

            window.addEventListener('resize', function() {
                if (window.innerWidth <= 768) {
                    sidebarToggle.style.display = 'flex';
                } else {
                    sidebarToggle.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>