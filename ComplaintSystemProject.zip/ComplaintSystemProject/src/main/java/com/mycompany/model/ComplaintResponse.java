package com.mycompany.model;

public class ComplaintResponse {
    private int complaint_id;
    private int staff_id;
    private String message;

    public ComplaintResponse() {}

    public ComplaintResponse(int complaint_id, int staff_id, String message) {
        this.complaint_id = complaint_id;
        this.staff_id = staff_id;
        this.message = message;
    }

    public int getComplaint_id() { return complaint_id; }
    public void setComplaint_id(int complaint_id) { this.complaint_id = complaint_id; }

    public int getStaff_id() { return staff_id; }
    public void setStaff_id(int staff_id) { this.staff_id = staff_id; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
