package com.mycompany.model;

import java.sql.Timestamp;

public class ApartmentUnit {
    private int unit_id;
    private String block;
    private int floor;
    private String unit_number;
    private String unit_type; // Will be derived or defaulted
    private String status; // Will be derived
    private Integer resident_id; // From resident table join
    private String resident_name; // From join with resident table
    private Timestamp created_at; // Will be null in your schema
    
    // Constructors
    public ApartmentUnit() {}
    
    // Getters and Setters
    public int getUnit_id() { return unit_id; }
    public void setUnit_id(int unit_id) { this.unit_id = unit_id; }
    
    public String getBlock() { return block; }
    public void setBlock(String block) { this.block = block; }
    
    public int getFloor() { return floor; }
    public void setFloor(int floor) { this.floor = floor; }
    
    public String getUnit_number() { return unit_number; }
    public void setUnit_number(String unit_number) { this.unit_number = unit_number; }
    
    public String getUnit_type() { 
        // Return default or derive from unit number
        return unit_type != null ? unit_type : "Standard";
    }
    public void setUnit_type(String unit_type) { this.unit_type = unit_type; }
    
    public String getStatus() { 
        // Derive status from resident assignment
        if (resident_id != null && resident_id > 0) {
            return "occupied";
        }
        return status != null ? status : "vacant";
    }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getResident_id() { return resident_id; }
    public void setResident_id(Integer resident_id) { this.resident_id = resident_id; }
    
    public String getResident_name() { return resident_name; }
    public void setResident_name(String resident_name) { this.resident_name = resident_name; }
    
    public Timestamp getCreated_at() { return created_at; }
    public void setCreated_at(Timestamp created_at) { this.created_at = created_at; }
    
    // Helper methods
    public String getFullLocation() {
        return "Block " + block + ", Floor " + floor + ", Unit " + unit_number;
    }
    
    public String getFormattedStatus() {
        return getStatus().toUpperCase();
    }
    
    public String getLocationCode() {
        return block + floor + unit_number;
    }
}