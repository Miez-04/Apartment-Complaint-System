package com.mycompany.model;

public class Staff {

    private int staff_id;
    private String name;
    private String phone;
    private int user_id;
    private int role_id;
    private int category_id;

    private User user;
    private Role role;
    private ComplaintCategory category;
    

    // getters & setters
    public int getStaff_id() { return staff_id; }
    public void setStaff_id(int staff_id) { this.staff_id = staff_id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public int getUser_id() { return user_id; }
    public void setUser_id(int user_id) { this.user_id = user_id; }

    public int getRole_id() { return role_id; }
    public void setRole_id(int role_id) { this.role_id = role_id; }

    public int getCategory_id() { return category_id; }
    public void setCategory_id(int category_id) { this.category_id = category_id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public ComplaintCategory getCategory() {
        return category;
    }

    public void setCategory(ComplaintCategory category) {
        this.category = category;
    }
}
