package com.mycompany.model;

public class ComplaintCategory {
    private int category_id;
    private String category_name;
    private String description;
    
    // Constructors
    public ComplaintCategory() {}
    
    public ComplaintCategory(int category_id, String category_name, String description) {
        this.category_id = category_id;
        this.category_name = category_name;
        this.description = description;
    }
    
    // Getters and Setters
    public int getCategory_id() {
        return category_id;
    }
    
    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }
    
    public String getCategory_name() {
        return category_name;
    }
    
    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
}