package com.mycompany.model;

public class User {

    private int user_id;
    private String username;
    private String password;
    private String role;
    private int staff_id;  // Add this to link user to staff

    public User() {}

    public User(int user_id, String username, String password, String role, int staff_id){
        this.user_id = user_id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.staff_id = staff_id;
    }

    // Getters and Setters
    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }
}
