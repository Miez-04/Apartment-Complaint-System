package com.mycompany.model;

public class Resident {

    private int resident_id;
    private String name;
    private String phone;
    private String email;
    private int unit_id;
    private int user_id;

    private User user;
    private ApartmentUnit unit;

    public Resident() {}

    public Resident(int resident_id, String name, String phone, String email, int unit_id, int user_id) {
        this.resident_id = resident_id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.unit_id = unit_id;
        this.user_id = user_id;
    }

    public int getResident_id() { return resident_id; }
    public void setResident_id(int resident_id) { this.resident_id = resident_id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public int getUnit_id() { return unit_id; }
    public void setUnit_id(int unit_id) { this.unit_id = unit_id; }

    public int getUser_id() { return user_id; }
    public void setUser_id(int user_id) { this.user_id = user_id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public ApartmentUnit getUnit() { return unit; }
    public void setUnit(ApartmentUnit unit) { this.unit = unit; }

    // Convenience getters for MVC JSP
    public String getUnitBlock() {
        return (unit != null) ? unit.getBlock() : "";
    }

    public String getUnitFloor() {
        return (unit != null) ? String.valueOf(unit.getFloor()) : "";
    }

    public String getUnitNumber() {
        return (unit != null) ? unit.getUnit_number() : "";
    }
}
