package com.mycompany.model;

public class Role {
    private int role_id;
    private String role_name;
    private String description; // Changed from role_desc to description
    
    // Constructors
    public Role() {}
    
    public Role(int role_id, String role_name, String description) {
        this.role_id = role_id;
        this.role_name = role_name;
        this.description = description;
    }
    
    // Getters and Setters
    public int getRole_id() {
        return role_id;
    }
    
    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }
    
    public String getRole_name() {
        return role_name;
    }
    
    public void setRole_name(String role_name) {
        this.role_name = role_name;
    }
    
    public String getDescription() { // Changed from getRole_desc()
        return description;
    }
    
    public void setDescription(String description) { // Changed from setRole_desc()
        this.description = description;
    }
}