package com.mycompany.controller.admin;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Collections;
import java.util.logging.Logger;

@WebServlet("/AssignStaffController")
public class AssignStaffController extends HttpServlet {
    
    private static final Logger logger = Logger.getLogger(AssignStaffController.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Debug: Check what's in the session
        logger.info("Session attributes: " + session.getAttributeNames());
        for (String name : Collections.list(session.getAttributeNames())) {
            logger.info("Attribute: " + name + " = " + session.getAttribute(name));
        }

        Object userObj = session.getAttribute("user");
        
        // Check if userObj is actually a User object
        if (userObj == null) {
            logger.warning("No user object found in session");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (!(userObj instanceof User)) {
            logger.severe("Session attribute 'user' is not a User object. Type: " + 
                         userObj.getClass().getName());
            // Clear the invalid session attribute
            session.removeAttribute("user");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        User user = (User) userObj;
        
        // Check if user is admin
        if (!"admin".equals(user.getRole())) {
            request.setAttribute("error", "Only administrators can assign staff.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
            return;
        }

        try {
            int complaintId = Integer.parseInt(request.getParameter("complaint_id"));
            int staffId = Integer.parseInt(request.getParameter("staff_id"));

            ComplaintDAO dao = new ComplaintDAO();
            boolean success = dao.assignStaff(complaintId, staffId);
            
            if (success) {
                // Add success message to session
                session.setAttribute("successMessage", "Staff assigned successfully!");
            } else {
                session.setAttribute("errorMessage", "Failed to assign staff.");
            }

            // Redirect back to complaint detail page
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);

        } catch (NumberFormatException e) {
            logger.warning("Invalid ID format: " + e.getMessage());
            request.setAttribute("error", "Invalid complaint or staff ID.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } catch (Exception e) {
            logger.severe("Error assigning staff: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}