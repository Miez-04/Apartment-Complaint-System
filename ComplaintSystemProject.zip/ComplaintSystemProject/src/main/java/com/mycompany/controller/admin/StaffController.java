package com.mycompany.controller.admin;

import com.mycompany.dao.StaffDAO;
import com.mycompany.dao.RoleDAO;
import com.mycompany.dao.ComplaintCategoryDAO;
import com.mycompany.model.User;
import com.mycompany.model.Role;
import com.mycompany.model.ComplaintCategory;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@WebServlet("/admin/staff")
public class StaffController extends HttpServlet {

    private StaffDAO staffDAO = new StaffDAO();
    private RoleDAO roleDAO = new RoleDAO();
    private ComplaintCategoryDAO categoryDAO = new ComplaintCategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Session & role check
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // 2️⃣ Get all data for the page
            request.setAttribute("staffList", staffDAO.getAllStaff());
            request.setAttribute("roles", roleDAO.getAllRoles());
            request.setAttribute("categories", categoryDAO.getAllCategories());
            request.setAttribute("user", user);
            
            // 3️⃣ Get stats for dashboard
            Map<String, Integer> stats = getStaffStats();
            request.setAttribute("stats", stats);
            
            // 4️⃣ Forward to JSP
            request.getRequestDispatcher("/admin/staff.jsp")
                   .forward(request, response);
                   
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Unable to load staff data: " + e.getMessage());
            request.getRequestDispatcher("/admin/staff.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Session & role check
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                handleAddStaff(request, session);
                
            } else if ("update".equals(action)) {
                handleUpdateStaff(request, session);
                
            } else if ("delete".equals(action)) {
                handleDeleteStaff(request, session);
            }
            
            response.sendRedirect(request.getContextPath() + "/admin/staff");
            
        } catch (Exception e) {
            e.printStackTrace();
            String errorMsg = getErrorMessage(e);
            session.setAttribute("errorMessage", errorMsg);
            response.sendRedirect(request.getContextPath() + "/admin/staff");
        }
    }
    
    private void handleAddStaff(HttpServletRequest request, HttpSession session) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        int roleId = Integer.parseInt(request.getParameter("role_id"));
        
        String categoryParam = request.getParameter("category_id");
        Integer categoryId = null;
        if (categoryParam != null && !categoryParam.trim().isEmpty()) {
            try {
                categoryId = Integer.parseInt(categoryParam);
            } catch (NumberFormatException e) {
                categoryId = null;
            }
        }

        // Validate input
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty() || 
            name == null || name.trim().isEmpty()) {
            session.setAttribute("errorMessage", "Username, Password and Name are required fields!");
            return;
        }

        staffDAO.addStaff(username, password, name, phone, roleId, categoryId);
        session.setAttribute("successMessage", "Staff member added successfully!");
    }
    
    private void handleUpdateStaff(HttpServletRequest request, HttpSession session) {
        int staffId = Integer.parseInt(request.getParameter("staff_id"));
        String username = request.getParameter("username");
        String password = request.getParameter("password"); // may be blank
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        int roleId = Integer.parseInt(request.getParameter("role_id"));

        String categoryParam = request.getParameter("category_id");
        Integer categoryId = null;
        if (categoryParam != null && !categoryParam.isEmpty()) {
            categoryId = Integer.parseInt(categoryParam);
        }

        // Validate input
        if (username == null || username.trim().isEmpty() || 
            name == null || name.trim().isEmpty()) {
            session.setAttribute("errorMessage", "Username and Name are required fields!");
            return;
        }

        staffDAO.updateStaff(staffId, username, password, name, phone, roleId, categoryId);
        session.setAttribute("successMessage", "Staff member updated successfully!");
    }
    
    private void handleDeleteStaff(HttpServletRequest request, HttpSession session) {
        String deleteId = request.getParameter("deleteId");
        if (deleteId != null && !deleteId.isEmpty()) {
            staffDAO.deleteStaff(Integer.parseInt(deleteId));
            session.setAttribute("successMessage", "Staff member deleted successfully!");
        }
    }
    
    private Map<String, Integer> getStaffStats() {
        Map<String, Integer> stats = new HashMap<>();
        
        try {
            // Get total staff count
            stats.put("totalStaff", staffDAO.getTotalStaffCount());
            
            // Get staff count by role
            Map<String, Integer> roleStats = staffDAO.getStaffCountByRole();
            stats.putAll(roleStats);
            
        } catch (Exception e) {
            e.printStackTrace();
            // Set default values
            stats.put("totalStaff", 0);
            stats.put("plumber", 0);
            stats.put("electrician", 0);
            stats.put("cleaner", 0);
            stats.put("security", 0);
            stats.put("maintenance", 0);
        }
        
        return stats;
    }
    
    private String getErrorMessage(Exception e) {
        if (e.getMessage() != null) {
            if (e.getMessage().contains("Duplicate")) {
                return "Username already exists. Please choose another.";
            } else if (e.getMessage().contains("foreign key constraint")) {
                return "Cannot delete staff member. They may be assigned to complaints.";
            } else {
                return "Error: " + e.getMessage();
            }
        }
        return "Unable to process staff operation.";
    }
}