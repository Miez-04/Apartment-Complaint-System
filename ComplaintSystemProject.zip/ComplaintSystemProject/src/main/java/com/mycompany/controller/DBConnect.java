package com.mycompany.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

    private static final String URL = "jdbc:mariadb://localhost:3306/chempaka";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() 
            throws SQLException, ClassNotFoundException {

        // Load MariaDB JDBC Driver
        Class.forName("org.mariadb.jdbc.Driver");

        // Create and return connection
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
