package com.mycompany.controller.admin;

import com.mycompany.dao.ApartmentUnitDAO;
import com.mycompany.model.ApartmentUnit;
import com.mycompany.model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.Map;

@WebServlet("/admin/units")
public class ApartmentUnitController extends HttpServlet {
    
    private ApartmentUnitDAO unitDAO;
    
    @Override
    public void init() throws ServletException {
        unitDAO = new ApartmentUnitDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check authentication
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Set user info for JSP
        request.setAttribute("user", user);
        
        try {
            // Get all units
            request.setAttribute("units", unitDAO.getAllUnits());
            
            // Get statistics
            Map<String, Integer> stats = unitDAO.getUnitStatistics();
            request.setAttribute("totalUnits", stats.get("total"));
            request.setAttribute("blockACount", stats.get("blockA"));
            request.setAttribute("blockBCount", stats.get("blockB"));
            request.setAttribute("blockCCount", stats.get("blockC"));
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error loading units: " + e.getMessage());
        }
        
        request.getRequestDispatcher("/admin/units.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check authentication
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                handleAddUnit(request, session);
            } else if ("update".equals(action)) {
                handleUpdateUnit(request, session);
            } else if ("delete".equals(action)) {
                handleDeleteUnit(request, session);
            }
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMessage", "Error: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/units");
    }
    
    private void handleAddUnit(HttpServletRequest request, HttpSession session) {
        String block = request.getParameter("block");
        String floorStr = request.getParameter("floor");
        String unitNumber = request.getParameter("unit_number");
        
        // Validate inputs
        if (block == null || block.trim().isEmpty() || 
            floorStr == null || floorStr.trim().isEmpty() || 
            unitNumber == null || unitNumber.trim().isEmpty()) {
            session.setAttribute("errorMessage", "All fields are required!");
            return;
        }
        
        try {
            int floor = Integer.parseInt(floorStr);
            
            if (floor < 1 || floor > 20) {
                session.setAttribute("errorMessage", "Floor must be between 1 and 20!");
                return;
            }
            
            if (!unitNumber.matches("\\d{2,3}")) {
                session.setAttribute("errorMessage", "Unit number must be 2-3 digits!");
                return;
            }
            
            ApartmentUnit unit = new ApartmentUnit();
            unit.setBlock(block.trim());
            unit.setFloor(floor);
            unit.setUnit_number(unitNumber.trim());
            
            if (unitDAO.addUnit(unit)) {
                session.setAttribute("successMessage", "Unit added successfully!");
            } else {
                session.setAttribute("errorMessage", "Unit already exists with these details!");
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("errorMessage", "Invalid floor number!");
        }
    }
    
    private void handleUpdateUnit(HttpServletRequest request, HttpSession session) {
        String unitIdStr = request.getParameter("unit_id");
        String block = request.getParameter("block");
        String floorStr = request.getParameter("floor");
        String unitNumber = request.getParameter("unit_number");
        
        // Validate inputs
        if (unitIdStr == null || unitIdStr.trim().isEmpty() ||
            block == null || block.trim().isEmpty() || 
            floorStr == null || floorStr.trim().isEmpty() || 
            unitNumber == null || unitNumber.trim().isEmpty()) {
            session.setAttribute("errorMessage", "All fields are required!");
            return;
        }
        
        try {
            int unitId = Integer.parseInt(unitIdStr);
            int floor = Integer.parseInt(floorStr);
            
            if (floor < 1 || floor > 20) {
                session.setAttribute("errorMessage", "Floor must be between 1 and 20!");
                return;
            }
            
            if (!unitNumber.matches("\\d{2,3}")) {
                session.setAttribute("errorMessage", "Unit number must be 2-3 digits!");
                return;
            }
            
            ApartmentUnit unit = new ApartmentUnit();
            unit.setUnit_id(unitId);
            unit.setBlock(block.trim());
            unit.setFloor(floor);
            unit.setUnit_number(unitNumber.trim());
            
            if (unitDAO.updateUnit(unit)) {
                session.setAttribute("successMessage", "Unit updated successfully!");
            } else {
                session.setAttribute("errorMessage", "Another unit already exists with these details!");
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("errorMessage", "Invalid number format!");
        }
    }
    
    private void handleDeleteUnit(HttpServletRequest request, HttpSession session) {
        String unitIdStr = request.getParameter("unit_id");
        
        if (unitIdStr == null || unitIdStr.trim().isEmpty()) {
            session.setAttribute("errorMessage", "Unit ID is required!");
            return;
        }
        
        try {
            int unitId = Integer.parseInt(unitIdStr);
            
            if (unitDAO.deleteUnit(unitId)) {
                session.setAttribute("successMessage", "Unit deleted successfully!");
            } else {
                session.setAttribute("errorMessage", "Cannot delete unit. It may have residents or complaints assigned.");
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("errorMessage", "Invalid unit ID!");
        }
    }
}