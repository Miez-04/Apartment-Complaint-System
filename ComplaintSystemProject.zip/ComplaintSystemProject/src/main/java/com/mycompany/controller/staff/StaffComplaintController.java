package com.mycompany.controller.staff;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.model.Complaint;
import com.mycompany.model.User;
import com.mycompany.model.Staff;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/staff/staff-complaints")
public class StaffComplaintController extends HttpServlet {

    private ComplaintDAO complaintDAO = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get logged-in user
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"staff".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // Get staff from session
        Staff staff = (Staff) request.getSession().getAttribute("staff");
        if (staff == null) {
            // Try to get staff from database using user_id
            try {
                Map<String, Object> staffData = complaintDAO.getStaffByUserId(user.getUser_id());
                if (staffData != null && !staffData.isEmpty()) {
                    staff = new Staff();
                    staff.setStaff_id((Integer) staffData.get("staff_id"));
                    staff.setName((String) staffData.get("name"));
                    staff.setUser_id(user.getUser_id());
                    request.getSession().setAttribute("staff", staff);
                } else {
                    response.sendRedirect(request.getContextPath() + "/login.jsp");
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/login.jsp");
                return;
            }
        }

        System.out.println("DEBUG: Staff ID = " + staff.getStaff_id()); // Debug log

        try {
            // Fetch complaints assigned to this staff
            List<Complaint> complaints = complaintDAO.getComplaintsByStaff(staff.getStaff_id());
            
            System.out.println("DEBUG: Number of complaints = " + complaints.size()); // Debug log
            
            // Get statistics
            Map<String, Integer> statusCounts = complaintDAO.getStaffComplaintStats(staff.getStaff_id());
            
            // Debug print status counts
            System.out.println("DEBUG: Status Counts = " + statusCounts);
            System.out.println("DEBUG: Total = " + statusCounts.get("total"));
            System.out.println("DEBUG: Pending = " + statusCounts.get("pending"));
            System.out.println("DEBUG: In Progress = " + statusCounts.get("in_progress"));
            System.out.println("DEBUG: Resolved = " + statusCounts.get("resolved"));
            
            // Ensure all status keys exist
            if (!statusCounts.containsKey("pending")) {
                System.out.println("DEBUG: Adding missing 'pending' key");
                statusCounts.put("pending", 0);
            }
            if (!statusCounts.containsKey("in_progress")) {
                System.out.println("DEBUG: Adding missing 'in_progress' key");
                statusCounts.put("in_progress", 0);
            }
            if (!statusCounts.containsKey("resolved")) {
                System.out.println("DEBUG: Adding missing 'resolved' key");
                statusCounts.put("resolved", 0);
            }
            if (!statusCounts.containsKey("rejected")) {
                System.out.println("DEBUG: Adding missing 'rejected' key");
                statusCounts.put("rejected", 0);
            }
            if (!statusCounts.containsKey("total")) {
                System.out.println("DEBUG: Adding missing 'total' key");
                statusCounts.put("total", complaints.size());
            }
            
            // Set attributes for JSP
            request.setAttribute("complaints", complaints);
            request.setAttribute("statusCounts", statusCounts);
            request.setAttribute("staffName", staff.getName());
            request.setAttribute("username", user.getUsername());
            request.setAttribute("staffId", staff.getStaff_id());
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading complaints: " + e.getMessage());
        }

        // Forward to JSP
        request.getRequestDispatcher("/staff/staff-complaint.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle form submissions (update status, add response, etc.)
        String action = request.getParameter("action");
        int complaintId = Integer.parseInt(request.getParameter("complaint_id"));
        
        // Get staff from session
        Staff staff = (Staff) request.getSession().getAttribute("staff");
        if (staff == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        try {
            if ("resolve".equals(action)) {
                String message = request.getParameter("message");
                complaintDAO.updateComplaintStatus(complaintId, "resolved", staff.getStaff_id());
                
                if (message != null && !message.trim().isEmpty()) {
                    complaintDAO.addComplaintResponse(complaintId, staff.getStaff_id(), message);
                }
                
            } else if ("update".equals(action)) {
                String status = request.getParameter("status");
                String message = request.getParameter("message");
                
                if (status != null) {
                    complaintDAO.updateComplaintStatus(complaintId, status, staff.getStaff_id());
                }
                
                if (message != null && !message.trim().isEmpty()) {
                    complaintDAO.addComplaintResponse(complaintId, staff.getStaff_id(), message);
                }
            }
            
            // FIXED: Redirect to match controller URL (singular)
            response.sendRedirect(request.getContextPath() + "/staff/staff-complaints");
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error processing request: " + e.getMessage());
            doGet(request, response); // Show the page with error message
        }
    }
}