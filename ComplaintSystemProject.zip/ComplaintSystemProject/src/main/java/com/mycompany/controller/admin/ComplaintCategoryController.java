package com.mycompany.controller.admin;

import com.mycompany.dao.ComplaintCategoryDAO;
import com.mycompany.model.ComplaintCategory;
import com.mycompany.model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/admin/categories")
public class ComplaintCategoryController extends HttpServlet {
    
    private ComplaintCategoryDAO categoryDAO;
    
    @Override
    public void init() throws ServletException {
        categoryDAO = new ComplaintCategoryDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check session and role
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        try {
            // Get all categories
            request.setAttribute("categories", categoryDAO.getAllCategories());
            
            // Get total count
            request.setAttribute("totalCategories", categoryDAO.getTotalCategories());
            
            // Set colors array for category icons
            String[] colors = {
                "var(--primary-light), var(--primary)",
                "#74b9ff, #0984e3",
                "#fdcb6e, #f39c12",
                "#00cec9, #00b894",
                "#a29bfe, #6c5ce7",
                "#fd79a8, #e84393",
                "#55efc4, #00b894"
            };
            request.setAttribute("colors", colors);
            
            // Set user for display
            request.setAttribute("user", user);
            
            // Forward to JSP
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
            
        } catch (Exception e) {
            request.setAttribute("error", "Error loading categories: " + e.getMessage());
            request.getRequestDispatcher("/admin/categories.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check session and role
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        
        try {
            if ("add".equals(action)) {
                String categoryName = request.getParameter("category_name");
                String description = request.getParameter("description");
                
                // Validate input
                if (categoryName == null || categoryName.trim().isEmpty()) {
                    session.setAttribute("errorMessage", "Category name is required!");
                    response.sendRedirect(request.getContextPath() + "/admin/categories");
                    return;
                }
                
                if (categoryName.trim().length() < 3) {
                    session.setAttribute("errorMessage", "Category name must be at least 3 characters!");
                    response.sendRedirect(request.getContextPath() + "/admin/categories");
                    return;
                }
                
                ComplaintCategory category = new ComplaintCategory();
                category.setCategory_name(categoryName.trim());
                category.setDescription(description != null ? description.trim() : "");
                
                if (categoryDAO.addCategory(category)) {
                    session.setAttribute("successMessage", "Category '" + categoryName + "' added successfully!");
                } else {
                    session.setAttribute("errorMessage", "Category '" + categoryName + "' already exists!");
                }
                
            } else if ("update".equals(action)) {
                int categoryId = Integer.parseInt(request.getParameter("category_id"));
                String categoryName = request.getParameter("category_name");
                String description = request.getParameter("description");
                
                // Validate input
                if (categoryName == null || categoryName.trim().isEmpty()) {
                    session.setAttribute("errorMessage", "Category name is required!");
                    response.sendRedirect(request.getContextPath() + "/admin/categories");
                    return;
                }
                
                // Check if category name already exists (excluding current category)
                if (categoryDAO.categoryExistsExcluding(categoryName, categoryId)) {
                    session.setAttribute("errorMessage", "Category '" + categoryName + "' already exists!");
                    response.sendRedirect(request.getContextPath() + "/admin/categories");
                    return;
                }
                
                ComplaintCategory category = new ComplaintCategory();
                category.setCategory_id(categoryId);
                category.setCategory_name(categoryName.trim());
                category.setDescription(description != null ? description.trim() : "");
                
                if (categoryDAO.updateCategory(category)) {
                    session.setAttribute("successMessage", "Category updated successfully!");
                } else {
                    session.setAttribute("errorMessage", "Failed to update category!");
                }
                
            } else if ("delete".equals(action)) {
                int categoryId = Integer.parseInt(request.getParameter("category_id"));
                
                if (categoryDAO.deleteCategory(categoryId)) {
                    session.setAttribute("successMessage", "Category deleted successfully!");
                } else {
                    session.setAttribute("errorMessage", "Failed to delete category. It may be in use.");
                }
            }
        } catch (NumberFormatException e) {
            session.setAttribute("errorMessage", "Invalid category ID!");
        } catch (Exception e) {
            session.setAttribute("errorMessage", "Error: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/categories");
    }
}


