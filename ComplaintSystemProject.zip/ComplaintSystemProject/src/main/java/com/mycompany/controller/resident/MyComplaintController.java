package com.mycompany.controller.resident;

import com.mycompany.model.Resident;
import com.mycompany.model.User;
import com.mycompany.controller.DBConnect;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

@WebServlet("/resident/myComplaint")
public class MyComplaintController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Check session & role
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"resident".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        int user_id = user.getUser_id();
        List<Map<String, Object>> complaints = new ArrayList<>();

        // 2️⃣ Get resident name
        String residentName = "";
        Resident resident = (Resident) request.getSession().getAttribute("resident");
        if (resident != null) {
            residentName = resident.getName();
        } else {
            try (Connection conn = DBConnect.getConnection()) {
                PreparedStatement ps = conn.prepareStatement(
                    "SELECT name FROM resident WHERE user_id = ?"
                );
                ps.setInt(1, user_id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    residentName = rs.getString("name");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 3️⃣ Get all complaints for this resident
        try (Connection conn = DBConnect.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                "cat.category_name, cat.description AS category_desc, " +
                "s.name AS staff_name " +
                "FROM complaint c " +
                "LEFT JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                "JOIN resident r ON c.resident_id = r.resident_id " +
                "WHERE r.user_id = ? " +
                "ORDER BY c.created_at DESC"
            );
            ps.setInt(1, user_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("complaint_id", rs.getInt("complaint_id"));
                row.put("title", rs.getString("title"));
                row.put("description", rs.getString("description"));
                row.put("status", rs.getString("status"));
                row.put("created_at", rs.getTimestamp("created_at"));
                row.put("category_name", rs.getString("category_name"));
                row.put("category_desc", rs.getString("category_desc"));
                row.put("staff_name", rs.getString("staff_name"));
                complaints.add(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 4️⃣ Set attributes for JSP
        request.setAttribute("complaints", complaints);
        request.setAttribute("residentName", residentName);
        request.setAttribute("username", user.getUsername());

        // 5️⃣ Forward to JSP
        request.getRequestDispatcher("/resident/myComplaint.jsp").forward(request, response);
    }
}
