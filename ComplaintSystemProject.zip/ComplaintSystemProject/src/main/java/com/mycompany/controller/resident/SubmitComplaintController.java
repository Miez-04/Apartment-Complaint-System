package com.mycompany.controller.resident;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.dao.ComplaintCategoryDAO;
import com.mycompany.dao.ResidentDAO;
import com.mycompany.model.ComplaintCategory;
import com.mycompany.model.Resident;
import com.mycompany.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@WebServlet("/resident/submitComplaint")
@MultipartConfig(maxFileSize = 1024 * 1024 * 5) // 5MB
public class SubmitComplaintController extends HttpServlet {

    private ComplaintDAO complaintDAO;
    private ComplaintCategoryDAO categoryDAO;
    private ResidentDAO residentDAO;

    @Override
    public void init() {
        complaintDAO = new ComplaintDAO();
        categoryDAO = new ComplaintCategoryDAO();
        residentDAO = new ResidentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get logged-in user
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"resident".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Fetch resident info
        Resident resident = residentDAO.getResidentByUserId(user.getUser_id());
        request.setAttribute("resident", resident);

        // Fetch complaint categories
        List<ComplaintCategory> categories = categoryDAO.getAllCategories();
        request.setAttribute("categories", categories);

        // Forward to JSP
        request.getRequestDispatcher("/resident/submitComplaint.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null || !"resident".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // Get form fields
            int residentId = Integer.parseInt(request.getParameter("resident_id"));
            int unitId = Integer.parseInt(request.getParameter("unit_id"));
            int categoryId = Integer.parseInt(request.getParameter("category_id"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            Part imagePart = request.getPart("image");

            InputStream imageData = (imagePart != null && imagePart.getSize() > 0)
                    ? imagePart.getInputStream()
                    : null;

            // Submit complaint via DAO
            boolean success = complaintDAO.submitComplaint(residentId, unitId, categoryId, title, description, imageData);

            // Redirect with status
            if (success) {
                response.sendRedirect(request.getContextPath() + "/resident/submitComplaint?status=success");
            } else {
                response.sendRedirect(request.getContextPath() + "/resident/submitComplaint?status=error");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/resident/submitComplaint?status=error");
        }
    }
}
