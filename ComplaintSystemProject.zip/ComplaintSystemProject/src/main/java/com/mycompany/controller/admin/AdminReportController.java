package com.mycompany.controller.admin;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

@WebServlet("/admin/report")
public class AdminReportController extends HttpServlet {
    
    private ComplaintDAO complaintDAO = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("print".equals(action)) {
            // Direct print without modal - just generate the report
            generatePrintReport(request, response);
        } else {
            showAnalyticsDashboard(request, response);
        }
    }
    
    private void showAnalyticsDashboard(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            Map<String, Object> analytics = complaintDAO.getAnalyticsData();
            
            // Set all analytics data as request attributes
            request.setAttribute("analytics", analytics);
            
            // Also set individual attributes for backward compatibility
            request.setAttribute("totalComplaints", analytics.get("totalComplaints"));
            request.setAttribute("pendingCount", analytics.get("pendingCount"));
            request.setAttribute("inProgressCount", analytics.get("inProgressCount"));
            request.setAttribute("resolvedCount", analytics.get("resolvedCount"));
            request.setAttribute("statusCount", analytics.get("statusCount"));
            request.setAttribute("categoryCount", analytics.get("categoryCount"));
            request.setAttribute("monthlyTrend", analytics.get("monthlyTrend"));
            request.setAttribute("staffPerformance", analytics.get("staffPerformance"));
            request.setAttribute("complaints", analytics.get("complaints"));
            
            request.getRequestDispatcher("/admin/admin-report.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error loading analytics data: " + e.getMessage());
            request.getRequestDispatcher("/admin/admin-report.jsp").forward(request, response);
        }
    }
    
    private void generatePrintReport(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Parse filter parameters
            String startDateStr = request.getParameter("startDate");
            String endDateStr = request.getParameter("endDate");
            String status = request.getParameter("status");
            String categoryIdStr = request.getParameter("categoryId");
            
            Date startDate = null;
            Date endDate = null;
            Integer categoryId = null;
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            
            if (startDateStr != null && !startDateStr.trim().isEmpty()) {
                try {
                    startDate = sdf.parse(startDateStr);
                } catch (Exception e) {
                    System.err.println("Invalid start date format: " + startDateStr);
                }
            }
            
            if (endDateStr != null && !endDateStr.trim().isEmpty()) {
                try {
                    endDate = sdf.parse(endDateStr);
                } catch (Exception e) {
                    System.err.println("Invalid end date format: " + endDateStr);
                }
            }
            
            if (categoryIdStr != null && !categoryIdStr.trim().isEmpty()) {
                try {
                    categoryId = Integer.parseInt(categoryIdStr);
                } catch (NumberFormatException e) {
                    System.err.println("Invalid category ID: " + categoryIdStr);
                }
            }
            
            // Get filtered complaints
            java.util.List<Map<String, Object>> complaints = 
                complaintDAO.getFilteredComplaintsForReport(startDate, endDate, status, categoryId);
            
            // Get analytics summary for the filtered data
            Map<String, Object> reportStats = getReportStats(complaints);
            
            // Set report data
            request.setAttribute("reportDate", new Date());
            request.setAttribute("startDate", startDate);
            request.setAttribute("endDate", endDate);
            request.setAttribute("statusFilter", status);
            request.setAttribute("categoryIdFilter", categoryId);
            request.setAttribute("complaints", complaints);
            request.setAttribute("analytics", reportStats);
            
            // Generate report in print-friendly format
            request.getRequestDispatcher("/print-report.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Error generating report: " + e.getMessage());
        }
    }
    
    private Map<String, Object> getReportStats(java.util.List<Map<String, Object>> complaints) {
        Map<String, Object> stats = new java.util.HashMap<>();
        
        int total = complaints.size();
        int pending = 0;
        int inProgress = 0;
        int resolved = 0;
        int rejected = 0;
        
        for (Map<String, Object> complaint : complaints) {
            String status = (String) complaint.get("status");
            if (status != null) {
                switch (status) {
                    case "pending": pending++; break;
                    case "in_progress": inProgress++; break;
                    case "resolved": resolved++; break;
                    case "rejected": rejected++; break;
                }
            }
        }
        
        stats.put("totalComplaints", total);
        stats.put("pendingCount", pending);
        stats.put("inProgressCount", inProgress);
        stats.put("resolvedCount", resolved);
        stats.put("rejectedCount", rejected);
        
        return stats;
    }
}