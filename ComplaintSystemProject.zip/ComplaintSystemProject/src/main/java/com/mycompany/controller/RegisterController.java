package com.mycompany.controller;

import com.mycompany.dao.ApartmentUnitDAO;
import com.mycompany.dao.UserDAO;
import com.mycompany.model.ApartmentUnit;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

@WebServlet("/register")
public class RegisterController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Fetch all apartment units
        ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();
        List<ApartmentUnit> units = unitDAO.getAllUnits();

        // 2️⃣ Pass units to JSP
        request.setAttribute("units", units);

        // 3️⃣ Forward to JSP
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        int unitId = Integer.parseInt(request.getParameter("unit_id"));

        try (Connection conn = DBConnect.getConnection()) {

            // 1️⃣ Check if username exists
            PreparedStatement checkUser = conn.prepareStatement(
                    "SELECT 1 FROM user WHERE username=?");
            checkUser.setString(1, username);
            ResultSet rs = checkUser.executeQuery();

            if (rs.next()) {
                request.setAttribute("error", "Username already exists!");
                
                // Reload units for dropdown
                ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();
                request.setAttribute("units", unitDAO.getAllUnits());

                request.getRequestDispatcher("/register.jsp")
                       .forward(request, response);
                return;
            }

            // 2️⃣ Insert user
            PreparedStatement psUser = conn.prepareStatement(
                    "INSERT INTO user (username, password, role) VALUES (?, ?, 'resident')",
                    Statement.RETURN_GENERATED_KEYS);
            psUser.setString(1, username);
            psUser.setString(2, password);
            psUser.executeUpdate();

            // 3️⃣ Get generated user_id
            ResultSet keys = psUser.getGeneratedKeys();
            keys.next();
            int userId = keys.getInt(1);

            // 4️⃣ Insert resident info
            PreparedStatement psResident = conn.prepareStatement(
                    "INSERT INTO resident (name, phone, email, user_id, unit_id) VALUES (?, ?, ?, ?, ?)");
            psResident.setString(1, name);
            psResident.setString(2, phone);
            psResident.setString(3, email);
            psResident.setInt(4, userId);
            psResident.setInt(5, unitId);
            psResident.executeUpdate();

            // 5️⃣ Redirect to login page
            response.sendRedirect(request.getContextPath() + "/login");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Registration failed. Please try again.");

            // Reload units for dropdown
            ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();
            request.setAttribute("units", unitDAO.getAllUnits());

            request.getRequestDispatcher("/register.jsp").forward(request, response);
        }
    }
}
