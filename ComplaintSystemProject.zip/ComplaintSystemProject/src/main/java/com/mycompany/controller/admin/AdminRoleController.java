package com.mycompany.controller.admin;

import com.mycompany.dao.RoleDAO;
import com.mycompany.model.Role;
import com.mycompany.model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/roles")
public class AdminRoleController extends HttpServlet {
    
    private RoleDAO roleDAO;
    
    @Override
    public void init() throws ServletException {
        roleDAO = new RoleDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        // Authentication and Authorization check
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/access-denied");
            return;
        }
        
        try {
            // Get data from DAO
            List<Role> roles = roleDAO.getAllRoles();
            int totalRoles = roleDAO.getTotalRoles();
            
            // Set request attributes
            request.setAttribute("roles", roles);
            request.setAttribute("totalRoles", totalRoles);
            
            // Define colors for role display
            String[] roleColors = {
                "linear-gradient(135deg, var(--primary-light), var(--primary))",
                "linear-gradient(135deg, #74b9ff, #0984e3)",
                "linear-gradient(135deg, #fdcb6e, #f39c12)",
                "linear-gradient(135deg, #00cec9, #00b894)",
                "linear-gradient(135deg, #a29bfe, #6c5ce7)",
                "linear-gradient(135deg, #fd79a8, #e84393)"
            };
            request.setAttribute("roleColors", roleColors);
            
            // Check for messages from previous POST request
            String successMessage = (String) session.getAttribute("successMessage");
            String errorMessage = (String) session.getAttribute("errorMessage");
            
            if (successMessage != null) {
                request.setAttribute("successMessage", successMessage);
                session.removeAttribute("successMessage");
            }
            
            if (errorMessage != null) {
                request.setAttribute("errorMessage", errorMessage);
                session.removeAttribute("errorMessage");
            }
            
            // Forward to JSP view - CORRECTED PATH
            request.getRequestDispatcher("/admin/roles.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading roles: " + e.getMessage());
            request.getRequestDispatcher("/admin/roles.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        // Authentication and Authorization check
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        if (!"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/access-denied");
            return;
        }
        
        String action = request.getParameter("action");
        String successMessage = null;
        String errorMessage = null;
        
        try {
            if ("add".equals(action)) {
                String roleName = request.getParameter("role_name");
                String description = request.getParameter("description");
                
                // Business validation in Controller
                if (roleName == null || roleName.trim().isEmpty()) {
                    errorMessage = "Role name is required";
                } else if (roleName.length() < 3) {
                    errorMessage = "Role name must be at least 3 characters";
                } else if (roleDAO.roleExists(roleName)) {
                    errorMessage = "Role '" + roleName + "' already exists";
                } else {
                    Role role = new Role();
                    role.setRole_name(roleName);
                    role.setDescription(description);
                    
                    boolean success = roleDAO.addRole(role);
                    if (success) {
                        successMessage = "Role '" + roleName + "' added successfully!";
                    } else {
                        errorMessage = "Failed to add role. Please try again.";
                    }
                }
                
            } else if ("update".equals(action)) {
                int roleId = Integer.parseInt(request.getParameter("role_id"));
                String roleName = request.getParameter("role_name");
                String description = request.getParameter("description");
                
                // Business validation in Controller
                if (roleName == null || roleName.trim().isEmpty()) {
                    errorMessage = "Role name is required";
                } else if (roleName.length() < 3) {
                    errorMessage = "Role name must be at least 3 characters";
                } else if (roleDAO.roleExistsExcluding(roleName, roleId)) {
                    errorMessage = "Role '" + roleName + "' already exists";
                } else {
                    Role role = new Role();
                    role.setRole_id(roleId);
                    role.setRole_name(roleName);
                    role.setDescription(description);
                    
                    boolean success = roleDAO.updateRole(role);
                    if (success) {
                        successMessage = "Role updated successfully!";
                    } else {
                        errorMessage = "Failed to update role. Please try again.";
                    }
                }
                
            } else if ("delete".equals(action)) {
                int roleId = Integer.parseInt(request.getParameter("role_id"));
                
                boolean success = roleDAO.deleteRole(roleId);
                if (success) {
                    successMessage = "Role deleted successfully!";
                } else {
                    errorMessage = "Failed to delete role. Please try again.";
                }
            } else {
                errorMessage = "Invalid action specified.";
            }
            
        } catch (NumberFormatException e) {
            errorMessage = "Invalid role ID format.";
        } catch (Exception e) {
            errorMessage = "Error: " + e.getMessage();
        }
        
        // Store message in session for redirect
        if (successMessage != null) {
            session.setAttribute("successMessage", successMessage);
        } else if (errorMessage != null) {
            session.setAttribute("errorMessage", errorMessage);
        }
        
        // Redirect to GET (PRG pattern)
        response.sendRedirect(request.getContextPath() + "/admin/roles");
    }
}