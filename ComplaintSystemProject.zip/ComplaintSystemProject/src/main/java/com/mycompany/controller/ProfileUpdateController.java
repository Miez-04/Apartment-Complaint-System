package com.mycompany.controller;

import com.mycompany.dao.ApartmentUnitDAO;
import com.mycompany.dao.ComplaintCategoryDAO;
import com.mycompany.dao.ResidentDAO;
import com.mycompany.dao.StaffDAO;
import com.mycompany.dao.RoleDAO;
import com.mycompany.model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/updateProfile")
public class ProfileUpdateController extends HttpServlet {

    private final ResidentDAO residentDAO = new ResidentDAO();
    private final StaffDAO staffDAO = new StaffDAO();
    private final ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();
    private final RoleDAO roleDAO = new RoleDAO();
    private final ComplaintCategoryDAO categoryDAO = new ComplaintCategoryDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if(session == null){
            response.sendRedirect("login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");
        if(user == null){
            response.sendRedirect("login.jsp");
            return;
        }

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = user.getRole();

        try {
            if("resident".equals(role)){
                int unitId = Integer.parseInt(request.getParameter("unit_id"));
                String name = request.getParameter("name");
                String email = request.getParameter("email");
                String phone = request.getParameter("phone");

                residentDAO.updateResident(
                        ((Resident)residentDAO.getResidentByUserId(user.getUser_id())).getResident_id(),
                        username, password, name, phone, email, unitId
                );

            } else if("staff".equals(role)){
                int roleId = Integer.parseInt(request.getParameter("role_id"));
                int categoryId = Integer.parseInt(request.getParameter("category_id"));
                String name = request.getParameter("name");
                String phone = request.getParameter("phone");

                Staff staff = staffDAO.getStaffByUserId(user.getUser_id());
                staffDAO.updateStaff(
                        staff.getStaff_id(),
                        username,
                        password,
                        name,
                        phone,
                        roleId,
                        categoryId
                );
            }

            // Update session info
            user.setUsername(username);
            if(password != null && !password.isEmpty()){
                user.setPassword(password);
            }
            session.setAttribute("user", user);

            response.sendRedirect("profile?success=1");

        } catch(Exception e){
            e.printStackTrace();
            response.sendRedirect("profile?error=1");
        }
    }
}
