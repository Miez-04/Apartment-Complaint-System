package com.mycompany.controller;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.dao.ResidentDAO;
import com.mycompany.dao.StaffDAO;
import com.mycompany.model.Complaint;
import com.mycompany.model.Resident;
import com.mycompany.model.Staff;
import com.mycompany.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet("/dashboard")
public class DashboardController extends HttpServlet {

    private ComplaintDAO complaintDAO = new ComplaintDAO();
    private ResidentDAO residentDAO = new ResidentDAO();
    private StaffDAO staffDAO = new StaffDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Session & role check
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // 2️⃣ Resident dashboard logic
        if ("resident".equals(user.getRole())) {
            try {
                Resident resident = residentDAO.getResidentByUserId(user.getUser_id());

                if (resident == null) {
                    response.sendRedirect(request.getContextPath() + "/login.jsp");
                    return;
                }

                int residentId = resident.getResident_id();
                List<Complaint> complaints = complaintDAO.getComplaintsByResident(residentId);

                // Compute stats
                int total = complaints.size();
                int pending = 0, inProgress = 0, resolved = 0;
                for (Complaint c : complaints) {
                    switch (c.getStatus()) {
                        case "pending": pending++; break;
                        case "in_progress": inProgress++; break;
                        case "resolved": resolved++; break;
                    }
                }

                Map<String, Integer> stats = new HashMap<>();
                stats.put("total", total);
                stats.put("pending", pending);
                stats.put("in_progress", inProgress);
                stats.put("resolved", resolved);

                request.setAttribute("resident", resident);
                request.setAttribute("stats", stats);
                request.setAttribute("complaints", complaints);

                request.getRequestDispatcher("/dashboard/resident-dashboard.jsp")
                       .forward(request, response);

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/login.jsp");
            }
            return;
        }

        // 3️⃣ Staff dashboard logic
        if ("staff".equals(user.getRole())) {
            try {
                Staff staff = staffDAO.getStaffByUserId(user.getUser_id());
                if (staff == null) {
                    response.sendRedirect(request.getContextPath() + "/login.jsp");
                    return;
                }
                
                // Store staff in session for future use
                request.getSession().setAttribute("staff", staff);
                
                // Get dashboard statistics
                Map<String, Integer> stats = complaintDAO.getStaffComplaintStats(staff.getStaff_id());
                
                // Get recent complaints
                List<Complaint> recentComplaints = complaintDAO.getRecentStaffComplaints(staff.getStaff_id(), 5);
                
                // Get role name and department
                String roleName = "Staff Member";
                String department = "";
                
                Map<String, Object> staffData = complaintDAO.getStaffByUserId(user.getUser_id());
                if (staffData != null && !staffData.isEmpty()) {
                    roleName = (String) staffData.getOrDefault("role_name", "Staff Member");
                    department = (String) staffData.getOrDefault("category_name", "");
                }
                
                // Get today's date
                SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMM d, yyyy");
                String todayDate = sdf.format(new Date());
                
                // Set request attributes
                request.setAttribute("staff", staff);
                request.setAttribute("staffName", staff.getName());
                request.setAttribute("roleName", roleName);
                request.setAttribute("department", department);
                request.setAttribute("phone", staff.getPhone());
                request.setAttribute("todayDate", todayDate);
                request.setAttribute("username", user.getUsername());
                request.setAttribute("staffId", staff.getStaff_id());
                request.setAttribute("stats", stats);
                request.setAttribute("recentComplaints", recentComplaints);
                
                request.getRequestDispatcher("/dashboard/staff-dashboard.jsp").forward(request, response);
                
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/login.jsp");
            }
            return;
        }

        // 4️⃣ Admin dashboard logic
        if ("admin".equals(user.getRole())) {
            try {
                // Get admin dashboard statistics
                Map<String, Integer> stats = getAdminDashboardStatistics();

                // Get chart data
                Map<String, Integer> categoryData = complaintDAO.getComplaintsByCategory();
                Map<String, Integer> statusData = complaintDAO.getComplaintsByStatus();

                // DEBUG: Print to console
                System.out.println("=== ADMIN DASHBOARD DATA ===");
                System.out.println("Category Data Size: " + categoryData.size());
                System.out.println("Category Data: " + categoryData);
                System.out.println("Status Data Size: " + statusData.size());
                System.out.println("Status Data: " + statusData);
                System.out.println("===========================");

                // Get recent complaints
                List<Map<String, Object>> recentComplaints = getAdminRecentComplaints();

                // Get today's date
                SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMM d, yyyy");
                String todayDate = sdf.format(new Date());

                // Set request attributes - Make sure names match JSP
                request.setAttribute("user", user);
                request.setAttribute("todayDate", todayDate);
                request.setAttribute("stats", stats);
                request.setAttribute("categoryData", categoryData);  // This is a Map
                request.setAttribute("statusData", statusData);      // This is a Map
                request.setAttribute("recentComplaints", recentComplaints);

                request.getRequestDispatcher("/dashboard/admin-dashboard.jsp").forward(request, response);

            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "Error loading dashboard: " + e.getMessage());
                request.getRequestDispatcher("/dashboard/admin-dashboard.jsp").forward(request, response);
            }
            return;
        }

        // Default: redirect to login
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }

    // Admin dashboard helper methods
    private Map<String, Integer> getAdminDashboardStatistics() throws Exception {
        Map<String, Integer> stats = new HashMap<>();
        
        // Get resident count
        int totalResidents = residentDAO.getTotalResidentCount();
        stats.put("totalResidents", totalResidents);
        
        // Get staff count
        int totalStaff = staffDAO.getTotalStaffCount();
        stats.put("totalStaff", totalStaff);
        
        // Get complaint statistics
        Map<String, Integer> complaintStats = complaintDAO.getAdminComplaintStats();
        // Rename keys to match JSP
        stats.put("totalComplaints", complaintStats.getOrDefault("totalComplaints", 0));
        stats.put("pending", complaintStats.getOrDefault("pendingCount", 0));
        stats.put("inProgress", complaintStats.getOrDefault("inProgressCount", 0));
        stats.put("resolved", complaintStats.getOrDefault("resolvedCount", 0));
        
        // Hardcoded apartment units
        stats.put("totalUnits", 60);
        
        return stats;
    }

    private Map<String, Object> getAdminChartData() throws Exception {
        Map<String, Object> chartData = new HashMap<>();
        
        // Get complaints by category
        Map<String, Integer> categoryData = complaintDAO.getComplaintsByCategory();
        chartData.put("categoryData", categoryData);
        
        // Get complaints by status
        Map<String, Integer> statusData = complaintDAO.getComplaintsByStatus();
        chartData.put("statusData", statusData);
        
        return chartData;
    }

    private List<Map<String, Object>> getAdminRecentComplaints() throws Exception {
        List<Map<String, Object>> recentComplaints = new ArrayList<>();
        
        // Get recent complaints from DAO
        List<Complaint> complaints = complaintDAO.getRecentComplaints(5);
        
        for (Complaint complaint : complaints) {
            Map<String, Object> complaintData = new HashMap<>();
            complaintData.put("id", complaint.getComplaint_id());
            complaintData.put("title", complaint.getTitle());
            complaintData.put("residentName", complaint.getResidentName());
            complaintData.put("status", complaint.getStatus());
            complaintData.put("createdAt", complaint.getCreated_at());
            complaintData.put("timeAgo", getTimeAgo((Timestamp) complaint.getCreated_at()));
            recentComplaints.add(complaintData);
        }
        
        return recentComplaints;
    }

    private String getTimeAgo(java.sql.Timestamp timestamp) {
        if (timestamp == null) return "Just now";
        
        long diff = System.currentTimeMillis() - timestamp.getTime();
        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (days > 0) {
            return days + " day" + (days > 1 ? "s" : "") + " ago";
        } else if (hours > 0) {
            return hours + " hour" + (hours > 1 ? "s" : "") + " ago";
        } else if (minutes > 0) {
            return minutes + " minute" + (minutes > 1 ? "s" : "") + " ago";
        } else {
            return "Just now";
        }
    }
    
    
}