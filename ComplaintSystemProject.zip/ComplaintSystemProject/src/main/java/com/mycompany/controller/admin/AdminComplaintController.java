package com.mycompany.controller.admin;

import com.mycompany.dao.ComplaintDAO;
import com.mycompany.model.User;
import com.mycompany.model.Complaint;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/admin-complaints")
public class AdminComplaintController extends HttpServlet {

    private ComplaintDAO complaintDAO = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check session and role
        User user = (User) request.getSession().getAttribute("user");
        if(user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // Get all complaints with full details
            List<Complaint> complaints = complaintDAO.getAllComplaintsWithDetails();
            request.setAttribute("complaints", complaints);
            
            // Get stats for dashboard
            Map<String, Integer> stats = complaintDAO.getAdminComplaintStats();
            request.setAttribute("stats", stats);
            
            // Set user info for display
            request.setAttribute("user", user);

            // Forward to JSP (view only - no logic)
            request.getRequestDispatcher("/admin/admin-complaint.jsp")
                   .forward(request, response);

        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("error", "Unable to load complaints. Please try again later.");
            request.getRequestDispatcher("/admin/admin-complaint.jsp")
                   .forward(request, response);
        }
    }
}