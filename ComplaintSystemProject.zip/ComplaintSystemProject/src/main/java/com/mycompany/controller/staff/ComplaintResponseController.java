package com.mycompany.controller.staff;

import com.mycompany.dao.ComplaintResponseDAO;
import com.mycompany.dao.StaffDAO;
import com.mycompany.model.ComplaintResponse;
import com.mycompany.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/staff/ComplaintResponseController")
public class ComplaintResponseController extends HttpServlet {
    
    private ComplaintResponseDAO complaintResponseDAO;
    private StaffDAO staffDAO;
    
    @Override
    public void init() throws ServletException {
        // Initialize DAOs
        complaintResponseDAO = new ComplaintResponseDAO();
        staffDAO = new StaffDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Authentication check
        if (user == null || !"staff".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // 1. Get parameters (Controller responsibility)
            int complaintId = Integer.parseInt(request.getParameter("complaint_id"));
            String message = request.getParameter("response_message");

            // 2. Input validation (Controller responsibility)
            if (message == null || message.trim().isEmpty()) {
                session.setAttribute("error", "Response message cannot be empty");
                response.sendRedirect(request.getContextPath() +
                        "/complaint-detail?complaint_id=" + complaintId);
                return;
            }

            // 3. Get staff ID through DAO (Business logic moved to Service layer in proper MVC)
            // In pure MVC, this would be in a Service class, but we'll keep it simple
            Integer staffId = staffDAO.getStaffIdByUserId(user.getUser_id());
            
            if (staffId == null || staffId == 0) {
                session.setAttribute("error", "Staff profile not found");
                response.sendRedirect(request.getContextPath() +
                        "/complaint-detail.jsp?complaint_id=" + complaintId);
                return;
            }

            // 4. Create model object
            ComplaintResponse complaintResponse = new ComplaintResponse();
            complaintResponse.setComplaint_id(complaintId);
            complaintResponse.setStaff_id(staffId);
            complaintResponse.setMessage(message);

            // 5. Call DAO to save (Controller delegates to Model layer)
            boolean success = complaintResponseDAO.addResponseAndResolve(complaintResponse);

            // 6. Handle response (Controller responsibility)
            if (success) {
                session.setAttribute("success", "Response saved successfully");
            } else {
                session.setAttribute("error", "Failed to save response");
            }
            
            response.sendRedirect(request.getContextPath() +
                    "/complaint-detail?complaint_id=" + complaintId);

        } catch (NumberFormatException e) {
            session.setAttribute("error", "Invalid complaint ID");
            response.sendRedirect(request.getContextPath() + "/staff/staff-complaints");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "An error occurred: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/staff/staff-complaints");
        }
    }
}