package com.mycompany.controller;

import java.sql.Connection;

public class TestConnection {

    public static void main(String[] args) {
        try {
            Connection conn = DBConnect.getConnection();

            if (conn != null) {
                System.out.println("✅ Database connection successful!");
                conn.close();
            }

        } catch (Exception e) {
            System.out.println("❌ Database connection failed!");
            e.printStackTrace();
        }
    }
}
