package com.mycompany.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import com.mycompany.controller.DBConnect;
import com.mycompany.model.User;
import java.sql.Types;

@WebServlet("/EditComplaintController")
@MultipartConfig(
    maxFileSize = 1024 * 1024 * 5, // 5MB
    maxRequestSize = 1024 * 1024 * 10, // 10MB
    fileSizeThreshold = 1024 * 1024 // 1MB
)
public class EditComplaintController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if(user == null){
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            int complaintId = Integer.parseInt(request.getParameter("complaint_id"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            int unitId = Integer.parseInt(request.getParameter("unit_id"));
            int categoryId = Integer.parseInt(request.getParameter("category_id"));

            // admin can update status
            String status = null;
            if("admin".equals(user.getRole())){
                status = request.getParameter("status");
            }

            Part imagePart = request.getPart("image");

            try (Connection conn = DBConnect.getConnection()) {
                String sql;
                PreparedStatement ps;

                if("admin".equals(user.getRole())){
                    if (imagePart != null && imagePart.getSize() > 0) {
                        // Update with image and status (admin)
                        sql = "UPDATE complaint SET title=?, description=?, unit_id=?, category_id=?, status=?, image_data=? WHERE complaint_id=?";
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, title);
                        ps.setString(2, description);
                        ps.setInt(3, unitId);
                        ps.setInt(4, categoryId);
                        ps.setString(5, status);
                        ps.setBlob(6, imagePart.getInputStream());
                        ps.setInt(7, complaintId);
                    } else {
                        // Update without image, keep existing image (admin)
                        sql = "UPDATE complaint SET title=?, description=?, unit_id=?, category_id=?, status=? WHERE complaint_id=?";
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, title);
                        ps.setString(2, description);
                        ps.setInt(3, unitId);
                        ps.setInt(4, categoryId);
                        ps.setString(5, status);
                        ps.setInt(6, complaintId);
                    }
                } else {
                    if (imagePart != null && imagePart.getSize() > 0) {
                        // Update with image (resident/staff)
                        sql = "UPDATE complaint SET title=?, description=?, unit_id=?, category_id=?, image_data=? WHERE complaint_id=?";
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, title);
                        ps.setString(2, description);
                        ps.setInt(3, unitId);
                        ps.setInt(4, categoryId);
                        ps.setBlob(5, imagePart.getInputStream());
                        ps.setInt(6, complaintId);
                    } else {
                        // Update without image, keep existing image (resident/staff)
                        sql = "UPDATE complaint SET title=?, description=?, unit_id=?, category_id=? WHERE complaint_id=?";
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, title);
                        ps.setString(2, description);
                        ps.setInt(3, unitId);
                        ps.setInt(4, categoryId);
                        ps.setInt(5, complaintId);
                    }
                }

                int rowsAffected = ps.executeUpdate();
                
                if (rowsAffected > 0) {
                    session.setAttribute("successMessage", "Complaint updated successfully!");
                } else {
                    session.setAttribute("errorMessage", "Failed to update complaint. Complaint not found.");
                }

                // Redirect back to complaint detail page
                response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);

            } catch (Exception e) {
                e.printStackTrace();
                session.setAttribute("errorMessage", "Database error: " + e.getMessage());
                response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
            session.setAttribute("errorMessage", "Invalid complaint ID format.");
            response.sendRedirect(request.getContextPath() + "/dashboard");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMessage", "An unexpected error occurred.");
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }
}