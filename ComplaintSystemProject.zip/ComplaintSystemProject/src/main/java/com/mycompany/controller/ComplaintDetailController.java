package com.mycompany.controller;

import com.mycompany.dao.*;
import com.mycompany.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/complaint-detail")
public class ComplaintDetailController extends HttpServlet {
    
    private ComplaintDAO complaintDAO;
    private ApartmentUnitDAO unitDAO;
    private ComplaintCategoryDAO categoryDAO;
    private StaffDAO staffDAO;
    private ResidentDAO residentDAO;

    @Override
    public void init() {
        complaintDAO = new ComplaintDAO();
        unitDAO = new ApartmentUnitDAO();
        categoryDAO = new ComplaintCategoryDAO();
        staffDAO = new StaffDAO();
        residentDAO = new ResidentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        int complaintId = 0;
        try {
            complaintId = Integer.parseInt(request.getParameter("complaint_id"));
        } catch (Exception e) {
            request.setAttribute("error", "Invalid complaint ID.");
            request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
            return;
        }

        try {
            // 1. Fetch complaint details
            Complaint complaint = complaintDAO.getComplaintById(complaintId);
            if (complaint == null) {
                request.setAttribute("error", "Complaint not found.");
                request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
                return;
            }

            // 2. Fetch related entities
            Resident resident = residentDAO.getResidentById(complaint.getResident_id());
            ApartmentUnit unit = unitDAO.getUnitById(complaint.getUnit_id());
            ComplaintCategory category = categoryDAO.getCategoryById(complaint.getCategory_id());
            Staff assignedStaff = null;
            String assignedStaffName = "Not assigned yet";
            if (complaint.getStaff_id() > 0) {
                assignedStaff = staffDAO.getStaffById(complaint.getStaff_id());
                if (assignedStaff != null) {
                    assignedStaffName = assignedStaff.getName();
                }
            }

            // 3. Load dropdowns for editing (only for admin)
            List<ApartmentUnit> allUnits = null;
            List<ComplaintCategory> allCategories = null;
            List<Staff> allStaff = null;
            
            // Get staff by category for modal dropdown
            List<Staff> staffByCategory = null;
            if (complaint.getCategory_id() > 0) {
                staffByCategory = staffDAO.getStaffByCategoryId(complaint.getCategory_id());
            }
            
            if ("admin".equals(user.getRole())) {
                allUnits = unitDAO.getAllUnits();
                allStaff = staffDAO.getAllStaff();
            } else {
                // For non-admin users, only get their own unit
                allUnits = new java.util.ArrayList<>();
                allUnits.add(unit);
            }
            
            allCategories = categoryDAO.getAllCategories();
            
            // If allStaff is still null (for non-admin), initialize empty list
            if (allStaff == null) {
                allStaff = new java.util.ArrayList<>();
            }
            
            // If staffByCategory is null, use allStaff
            if (staffByCategory == null || staffByCategory.isEmpty()) {
                staffByCategory = allStaff;
            }

            // 4. Fetch complaint responses
            List<Map<String, Object>> responses = complaintDAO.getComplaintResponses(complaintId);

            // 5. Check if complaint has image
            boolean hasImage = false;
            try {
                if (complaint.getImage_data() != null) {
                    hasImage = true;
                }
            } catch (Exception e) {
                // If getImage_data() throws exception or returns null
                hasImage = false;
            }

            // 6. Set attributes for JSP
            request.setAttribute("complaint", complaint);
            request.setAttribute("resident", resident);
            request.setAttribute("unit", unit);
            request.setAttribute("category", category);
            request.setAttribute("assignedStaff", assignedStaff);
            request.setAttribute("assignedStaffName", assignedStaffName);
            request.setAttribute("allUnits", allUnits);
            request.setAttribute("allCategories", allCategories);
            request.setAttribute("allStaff", allStaff);
            request.setAttribute("staffByCategory", staffByCategory);
            request.setAttribute("responses", responses);
            request.setAttribute("hasImage", hasImage);
            request.setAttribute("user", user);
            request.setAttribute("role", user.getRole());

            // 7. Forward to JSP
            request.getRequestDispatcher("/complaintDetail.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading complaint details: " + e.getMessage());
            request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        int complaintId = 0;
        
        try {
            complaintId = Integer.parseInt(request.getParameter("complaint_id"));
        } catch (Exception e) {
            request.setAttribute("error", "Invalid complaint ID.");
            request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
            return;
        }

        try {
            if ("update".equals(action)) {
                handleUpdateComplaint(request, response, user, complaintId);
            } else if ("assign".equals(action)) {
                handleAssignStaff(request, response, user, complaintId);
            } else if ("update_status".equals(action)) {
                handleUpdateStatus(request, response, user, complaintId);
            } else if ("add_response".equals(action)) {
                handleAddResponse(request, response, user, complaintId);
            } else {
                request.setAttribute("error", "Invalid action.");
                response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error processing request: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
        }
    }
    
    private void handleUpdateComplaint(HttpServletRequest request, HttpServletResponse response, 
                                       User user, int complaintId) throws Exception {
        
        if (!"admin".equals(user.getRole()) && !"resident".equals(user.getRole())) {
            request.setAttribute("error", "You don't have permission to edit complaints.");
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            return;
        }

        // Get form parameters
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String status = request.getParameter("status");
        int categoryId = Integer.parseInt(request.getParameter("category_id"));
        int unitId = Integer.parseInt(request.getParameter("unit_id"));
        
        // Create complaint object
        Complaint complaint = new Complaint();
        complaint.setComplaint_id(complaintId);
        complaint.setTitle(title);
        complaint.setDescription(description);
        complaint.setStatus(status);
        complaint.setCategory_id(categoryId);
        complaint.setUnit_id(unitId);

        // Update complaint
        complaintDAO.updateComplaint(complaint);
        
        request.setAttribute("success", "Complaint updated successfully.");
        response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
    }

    private void handleAssignStaff(HttpServletRequest request, HttpServletResponse response,
                                   User user, int complaintId) throws Exception {
        
        if (!"admin".equals(user.getRole())) {
            request.setAttribute("error", "You don't have permission to assign staff.");
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            return;
        }

        int staffId = Integer.parseInt(request.getParameter("staff_id"));
        
        // Assign staff to complaint
        boolean success = complaintDAO.assignStaff(complaintId, staffId);
        
        if (success) {
            request.setAttribute("success", "Staff assigned successfully.");
        } else {
            request.setAttribute("error", "Failed to assign staff.");
        }
        
        response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
    }

    private void handleUpdateStatus(HttpServletRequest request, HttpServletResponse response,
                                    User user, int complaintId) throws Exception {
        
        if (!"admin".equals(user.getRole()) && !"staff".equals(user.getRole())) {
            request.setAttribute("error", "You don't have permission to update status.");
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            return;
        }
        
        String status = request.getParameter("status");
        String message = request.getParameter("message");
        
        // Get staff ID if user is staff
        int staffId = 0;
        if ("staff".equals(user.getRole())) {
            Staff staff = staffDAO.getStaffByUserId(user.getUser_id());
            if (staff != null) {
                staffId = staff.getStaff_id();
            }
        } else {
            staffId = Integer.parseInt(request.getParameter("staff_id"));
        }
        
        // Update complaint status
        boolean success = complaintDAO.updateComplaintStatus(complaintId, status, staffId);
        
        if (success && message != null && !message.trim().isEmpty()) {
            // Add response message
            complaintDAO.addComplaintResponse(complaintId, staffId, message);
        }
        
        if (success) {
            request.setAttribute("success", "Status updated successfully.");
        } else {
            request.setAttribute("error", "Failed to update status.");
        }
        
        response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
    }

    private void handleAddResponse(HttpServletRequest request, HttpServletResponse response,
                                   User user, int complaintId) throws Exception {
        
        String message = request.getParameter("message");
        
        if (message == null || message.trim().isEmpty()) {
            request.setAttribute("error", "Message cannot be empty.");
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            return;
        }
        
        // Get staff ID
        int staffId = 0;
        if ("admin".equals(user.getRole())) {
            staffId = Integer.parseInt(request.getParameter("staff_id"));
        } else if ("staff".equals(user.getRole())) {
            Staff staff = staffDAO.getStaffByUserId(user.getUser_id());
            if (staff != null) {
                staffId = staff.getStaff_id();
            }
        } else {
            request.setAttribute("error", "You don't have permission to add responses.");
            response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
            return;
        }
        
        // Add response
        boolean success = complaintDAO.addComplaintResponse(complaintId, staffId, message);
        
        if (success) {
            request.setAttribute("success", "Response added successfully.");
        } else {
            request.setAttribute("error", "Failed to add response.");
        }
        
        response.sendRedirect(request.getContextPath() + "/complaint-detail?complaint_id=" + complaintId);
    }
}