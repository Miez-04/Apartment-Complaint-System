package com.mycompany.controller;

import com.mycompany.dao.ApartmentUnitDAO;
import com.mycompany.dao.ComplaintCategoryDAO;
import com.mycompany.dao.ResidentDAO;
import com.mycompany.dao.StaffDAO;
import com.mycompany.dao.RoleDAO;
import com.mycompany.model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/profile")
public class ProfileController extends HttpServlet {

    private final ResidentDAO residentDAO = new ResidentDAO();
    private final StaffDAO staffDAO = new StaffDAO();
    private final ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();
    private final RoleDAO roleDAO = new RoleDAO();
    private final ComplaintCategoryDAO categoryDAO = new ComplaintCategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Object profile = null;
        List<ApartmentUnit> units = null;
        List<Role> roles = null;
        List<ComplaintCategory> categories = null;

        if ("resident".equals(user.getRole())) {
            profile = residentDAO.getResidentByUserId(user.getUser_id());
            units = unitDAO.getAllUnits();
        } else if ("staff".equals(user.getRole())) {
            profile = staffDAO.getStaffByUserId(user.getUser_id());
            roles = roleDAO.getAllRoles();
            categories = categoryDAO.getAllCategories();
        }

        request.setAttribute("user", user);
        request.setAttribute("profile", profile);
        request.setAttribute("units", units);
        request.setAttribute("roles", roles);
        request.setAttribute("categories", categories);

        request.getRequestDispatcher("/profile.jsp").forward(request, response);
    }
}
