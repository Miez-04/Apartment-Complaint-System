package com.mycompany.controller.admin;

import com.mycompany.dao.ResidentDAO;
import com.mycompany.dao.ApartmentUnitDAO;
import com.mycompany.model.User;
import com.mycompany.model.Resident;
import com.mycompany.model.ApartmentUnit;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@WebServlet("/admin/resident")
public class AdminResidentController extends HttpServlet {

    private ResidentDAO residentDAO = new ResidentDAO();
    private ApartmentUnitDAO unitDAO = new ApartmentUnitDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Check session and role
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // 2️⃣ Fetch resident list
            List<Resident> residentList = residentDAO.getAllResidents();
            request.setAttribute("residentList", residentList);

            // 3️⃣ Fetch unit list for dropdown
            List<ApartmentUnit> unitList = unitDAO.getAllUnits();
            request.setAttribute("unitList", unitList);
            
            // 4️⃣ Calculate statistics
            Map<String, Integer> stats = calculateResidentStatistics(residentList);
            request.setAttribute("totalResidents", stats.get("total"));
            request.setAttribute("blockA", stats.get("blockA"));
            request.setAttribute("blockB", stats.get("blockB"));
            request.setAttribute("blockC", stats.get("blockC"));

            // 5️⃣ Forward to JSP
            request.getRequestDispatcher("/admin/admin-resident.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Unable to load residents: " + e.getMessage());
            request.getRequestDispatcher("/admin/admin-resident.jsp").forward(request, response);
        }
    }

    private Map<String, Integer> calculateResidentStatistics(List<Resident> residents) {
        Map<String, Integer> stats = new HashMap<>();
        
        int total = residents.size();
        int blockA = 0;
        int blockB = 0;
        int blockC = 0;
        
        for (Resident r : residents) {
            if (r.getUnit() != null) {
                String block = r.getUnit().getBlock().toUpperCase();
                switch (block) {
                    case "A": blockA++; break;
                    case "B": blockB++; break;
                    case "C": blockC++; break;
                }
            }
        }
        
        stats.put("total", total);
        stats.put("blockA", blockA);
        stats.put("blockB", blockB);
        stats.put("blockC", blockC);
        
        return stats;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1️⃣ Check session and role
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        HttpSession session = request.getSession();
        
        try {
            // 2️⃣ DELETE resident
            String deleteId = request.getParameter("deleteId");
            if (deleteId != null && !deleteId.isEmpty()) {
                residentDAO.deleteResident(Integer.parseInt(deleteId));
                session.setAttribute("successMessage", "Resident deleted successfully!");
                response.sendRedirect(request.getContextPath() + "/admin/resident");
                return;
            }

            // 3️⃣ ADD or UPDATE resident
            String residentIdStr = request.getParameter("residentId"); // present if update
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String unitIdStr = request.getParameter("unitId");

            // Validate required fields
            if (username == null || username.trim().isEmpty() || 
                name == null || name.trim().isEmpty() ||
                unitIdStr == null || unitIdStr.trim().isEmpty()) {
                session.setAttribute("errorMessage", "Username, Name, and Unit are required fields!");
                response.sendRedirect(request.getContextPath() + "/admin/resident");
                return;
            }

            int unitId = Integer.parseInt(unitIdStr);

            if (residentIdStr == null || residentIdStr.isEmpty()) {
                // ADD new resident - password required
                if (password == null || password.trim().isEmpty()) {
                    session.setAttribute("errorMessage", "Password is required for new residents!");
                    response.sendRedirect(request.getContextPath() + "/admin/resident");
                    return;
                }
                residentDAO.addResident(username, password, name, phone, email, unitId);
                session.setAttribute("successMessage", "Resident added successfully!");
            } else {
                // UPDATE existing resident
                int residentId = Integer.parseInt(residentIdStr);
                residentDAO.updateResident(residentId, username, password, name, phone, email, unitId);
                session.setAttribute("successMessage", "Resident updated successfully!");
            }

            // 4️⃣ Redirect back to clean URL
            response.sendRedirect(request.getContextPath() + "/admin/resident");

        } catch (Exception e) {
            e.printStackTrace();
            // Check for specific errors
            String errorMsg = "Unable to save resident.";
            if (e.getMessage() != null) {
                if (e.getMessage().contains("Duplicate")) {
                    errorMsg = "Username already exists. Please choose another.";
                } else if (e.getMessage().contains("foreign key constraint")) {
                    errorMsg = "Cannot delete resident. They may have active complaints.";
                } else {
                    errorMsg = "Error: " + e.getMessage();
                }
            }
            session.setAttribute("errorMessage", errorMsg);
            response.sendRedirect(request.getContextPath() + "/admin/resident");
        }
    }
}