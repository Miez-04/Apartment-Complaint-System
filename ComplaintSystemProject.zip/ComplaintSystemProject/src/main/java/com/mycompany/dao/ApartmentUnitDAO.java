package com.mycompany.dao;

import com.mycompany.model.ApartmentUnit;
import com.mycompany.controller.DBConnect;
import java.sql.*;
import java.util.*;

public class ApartmentUnitDAO {
    
    // Get all units
    public List<ApartmentUnit> getAllUnits() {
        List<ApartmentUnit> units = new ArrayList<>();
        String sql = "SELECT * FROM apartmentunit ORDER BY block, floor, unit_number";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ApartmentUnit unit = new ApartmentUnit();
                unit.setUnit_id(rs.getInt("unit_id"));
                unit.setBlock(rs.getString("block"));
                unit.setFloor(rs.getInt("floor"));
                unit.setUnit_number(rs.getString("unit_number"));
                units.add(unit);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return units;
    }
    
    // Get statistics for dashboard
    public Map<String, Integer> getUnitStatistics() {
        Map<String, Integer> stats = new HashMap<>();
        
        try (Connection conn = DBConnect.getConnection()) {
            // Total units
            String totalSql = "SELECT COUNT(*) as total FROM apartmentunit";
            try (PreparedStatement ps = conn.prepareStatement(totalSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    stats.put("total", rs.getInt("total"));
                }
            }
            
            // Units by block
            String blockSql = "SELECT block, COUNT(*) as count FROM apartmentunit GROUP BY block";
            try (PreparedStatement ps = conn.prepareStatement(blockSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String block = rs.getString("block");
                    stats.put("block" + block, rs.getInt("count"));
                }
            }
            
            // Initialize all blocks with 0 if not present
            stats.putIfAbsent("blockA", 0);
            stats.putIfAbsent("blockB", 0);
            stats.putIfAbsent("blockC", 0);
            
        } catch (Exception e) {
            e.printStackTrace();
            // Return zeros on error
            stats.put("total", 0);
            stats.put("blockA", 0);
            stats.put("blockB", 0);
            stats.put("blockC", 0);
        }
        
        return stats;
    }
    
    // Get unit by ID
    public ApartmentUnit getUnitById(int unitId) {
        String sql = "SELECT * FROM apartmentunit WHERE unit_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, unitId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ApartmentUnit unit = new ApartmentUnit();
                    unit.setUnit_id(rs.getInt("unit_id"));
                    unit.setBlock(rs.getString("block"));
                    unit.setFloor(rs.getInt("floor"));
                    unit.setUnit_number(rs.getString("unit_number"));
                    return unit;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Check if unit exists (for duplicate checking)
    public boolean unitExists(String block, int floor, String unitNumber) {
        String sql = "SELECT COUNT(*) as count FROM apartmentunit WHERE block = ? AND floor = ? AND unit_number = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, block);
            ps.setInt(2, floor);
            ps.setString(3, unitNumber);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Check if unit exists (excluding current unit for update)
    public boolean unitExistsExcluding(String block, int floor, String unitNumber, int excludeUnitId) {
        String sql = "SELECT COUNT(*) as count FROM apartmentunit WHERE block = ? AND floor = ? AND unit_number = ? AND unit_id != ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, block);
            ps.setInt(2, floor);
            ps.setString(3, unitNumber);
            ps.setInt(4, excludeUnitId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Add new unit
    public boolean addUnit(ApartmentUnit unit) {
        // Check if unit already exists
        if (unitExists(unit.getBlock(), unit.getFloor(), unit.getUnit_number())) {
            return false; // Unit already exists
        }
        
        String sql = "INSERT INTO apartmentunit (block, floor, unit_number) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, unit.getBlock());
            ps.setInt(2, unit.getFloor());
            ps.setString(3, unit.getUnit_number());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Update unit
    public boolean updateUnit(ApartmentUnit unit) {
        // Check if unit already exists (excluding current unit)
        if (unitExistsExcluding(unit.getBlock(), unit.getFloor(), unit.getUnit_number(), unit.getUnit_id())) {
            return false; // Another unit with same details exists
        }
        
        String sql = "UPDATE apartmentunit SET block = ?, floor = ?, unit_number = ? WHERE unit_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, unit.getBlock());
            ps.setInt(2, unit.getFloor());
            ps.setString(3, unit.getUnit_number());
            ps.setInt(4, unit.getUnit_id());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Delete unit (only if not used)
    public boolean deleteUnit(int unitId) {
        // Check if unit is used by any resident
        String checkResidentSql = "SELECT COUNT(*) as count FROM resident WHERE unit_id = ?";
        String checkComplaintSql = "SELECT COUNT(*) as count FROM complaint WHERE unit_id = ?";
        String deleteSql = "DELETE FROM apartmentunit WHERE unit_id = ?";
        
        try (Connection conn = DBConnect.getConnection()) {
            // Check if unit has residents
            try (PreparedStatement ps = conn.prepareStatement(checkResidentSql)) {
                ps.setInt(1, unitId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt("count") > 0) {
                        return false; // Unit has residents, cannot delete
                    }
                }
            }
            
            // Check if unit has complaints
            try (PreparedStatement ps = conn.prepareStatement(checkComplaintSql)) {
                ps.setInt(1, unitId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt("count") > 0) {
                        return false; // Unit has complaints, cannot delete
                    }
                }
            }
            
            // Delete unit
            try (PreparedStatement ps = conn.prepareStatement(deleteSql)) {
                ps.setInt(1, unitId);
                return ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}