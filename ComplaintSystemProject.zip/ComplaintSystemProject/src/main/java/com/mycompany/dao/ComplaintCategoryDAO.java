package com.mycompany.dao;

import com.mycompany.model.ComplaintCategory;
import com.mycompany.controller.DBConnect;
import java.sql.*;
import java.util.*;

public class ComplaintCategoryDAO {
    
    // Get all categories
    public List<ComplaintCategory> getAllCategories() {
        List<ComplaintCategory> categories = new ArrayList<>();
        String sql = "SELECT * FROM complaintcategory ORDER BY category_name";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                ComplaintCategory category = new ComplaintCategory();
                category.setCategory_id(rs.getInt("category_id"));
                category.setCategory_name(rs.getString("category_name"));
                category.setDescription(rs.getString("description"));
                categories.add(category);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categories;
    }
    
    // Get category by ID
    public ComplaintCategory getCategoryById(int categoryId) {
        String sql = "SELECT * FROM complaintcategory WHERE category_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ComplaintCategory category = new ComplaintCategory();
                    category.setCategory_id(rs.getInt("category_id"));
                    category.setCategory_name(rs.getString("category_name"));
                    category.setDescription(rs.getString("description"));
                    return category;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Check if category exists
    public boolean categoryExists(String categoryName) {
        String sql = "SELECT COUNT(*) as count FROM complaintcategory WHERE category_name = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoryName);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Check if category exists excluding current category
    public boolean categoryExistsExcluding(String categoryName, int excludeCategoryId) {
        String sql = "SELECT COUNT(*) as count FROM complaintcategory WHERE category_name = ? AND category_id != ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoryName);
            ps.setInt(2, excludeCategoryId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Add new category
    public boolean addCategory(ComplaintCategory category) {
        if (categoryExists(category.getCategory_name())) {
            return false;
        }
        
        String sql = "INSERT INTO complaintcategory (category_name, description) VALUES (?, ?)";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, category.getCategory_name());
            ps.setString(2, category.getDescription());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Update category
    public boolean updateCategory(ComplaintCategory category) {
        String sql = "UPDATE complaintcategory SET category_name = ?, description = ? WHERE category_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, category.getCategory_name());
            ps.setString(2, category.getDescription());
            ps.setInt(3, category.getCategory_id());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Delete category
    public boolean deleteCategory(int categoryId) {
        String sql = "DELETE FROM complaintcategory WHERE category_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, categoryId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Get total category count
    public int getTotalCategories() {
        String sql = "SELECT COUNT(*) as total FROM complaintcategory";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}