package com.mycompany.dao;

import com.mycompany.controller.DBConnect;
import com.mycompany.model.Complaint;
import java.io.InputStream;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class ComplaintDAO {
    
    // In ComplaintDAO.java
    public boolean submitComplaint(int residentId, int unitId, int categoryId,
                                   String title, String description, InputStream imageData) {
        String sql = "INSERT INTO complaint (resident_id, unit_id, category_id, title, description, status, image_data) VALUES (?,?,?,?,?,?,?)";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, residentId);
            ps.setInt(2, unitId);
            ps.setInt(3, categoryId);
            ps.setString(4, title);
            ps.setString(5, description);
            ps.setString(6, "pending");

            if (imageData != null) {
                ps.setBinaryStream(7, imageData);
            } else {
                ps.setNull(7, java.sql.Types.BLOB);
            }

            return ps.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }



    public List<Map<String, Object>> getComplaintsByResidentWithFormattedDate(int residentId) throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> complaints = new ArrayList<>();

        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                     "cat.category_name " +
                     "FROM complaint c " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "WHERE c.resident_id = ? " +
                     "ORDER BY c.created_at DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, residentId);

            try (ResultSet rs = ps.executeQuery()) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");

                while (rs.next()) {
                    Map<String, Object> complaint = new HashMap<>();
                    complaint.put("complaint_id", rs.getInt("complaint_id"));
                    complaint.put("title", rs.getString("title"));
                    complaint.put("description", rs.getString("description"));
                    complaint.put("status", rs.getString("status"));
                    complaint.put("category_name", rs.getString("category_name"));

                    Timestamp createdAt = rs.getTimestamp("created_at");
                    complaint.put("created_at_formatted", createdAt != null ? sdf.format(createdAt) : "");
                    complaint.put("created_at_raw", createdAt);

                    complaints.add(complaint);
                }
            }
        }

        return complaints;
    }
    
    public List<Complaint> getResidentComplaints(int residentId) {
    List<Complaint> list = new ArrayList<>();
    String sql = "SELECT c.complaint_id, c.title, c.status, c.created_at, cat.category_name " +
                 "FROM complaint c " +
                 "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                 "WHERE c.resident_id = ? " +
                 "ORDER BY c.created_at DESC";

    try (Connection con = DBConnect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, residentId);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Complaint c = new Complaint();
                c.setComplaint_id(rs.getInt("complaint_id"));
                c.setTitle(rs.getString("title"));
                c.setStatus(rs.getString("status"));
                c.setCreated_at(rs.getTimestamp("created_at"));
                c.setCategoryName(rs.getString("category_name"));
                list.add(c);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

        return list;
    }

    
    // In ComplaintDAO.java
    public List<Complaint> getComplaintsByResident(int residentId) {
        List<Complaint> list = new ArrayList<>();
        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, "
                   + "cat.category_name "
                   + "FROM complaint c "
                   + "JOIN complaintcategory cat ON c.category_id = cat.category_id "
                   + "WHERE c.resident_id = ? "
                   + "ORDER BY c.created_at DESC";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, residentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Complaint c = new Complaint();
                    c.setComplaint_id(rs.getInt("complaint_id"));
                    c.setTitle(rs.getString("title"));
                    c.setDescription(rs.getString("description"));
                    c.setStatus(rs.getString("status"));
                    c.setCreated_at(rs.getTimestamp("created_at"));
                    c.setCategoryName(rs.getString("category_name"));
                    list.add(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
        public Map<String, Integer> getResidentComplaintStats(int residentId) {
        Map<String, Integer> stats = new HashMap<>();
        stats.put("total", 0);
        stats.put("pending", 0);
        stats.put("in_progress", 0);
        stats.put("resolved", 0);

        String sql = "SELECT status, COUNT(*) AS total FROM complaint WHERE resident_id = ? GROUP BY status";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, residentId);
            try (ResultSet rs = ps.executeQuery()) {
                int total = 0;
                while (rs.next()) {
                    String status = rs.getString("status");
                    int count = rs.getInt("total");
                    stats.put(status, count);
                    total += count;
                }
                stats.put("total", total);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stats;
    }



    
    // Fetch complaints assigned to a specific staff - UPDATED WITH NULL HANDLING
    public List<Complaint> getComplaintsByStaff(int staffId) throws SQLException, ClassNotFoundException {
        List<Complaint> complaints = new ArrayList<>();

        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                     "r.name AS resident_name, r.resident_id, c.unit_id, " +
                     "cat.category_name, cat.category_id " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "WHERE c.staff_id = ? " +
                     "ORDER BY c.created_at DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Complaint c = new Complaint();
                    c.setComplaint_id(rs.getInt("complaint_id"));
                    c.setTitle(rs.getString("title"));
                    c.setDescription(rs.getString("description"));
                    c.setStatus(rs.getString("status"));
                    c.setCreated_at(rs.getTimestamp("created_at"));

                    // Handle null values for resident_name
                    String residentName = rs.getString("resident_name");
                    c.setResidentName(residentName != null ? residentName : "Unknown Resident");

                    c.setResident_id(rs.getInt("resident_id"));
                    c.setUnit_id(rs.getInt("unit_id"));

                    String categoryName = rs.getString("category_name");
                    c.setCategoryName(categoryName != null ? categoryName : "Uncategorized");

                    c.setCategory_id(rs.getInt("category_id"));
                    complaints.add(c);
                }
            }
        }

        return complaints;
    }

    // Get complaint details with all information for staff
    public Complaint getComplaintDetailsForStaff(int complaintId, int staffId) throws SQLException, ClassNotFoundException {
        Complaint complaint = null;
        
        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, c.updated_at, " +
                     "c.image_data, r.name AS resident_name, r.phone AS resident_phone, " +
                     "r.email AS resident_email, r.resident_id, cat.category_name, " +
                     "CONCAT(a.block, ' - Floor ', a.floor, ' - Unit ', a.unit_number) as unit_address, " +
                     "s.name AS staff_name, s.phone AS staff_phone, role.role_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN apartmentunit a ON c.unit_id = a.unit_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                     "LEFT JOIN role ON s.role_id = role.role_id " +
                     "WHERE c.complaint_id = ? AND c.staff_id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, complaintId);
            ps.setInt(2, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    complaint = new Complaint();
                    complaint.setComplaint_id(rs.getInt("complaint_id"));
                    complaint.setTitle(rs.getString("title"));
                    complaint.setDescription(rs.getString("description"));
                    complaint.setStatus(rs.getString("status"));
                    complaint.setCreated_at(rs.getTimestamp("created_at"));
                    complaint.setUpdated_at(rs.getTimestamp("updated_at"));
                    complaint.setResidentName(rs.getString("resident_name"));
                    complaint.setCategoryName(rs.getString("category_name"));
                    complaint.setStaffName(rs.getString("staff_name") + " (" + rs.getString("role_name") + ")");
                    complaint.setImage_data(rs.getBinaryStream("image_data"));
                }
            }
        }

        return complaint;
    }

    // Get staff information with role_name
    public Map<String, String> getStaffInfo(int staffId) throws SQLException, ClassNotFoundException {
        Map<String, String> staffInfo = new HashMap<>();
        
        String sql = "SELECT s.name, s.phone, r.role_name, cat.category_name " +
                     "FROM staff s " +
                     "LEFT JOIN role r ON s.role_id = r.role_id " +
                     "LEFT JOIN complaintcategory cat ON s.category_id = cat.category_id " +
                     "WHERE s.staff_id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    staffInfo.put("name", rs.getString("name"));
                    staffInfo.put("phone", rs.getString("phone"));
                    staffInfo.put("role_name", rs.getString("role_name"));
                    staffInfo.put("category_name", rs.getString("category_name"));
                }
            }
        }

        return staffInfo;
    }

    // Update complaint status for staff
    public boolean updateComplaintStatus(int complaintId, String status, int staffId) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE complaint SET status = ?, updated_at = NOW() " +
                     "WHERE complaint_id = ? AND staff_id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, complaintId);
            ps.setInt(3, staffId);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    // Add response to complaint
    public boolean addComplaintResponse(int complaintId, int staffId, String message) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO complaintresponse (complaint_id, staff_id, message) VALUES (?, ?, ?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, complaintId);
            ps.setInt(2, staffId);
            ps.setString(3, message);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        }
    }

    // Get responses for a complaint
    public List<Map<String, Object>> getComplaintResponses(int complaintId) throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> responses = new ArrayList<>();

        String sql = "SELECT cr.response_id, cr.message, cr.response_time, " +
                     "s.name AS staff_name, r.role_name " +
                     "FROM complaintresponse cr " +
                     "JOIN staff s ON cr.staff_id = s.staff_id " +
                     "LEFT JOIN role r ON s.role_id = r.role_id " +
                     "WHERE cr.complaint_id = ? " +
                     "ORDER BY cr.response_time DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, complaintId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> response = new HashMap<>();
                    response.put("response_id", rs.getInt("response_id"));
                    response.put("message", rs.getString("message"));
                    response.put("response_time", rs.getTimestamp("response_time"));
                    response.put("staff_name", rs.getString("staff_name"));
                    response.put("role_name", rs.getString("role_name"));
                    responses.add(response);
                }
            }
        }

        return responses;
    }

    // Get statistics for staff dashboard - UPDATED FIX
    public Map<String, Integer> getStaffComplaintStats(int staffId) throws SQLException, ClassNotFoundException {
        Map<String, Integer> stats = new HashMap<>();

        // Initialize all statuses with 0
        stats.put("total", 0);
        stats.put("pending", 0);
        stats.put("in_progress", 0);
        stats.put("resolved", 0);
        stats.put("rejected", 0);

        String sql = "SELECT status, COUNT(*) as count " +
                     "FROM complaint " +
                     "WHERE staff_id = ? " +
                     "GROUP BY status";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                int total = 0;
                while (rs.next()) {
                    String status = rs.getString("status");
                    int count = rs.getInt("count");
                    stats.put(status, count);
                    total += count;
                }
                stats.put("total", total);
            }
        }

        return stats;
    }

    // Get recent complaints for staff
    public List<Complaint> getRecentStaffComplaints(int staffId, int limit) throws SQLException, ClassNotFoundException {
        List<Complaint> complaints = new ArrayList<>();

        String sql = "SELECT c.complaint_id, c.title, c.status, c.created_at, " +
                     "r.name AS resident_name, cat.category_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "WHERE c.staff_id = ? " +
                     "ORDER BY c.created_at DESC LIMIT ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffId);
            ps.setInt(2, limit);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Complaint c = new Complaint();
                    c.setComplaint_id(rs.getInt("complaint_id"));
                    c.setTitle(rs.getString("title"));
                    c.setStatus(rs.getString("status"));
                    c.setCreated_at(rs.getTimestamp("created_at"));
                    c.setResidentName(rs.getString("resident_name"));
                    c.setCategoryName(rs.getString("category_name"));
                    complaints.add(c);
                }
            }
        }

        return complaints;
    }

    // Get staff by user_id
    public Map<String, Object> getStaffByUserId(int userId) throws SQLException, ClassNotFoundException {
        Map<String, Object> staffData = new HashMap<>();
        
        String sql = "SELECT s.staff_id, s.name, s.phone, s.role_id, s.category_id, " +
                     "r.role_name, cat.category_name " +
                     "FROM staff s " +
                     "LEFT JOIN role r ON s.role_id = r.role_id " +
                     "LEFT JOIN complaintcategory cat ON s.category_id = cat.category_id " +
                     "WHERE s.user_id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    staffData.put("staff_id", rs.getInt("staff_id"));
                    staffData.put("name", rs.getString("name"));
                    staffData.put("phone", rs.getString("phone"));
                    staffData.put("role_id", rs.getInt("role_id"));
                    staffData.put("category_id", rs.getInt("category_id"));
                    staffData.put("role_name", rs.getString("role_name"));
                    staffData.put("category_name", rs.getString("category_name"));
                }
            }
        }

        return staffData;
    }

    // Get all staff with their roles
    public List<Map<String, Object>> getAllStaffWithRoles() throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> staffList = new ArrayList<>();

        String sql = "SELECT s.staff_id, s.name, s.phone, r.role_name, cat.category_name " +
                     "FROM staff s " +
                     "LEFT JOIN role r ON s.role_id = r.role_id " +
                     "LEFT JOIN complaintcategory cat ON s.category_id = cat.category_id " +
                     "ORDER BY s.name";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> staff = new HashMap<>();
                staff.put("staff_id", rs.getInt("staff_id"));
                staff.put("name", rs.getString("name"));
                staff.put("phone", rs.getString("phone"));
                staff.put("role_name", rs.getString("role_name"));
                staff.put("category_name", rs.getString("category_name"));
                staffList.add(staff);
            }
        }

        return staffList;
    }

    // Check if complaint is assigned to staff
    public boolean isComplaintAssignedToStaff(int complaintId, int staffId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM complaint WHERE complaint_id = ? AND staff_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, complaintId);
            ps.setInt(2, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        
        return false;
    }

    // Get staff role by staff_id
    public String getStaffRole(int staffId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT r.role_name FROM staff s " +
                     "JOIN role r ON s.role_id = r.role_id " +
                     "WHERE s.staff_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, staffId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("role_name");
                }
            }
        }
        
        return "Staff Member";
    }
    
    public String formatDate(Timestamp timestamp) {
        if (timestamp == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
        return sdf.format(new Date(timestamp.getTime()));
    }
    
    // In your getComplaintsByStaff method
    public List<Map<String, Object>> getComplaintsByStaffWithFormattedDate(int staffId) throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> complaints = new ArrayList<>();
        
        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                     "r.name AS resident_name, cat.category_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "WHERE c.staff_id = ? " +
                     "ORDER BY c.created_at DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, staffId);
            
            try (ResultSet rs = ps.executeQuery()) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
                
                while (rs.next()) {
                    Map<String, Object> complaint = new HashMap<>();
                    complaint.put("complaint_id", rs.getInt("complaint_id"));
                    complaint.put("title", rs.getString("title"));
                    complaint.put("status", rs.getString("status"));
                    complaint.put("resident_name", rs.getString("resident_name"));
                    complaint.put("category_name", rs.getString("category_name"));
                    
                    // Format the date
                    Timestamp createdAt = rs.getTimestamp("created_at");
                    if (createdAt != null) {
                        complaint.put("created_at_formatted", sdf.format(new Date(createdAt.getTime())));
                    } else {
                        complaint.put("created_at_formatted", "");
                    }
                    complaint.put("created_at_raw", createdAt);
                    
                    complaints.add(complaint);
                }
            }
        }
        
        return complaints;
    }

    
    // Get all complaints
    public List<Complaint> getAllComplaints() throws SQLException, ClassNotFoundException {
        List<Complaint> complaints = new ArrayList<>();

        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                     "r.name AS resident_name, c.unit_id, cat.category_name, s.name AS staff_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                     "ORDER BY c.created_at DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Complaint c = new Complaint();
                c.setComplaint_id(rs.getInt("complaint_id"));
                c.setTitle(rs.getString("title"));
                c.setDescription(rs.getString("description"));
                c.setStatus(rs.getString("status"));
                c.setCreated_at(rs.getTimestamp("created_at"));
                c.setResidentName(rs.getString("resident_name"));
                c.setUnit_id(rs.getInt("unit_id"));
                c.setCategoryName(rs.getString("category_name"));
                c.setStaffName(rs.getString("staff_name"));

                complaints.add(c);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return complaints;
    }

    // Update complaint
    public void updateComplaint(Complaint c) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE complaint SET title=?, description=?, status=?, updated_at=NOW() WHERE complaint_id=?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getTitle());
            ps.setString(2, c.getDescription());
            ps.setString(3, c.getStatus());
            ps.setInt(4, c.getComplaint_id());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Assign staff to complaint
    public boolean assignStaff(int complaintId, int staffId) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE complaint SET staff_id = ?, status = 'in_progress' WHERE complaint_id = ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, staffId);
            ps.setInt(2, complaintId);

            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated == 1; // Should update exactly 1 row

        } catch (SQLException e) {
            e.printStackTrace();
            throw e; // Re-throw or return false
        }
    }


    // Delete complaint
    public void deleteComplaint(int complaintId) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM complaint WHERE complaint_id=?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, complaintId);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get complaint by ID
    public Complaint getComplaintById(int complaintId) throws SQLException, ClassNotFoundException {
        Complaint c = null;
        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, " +
                     "c.resident_id, c.unit_id, c.category_id, c.staff_id, " +
                     "c.created_at, c.updated_at, c.image_data, " +
                     "r.name AS resident_name, cat.category_name, s.name AS staff_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                     "WHERE c.complaint_id = ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, complaintId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    c = new Complaint();
                    c.setComplaint_id(rs.getInt("complaint_id"));
                    c.setTitle(rs.getString("title"));
                    c.setDescription(rs.getString("description"));
                    c.setStatus(rs.getString("status"));
                    c.setResident_id(rs.getInt("resident_id"));
                    c.setUnit_id(rs.getInt("unit_id"));
                    c.setCategory_id(rs.getInt("category_id"));
                    c.setStaff_id(rs.getInt("staff_id"));
                    c.setResidentName(rs.getString("resident_name"));
                    c.setCategoryName(rs.getString("category_name"));
                    c.setStaffName(rs.getString("staff_name"));
                    c.setCreated_at(rs.getTimestamp("created_at"));
                    c.setUpdated_at(rs.getTimestamp("updated_at"));
                    c.setImage_data(rs.getBinaryStream("image_data"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return c;
    }
    
    // Count total complaints
    public int countTotalComplaints() {
        String sql = "SELECT COUNT(*) FROM complaint";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Count complaints by specific status
    public int countByStatusSingle(String status) {
        String sql = "SELECT COUNT(*) FROM complaint WHERE status = ?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Count complaints by status (for chart)
    public Map<String, Integer> countByStatus() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT status, COUNT(*) total FROM complaint GROUP BY status";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                map.put(rs.getString("status"), rs.getInt("total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    // Count complaints by category (for chart)
    public Map<String, Integer> countByCategory() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT cat.category_name, COUNT(*) total " +
                     "FROM complaint c " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "GROUP BY cat.category_name";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                map.put(rs.getString("category_name"), rs.getInt("total"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }
    
    public Map<String, Integer> getAdminComplaintStats() {
        Map<String, Integer> stats = new HashMap<>();

        String sql = "SELECT COUNT(*) as totalComplaints, " +
                     "SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingCount, " +
                     "SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as inProgressCount, " +
                     "SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolvedCount " +
                     "FROM complaint";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                stats.put("totalComplaints", rs.getInt("totalComplaints"));
                stats.put("pendingCount", rs.getInt("pendingCount"));
                stats.put("inProgressCount", rs.getInt("inProgressCount"));
                stats.put("resolvedCount", rs.getInt("resolvedCount"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stats;
    }

    public Map<String, Integer> getComplaintsByCategory() {
        Map<String, Integer> categoryData = new LinkedHashMap<>();
        String sql = "SELECT cat.category_name, COUNT(c.complaint_id) as count " +
                     "FROM complaint c " +
                     "RIGHT JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "GROUP BY cat.category_id, cat.category_name " +
                     "ORDER BY cat.category_id";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                categoryData.put(rs.getString("category_name"), rs.getInt("count"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categoryData;
    }

    public Map<String, Integer> getComplaintsByStatus() {
        Map<String, Integer> statusData = new LinkedHashMap<>();
        String sql = "SELECT status, COUNT(*) as count FROM complaint GROUP BY status";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                statusData.put(rs.getString("status"), rs.getInt("count"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return statusData;
    }

    public List<Complaint> getRecentComplaints(int limit) {
        List<Complaint> complaints = new ArrayList<>();
        String sql = "SELECT c.complaint_id, c.title, c.status, c.created_at, " +
                     "r.name AS resident_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "ORDER BY c.created_at DESC LIMIT ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Complaint c = new Complaint();
                c.setComplaint_id(rs.getInt("complaint_id"));
                c.setTitle(rs.getString("title"));
                c.setStatus(rs.getString("status"));
                c.setCreated_at(rs.getTimestamp("created_at"));
                c.setResidentName(rs.getString("resident_name"));
                complaints.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return complaints;
    }
    
    public List<Complaint> getAllComplaintsWithDetails() {
        List<Complaint> complaints = new ArrayList<>();

        String sql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                     "r.name AS resident_name, r.email, " +
                     "cat.category_name, " +
                     "au.block, au.floor, au.unit_number, " +
                     "s.name AS staff_name " +
                     "FROM complaint c " +
                     "JOIN resident r ON c.resident_id = r.resident_id " +
                     "JOIN complaintcategory cat ON c.category_id = cat.category_id " +
                     "JOIN apartmentunit au ON c.unit_id = au.unit_id " +
                     "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                     "ORDER BY c.created_at DESC";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Complaint c = new Complaint();
                c.setComplaint_id(rs.getInt("complaint_id"));
                c.setTitle(rs.getString("title"));
                c.setDescription(rs.getString("description"));
                c.setStatus(rs.getString("status"));
                c.setCreated_at(rs.getDate("created_at"));
                c.setResidentName(rs.getString("resident_name"));
                c.setCategoryName(rs.getString("category_name"));
                c.setStaffName(rs.getString("staff_name"));

                complaints.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error fetching complaints: " + e.getMessage(), e);
        }

        return complaints;
    }
    
     // Analytics/Report methods
    public Map<String, Object> getAnalyticsData() throws SQLException {
        Map<String, Object> analytics = new HashMap<>();
        
        try (Connection conn = DBConnect.getConnection()) {
            // 1. Get total complaints and status counts
            Map<String, Integer> statusCount = new HashMap<>();
            String statusSql = "SELECT status, COUNT(*) as count FROM complaint GROUP BY status";
            try (PreparedStatement ps = conn.prepareStatement(statusSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    statusCount.put(rs.getString("status"), rs.getInt("count"));
                }
            }
            analytics.put("statusCount", statusCount);
            
            // 2. Get category counts
            Map<String, Integer> categoryCount = new HashMap<>();
            String categorySql = "SELECT cc.category_name, COUNT(c.complaint_id) as count " +
                               "FROM complaint c " +
                               "JOIN complaintcategory cc ON c.category_id = cc.category_id " +
                               "GROUP BY cc.category_name ORDER BY count DESC";
            try (PreparedStatement ps = conn.prepareStatement(categorySql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    categoryCount.put(rs.getString("category_name"), rs.getInt("count"));
                }
            }
            analytics.put("categoryCount", categoryCount);
            
            // 3. Get monthly trend (last 6 months)
            Map<String, Integer> monthlyTrend = new LinkedHashMap<>();
            String trendSql = "SELECT DATE_FORMAT(created_at, '%b %Y') as month, COUNT(*) as count " +
                             "FROM complaint " +
                             "WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                             "GROUP BY DATE_FORMAT(created_at, '%Y-%m') " +
                             "ORDER BY created_at";
            try (PreparedStatement ps = conn.prepareStatement(trendSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    monthlyTrend.put(rs.getString("month"), rs.getInt("count"));
                }
            }
            analytics.put("monthlyTrend", monthlyTrend);
            
            // 4. Get staff performance
            Map<String, Integer> staffPerformance = new HashMap<>();
            String staffSql = "SELECT s.name, COUNT(c.complaint_id) as count " +
                             "FROM complaint c " +
                             "JOIN staff s ON c.staff_id = s.staff_id " +
                             "WHERE c.staff_id IS NOT NULL " +
                             "GROUP BY s.staff_id, s.name " +
                             "ORDER BY count DESC LIMIT 5";
            try (PreparedStatement ps = conn.prepareStatement(staffSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    staffPerformance.put(rs.getString("name"), rs.getInt("count"));
                }
            }
            analytics.put("staffPerformance", staffPerformance);
            
            // 5. Get detailed complaints list for reports
            List<Map<String, Object>> complaintsList = new ArrayList<>();
            String complaintsSql = "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
                                  "r.name as resident_name, cc.category_name, s.name as staff_name " +
                                  "FROM complaint c " +
                                  "LEFT JOIN resident r ON c.resident_id = r.resident_id " +
                                  "LEFT JOIN complaintcategory cc ON c.category_id = cc.category_id " +
                                  "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
                                  "ORDER BY c.created_at DESC LIMIT 50";
            try (PreparedStatement ps = conn.prepareStatement(complaintsSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> complaint = new HashMap<>();
                    complaint.put("complaint_id", rs.getInt("complaint_id"));
                    complaint.put("title", rs.getString("title"));
                    complaint.put("description", rs.getString("description"));
                    complaint.put("status", rs.getString("status"));
                    complaint.put("created_at", rs.getTimestamp("created_at"));
                    complaint.put("residentName", rs.getString("resident_name"));
                    complaint.put("categoryName", rs.getString("category_name"));
                    complaint.put("staffName", rs.getString("staff_name"));
                    complaintsList.add(complaint);
                }
            }
            analytics.put("complaints", complaintsList);
            
            // 6. Calculate summary statistics
            int totalComplaints = 0;
            int pendingCount = 0;
            int inProgressCount = 0;
            int resolvedCount = 0;
            int rejectedCount = 0;
            
            for (Map.Entry<String, Integer> entry : statusCount.entrySet()) {
                totalComplaints += entry.getValue();
                switch (entry.getKey().toLowerCase()) {
                    case "pending": pendingCount = entry.getValue(); break;
                    case "in_progress": inProgressCount = entry.getValue(); break;
                    case "resolved": resolvedCount = entry.getValue(); break;
                    case "rejected": rejectedCount = entry.getValue(); break;
                }
            }
            
            analytics.put("totalComplaints", totalComplaints);
            analytics.put("pendingCount", pendingCount);
            analytics.put("inProgressCount", inProgressCount);
            analytics.put("resolvedCount", resolvedCount);
            analytics.put("rejectedCount", rejectedCount);
            
            // 7. Get today's complaints
            String todaySql = "SELECT COUNT(*) as count FROM complaint WHERE DATE(created_at) = CURDATE()";
            try (PreparedStatement ps = conn.prepareStatement(todaySql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    analytics.put("todayComplaints", rs.getInt("count"));
                }
            }
            
            // 8. Get this week's complaints
            String weekSql = "SELECT COUNT(*) as count FROM complaint WHERE YEARWEEK(created_at) = YEARWEEK(CURDATE())";
            try (PreparedStatement ps = conn.prepareStatement(weekSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    analytics.put("thisWeekComplaints", rs.getInt("count"));
                }
            }
            
            // 9. Get this month's complaints
            String monthSql = "SELECT COUNT(*) as count FROM complaint WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
            try (PreparedStatement ps = conn.prepareStatement(monthSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    analytics.put("thisMonthComplaints", rs.getInt("count"));
                }
            }
            
            // 10. Find top category
            String topCategory = "N/A";
            int topCategoryCount = 0;
            for (Map.Entry<String, Integer> entry : categoryCount.entrySet()) {
                if (entry.getValue() > topCategoryCount) {
                    topCategoryCount = entry.getValue();
                    topCategory = entry.getKey();
                }
            }
            analytics.put("topCategory", topCategory);
            analytics.put("topCategoryCount", topCategoryCount);
            
            // 11. Find most active staff
            String mostActiveStaff = "N/A";
            int mostActiveStaffCount = 0;
            for (Map.Entry<String, Integer> entry : staffPerformance.entrySet()) {
                if (entry.getValue() > mostActiveStaffCount) {
                    mostActiveStaffCount = entry.getValue();
                    mostActiveStaff = entry.getKey();
                }
            }
            analytics.put("mostActiveStaff", mostActiveStaff);
            analytics.put("mostActiveStaffCount", mostActiveStaffCount);
            
        } catch (Exception e) {
            throw new SQLException("Error fetching analytics data", e);
        }
        
        return analytics;
    }
    
    // Get filtered complaints for report generation
    public List<Map<String, Object>> getFilteredComplaintsForReport(Date startDate, Date endDate, 
                                                                    String status, Integer categoryId) 
                                                                    throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> complaints = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
            "SELECT c.complaint_id, c.title, c.description, c.status, c.created_at, " +
            "r.name as resident_name, cc.category_name, s.name as staff_name " +
            "FROM complaint c " +
            "LEFT JOIN resident r ON c.resident_id = r.resident_id " +
            "LEFT JOIN complaintcategory cc ON c.category_id = cc.category_id " +
            "LEFT JOIN staff s ON c.staff_id = s.staff_id " +
            "WHERE 1=1"
        );

        List<Object> params = new ArrayList<>();

        if (startDate != null) {
            sql.append(" AND DATE(c.created_at) >= ?");
            params.add(new java.sql.Date(startDate.getTime()));
        }

        if (endDate != null) {
            sql.append(" AND DATE(c.created_at) <= ?");
            params.add(new java.sql.Date(endDate.getTime()));
        }

        if (status != null && !status.isEmpty()) {
            sql.append(" AND c.status = ?");
            params.add(status);
        }

        if (categoryId != null) {
            sql.append(" AND c.category_id = ?");
            params.add(categoryId);
        }

        sql.append(" ORDER BY c.created_at DESC");

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> complaint = new HashMap<>();
                    complaint.put("complaint_id", rs.getInt("complaint_id"));
                    complaint.put("title", rs.getString("title"));
                    complaint.put("description", rs.getString("description"));
                    complaint.put("status", rs.getString("status"));
                    complaint.put("created_at", rs.getTimestamp("created_at"));
                    complaint.put("resident_name", rs.getString("resident_name"));
                    complaint.put("category_name", rs.getString("category_name"));
                    complaint.put("staff_name", rs.getString("staff_name"));
                    complaints.add(complaint);
                }
            }
        }

        return complaints;
    }

    // Get categories for filter dropdown - Fixed version
    public List<Map<String, Object>> getAllCategories() {
        List<Map<String, Object>> categories = new ArrayList<>();

        try {
            String sql = "SELECT category_id, category_name FROM complaintcategory ORDER BY category_name";

            try (Connection conn = DBConnect.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Map<String, Object> category = new HashMap<>();
                    category.put("category_id", rs.getInt("category_id"));
                    category.put("category_name", rs.getString("category_name"));
                    categories.add(category);
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading categories: " + e.getMessage());
            e.printStackTrace();
            // Return empty list to prevent page from breaking
        }

        return categories;
    }

}
