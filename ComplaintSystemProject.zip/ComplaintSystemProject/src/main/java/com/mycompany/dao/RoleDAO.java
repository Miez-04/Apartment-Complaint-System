package com.mycompany.dao;

import com.mycompany.model.Role;
import com.mycompany.controller.DBConnect;
import java.sql.*;
import java.util.*;

public class RoleDAO {
    
    // Get all roles
    public List<Role> getAllRoles() {
        List<Role> roles = new ArrayList<>();
        String sql = "SELECT * FROM role ORDER BY role_name";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Role role = new Role();
                role.setRole_id(rs.getInt("role_id"));
                role.setRole_name(rs.getString("role_name"));
                role.setDescription(rs.getString("description"));
                roles.add(role);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return roles;
    }
    
    // Get role by ID
    public Role getRoleById(int roleId) {
        String sql = "SELECT * FROM role WHERE role_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roleId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Role role = new Role();
                    role.setRole_id(rs.getInt("role_id"));
                    role.setRole_name(rs.getString("role_name"));
                    role.setDescription(rs.getString("description"));
                    return role;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Check if role exists
    public boolean roleExists(String roleName) {
        String sql = "SELECT COUNT(*) as count FROM role WHERE role_name = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, roleName);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Check if role exists excluding current role
    public boolean roleExistsExcluding(String roleName, int excludeRoleId) {
        String sql = "SELECT COUNT(*) as count FROM role WHERE role_name = ? AND role_id != ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, roleName);
            ps.setInt(2, excludeRoleId);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("count") > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Add new role
    public boolean addRole(Role role) {
        if (roleExists(role.getRole_name())) {
            return false;
        }
        
        String sql = "INSERT INTO role (role_name, description) VALUES (?, ?)";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, role.getRole_name());
            ps.setString(2, role.getDescription());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Update role
    public boolean updateRole(Role role) {
        String sql = "UPDATE role SET role_name = ?, description = ? WHERE role_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, role.getRole_name());
            ps.setString(2, role.getDescription());
            ps.setInt(3, role.getRole_id());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Delete role
    public boolean deleteRole(int roleId) {
        String sql = "DELETE FROM role WHERE role_id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roleId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Get total role count
    public int getTotalRoles() {
        String sql = "SELECT COUNT(*) as total FROM role";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}