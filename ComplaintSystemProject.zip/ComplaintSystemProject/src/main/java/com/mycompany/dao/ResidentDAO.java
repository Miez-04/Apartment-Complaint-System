package com.mycompany.dao;

import com.mycompany.controller.DBConnect;
import com.mycompany.model.Resident;
import com.mycompany.model.User;
import com.mycompany.model.ApartmentUnit;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResidentDAO {

    // Get all residents with User and Unit info
    public List<Resident> getAllResidents() {
        List<Resident> list = new ArrayList<>();
        String sql = "SELECT r.resident_id, r.name, r.phone, r.email, r.unit_id, r.user_id, "
                   + "u.username, u.role, "
                   + "a.block, a.floor, a.unit_number "
                   + "FROM Resident r "
                   + "JOIN User u ON r.user_id = u.user_id "
                   + "JOIN ApartmentUnit a ON r.unit_id = a.unit_id";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Resident r = new Resident();
                r.setResident_id(rs.getInt("resident_id"));
                r.setName(rs.getString("name"));
                r.setPhone(rs.getString("phone"));
                r.setEmail(rs.getString("email"));
                r.setUnit_id(rs.getInt("unit_id"));
                r.setUser_id(rs.getInt("user_id"));

                // User
                User u = new User();
                u.setUser_id(rs.getInt("user_id"));
                u.setUsername(rs.getString("username"));
                u.setRole(rs.getString("role"));
                r.setUser(u);

                // Unit
                ApartmentUnit a = new ApartmentUnit();
                a.setUnit_id(rs.getInt("unit_id"));
                a.setBlock(rs.getString("block"));
                a.setFloor(rs.getInt("floor"));
                a.setUnit_number(rs.getString("unit_number"));
                r.setUnit(a);

                list.add(r);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Add resident (insert User + Resident)
    public void addResident(String username, String password, String name, String phone, String email, int unitId) {
        String insertUser = "INSERT INTO User (username, password, role) VALUES (?, ?, 'resident')";
        String insertResident = "INSERT INTO Resident (name, phone, email, unit_id, user_id) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnect.getConnection()) {
            // Insert User
            PreparedStatement psUser = con.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            psUser.setString(1, username);
            psUser.setString(2, password);
            psUser.executeUpdate();

            ResultSet rs = psUser.getGeneratedKeys();
            if (rs.next()) {
                int userId = rs.getInt(1);

                // Insert Resident
                PreparedStatement psResident = con.prepareStatement(insertResident);
                psResident.setString(1, name);
                psResident.setString(2, phone);
                psResident.setString(3, email);
                psResident.setInt(4, unitId);
                psResident.setInt(5, userId);
                psResident.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update resident info AND linked User info
public void updateResident(int residentId, String username, String password, String name, String phone, String email, int unitId) {
    StringBuilder sql = new StringBuilder(
        "UPDATE user u JOIN resident r ON u.user_id=r.user_id " +
        "SET u.username=?, r.name=?, r.phone=?, r.email=?, r.unit_id=?"
    );

    if(password != null && !password.isEmpty()){
        sql.append(", u.password=?");
    }
    sql.append(" WHERE r.resident_id=?");

    try(Connection conn = DBConnect.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql.toString())) {

        int index = 1;
        ps.setString(index++, username);   // username first
        ps.setString(index++, name);
        ps.setString(index++, phone);
        ps.setString(index++, email);
        ps.setInt(index++, unitId);

        if(password != null && !password.isEmpty()){
            ps.setString(index++, password); // only set password if not blank
        }

        ps.setInt(index++, residentId);

        ps.executeUpdate();
    } catch(Exception e){
        e.printStackTrace();
    }
}




    // Delete resident and corresponding User
    public void deleteResident(int residentId) {
        String getUserId = "SELECT user_id FROM Resident WHERE resident_id=?";
        String deleteResident = "DELETE FROM Resident WHERE resident_id=?";
        String deleteUser = "DELETE FROM User WHERE user_id=?";

        try (Connection con = DBConnect.getConnection()) {
            PreparedStatement ps1 = con.prepareStatement(getUserId);
            ps1.setInt(1, residentId);
            ResultSet rs = ps1.executeQuery();
            if (rs.next()) {
                int userId = rs.getInt("user_id");

                PreparedStatement ps2 = con.prepareStatement(deleteResident);
                ps2.setInt(1, residentId);
                ps2.executeUpdate();

                PreparedStatement ps3 = con.prepareStatement(deleteUser);
                ps3.setInt(1, userId);
                ps3.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // In ResidentDAO.java
    public Resident getResidentByUserId(int userId) {
        String sql = "SELECT r.resident_id, r.name, r.phone, r.email, r.unit_id, r.user_id, "
                   + "u.username, u.role, "
                   + "a.block, a.floor, a.unit_number "
                   + "FROM Resident r "
                   + "JOIN User u ON r.user_id = u.user_id "
                   + "JOIN ApartmentUnit a ON r.unit_id = a.unit_id "
                   + "WHERE r.user_id = ?";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Resident r = new Resident();
                    r.setResident_id(rs.getInt("resident_id"));
                    r.setName(rs.getString("name"));
                    r.setPhone(rs.getString("phone"));
                    r.setEmail(rs.getString("email"));
                    r.setUnit_id(rs.getInt("unit_id"));
                    r.setUser_id(rs.getInt("user_id"));

                    User u = new User();
                    u.setUser_id(rs.getInt("user_id"));
                    u.setUsername(rs.getString("username"));
                    u.setRole(rs.getString("role"));
                    r.setUser(u);

                    ApartmentUnit a = new ApartmentUnit();
                    a.setUnit_id(rs.getInt("unit_id"));
                    a.setBlock(rs.getString("block"));
                    a.setFloor(rs.getInt("floor"));
                    a.setUnit_number(rs.getString("unit_number"));
                    r.setUnit(a);

                    return r;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Resident getResidentById(int residentId) {
        String sql = "SELECT resident_id, name, phone, email, unit_id, user_id FROM resident WHERE resident_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, residentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Resident resident = new Resident();
                    resident.setResident_id(rs.getInt("resident_id"));
                    resident.setName(rs.getString("name"));
                    resident.setPhone(rs.getString("phone"));
                    resident.setEmail(rs.getString("email"));
                    resident.setUnit_id(rs.getInt("unit_id"));
                    resident.setUser_id(rs.getInt("user_id"));
                    return resident;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getTotalResidentCount() {
        String sql = "SELECT COUNT(*) as count FROM resident";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
}
