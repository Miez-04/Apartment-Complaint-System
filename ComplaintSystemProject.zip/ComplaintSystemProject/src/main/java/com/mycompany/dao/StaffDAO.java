package com.mycompany.dao;

import com.mycompany.controller.DBConnect;
import com.mycompany.model.ComplaintCategory;
import com.mycompany.model.Role;
import com.mycompany.model.Staff;
import com.mycompany.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StaffDAO {

    // ==============================
    // GET ALL STAFF
    // ==============================
   public List<Staff> getAllStaff() {
    List<Staff> list = new ArrayList<>();
    
    String sql = "SELECT s.staff_id, s.name, s.phone, s.role_id, s.category_id, "
               + "r.role_name, "
               + "u.user_id, u.username, "
               + "c.category_name "
               + "FROM staff s "
               + "JOIN user u ON s.user_id = u.user_id "
               + "JOIN role r ON s.role_id = r.role_id "
               + "LEFT JOIN complaintcategory c ON s.category_id = c.category_id "
               + "WHERE u.role = 'staff'";

    try (Connection con = DBConnect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Staff s = new Staff();
            s.setStaff_id(rs.getInt("staff_id"));
            s.setName(rs.getString("name"));
            s.setPhone(rs.getString("phone"));
            s.setRole_id(rs.getInt("role_id"));
            s.setCategory_id(rs.getInt("category_id"));

            // Role
            Role role = new Role();
            role.setRole_id(rs.getInt("role_id"));
            String roleName = rs.getString("role_name");
            role.setRole_name(roleName);
            s.setRole(role);
            
            
            // User
            User u = new User();
            u.setUser_id(rs.getInt("user_id"));
            u.setUsername(rs.getString("username"));
            s.setUser(u);

            // Category
            ComplaintCategory cat = new ComplaintCategory();
            cat.setCategory_id(rs.getInt("category_id"));
            cat.setCategory_name(rs.getString("category_name"));
            s.setCategory(cat);

            list.add(s);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
   
   public Staff getStaffByUserId(int userId) {
    String sql = "SELECT s.staff_id, s.name, s.phone, s.role_id, s.category_id, "
               + "r.role_name, u.user_id, u.username, c.category_name "
               + "FROM staff s "
               + "JOIN user u ON s.user_id = u.user_id "
               + "JOIN role r ON s.role_id = r.role_id "
               + "LEFT JOIN complaintcategory c ON s.category_id = c.category_id "
               + "WHERE u.user_id = ?";

    try (Connection con = DBConnect.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                Staff s = new Staff();
                s.setStaff_id(rs.getInt("staff_id"));
                s.setName(rs.getString("name"));
                s.setPhone(rs.getString("phone"));

                Role role = new Role();
                role.setRole_id(rs.getInt("role_id"));
                role.setRole_name(rs.getString("role_name"));
                s.setRole(role);

                User u = new User();
                u.setUser_id(rs.getInt("user_id"));
                u.setUsername(rs.getString("username"));
                s.setUser(u);

                ComplaintCategory cat = new ComplaintCategory();
                cat.setCategory_id(rs.getInt("category_id"));
                cat.setCategory_name(rs.getString("category_name"));
                s.setCategory(cat);

                return s;
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}



    // ==============================
    // ADD STAFF
    // ==============================
    public void addStaff(String username, String password, String name, String phone, int roleId, Integer categoryId) {
    String insertUser = "INSERT INTO user (username, password, role) VALUES (?, ?, 'staff')";
    String insertStaff = "INSERT INTO staff (user_id, name, phone, role_id, category_id) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = DBConnect.getConnection()) {
        conn.setAutoCommit(false);

        // 1. Insert into user table
        int userId = 0;
        try (PreparedStatement psUser = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS)) {
            psUser.setString(1, username);
            psUser.setString(2, password);
            psUser.executeUpdate();

            try (ResultSet rs = psUser.getGeneratedKeys()) {
                if (rs.next()) {
                    userId = rs.getInt(1);
                } else {
                    throw new SQLException("Failed to retrieve generated user ID.");
                }
            }
        }

        // 2. Insert into staff table
        try (PreparedStatement psStaff = conn.prepareStatement(insertStaff)) {
            psStaff.setInt(1, userId);
            psStaff.setString(2, name);
            psStaff.setString(3, phone);
            psStaff.setInt(4, roleId);

            if (categoryId != null) {
                psStaff.setInt(5, categoryId);
            } else {
                psStaff.setNull(5, java.sql.Types.INTEGER);
            }

            psStaff.executeUpdate();
        }

        conn.commit();

    } catch (Exception e) {
        e.printStackTrace();
        try {
            if (!DBConnect.getConnection().getAutoCommit()) {
                DBConnect.getConnection().rollback();
            }
        } catch (Exception rollbackEx) {
            rollbackEx.printStackTrace();
        }
    }
}

    // ==============================
    // UPDATE STAFF
    // ==============================
    public void updateStaff(int staffId, String username, String password, String name, String phone, int roleId, Integer categoryId) {
    String getUserId = "SELECT user_id FROM staff WHERE staff_id = ?";
    String updateStaff = "UPDATE staff SET name = ?, phone = ?, role_id = ?, category_id = ? WHERE staff_id = ?";
    String updateUserBase = "UPDATE user SET username = ?";
    String updateUserWhere = " WHERE user_id = ?";

    try (Connection con = DBConnect.getConnection()) {

        int userId = 0;
        // 1. Get user_id linked to staff
        try (PreparedStatement ps1 = con.prepareStatement(getUserId)) {
            ps1.setInt(1, staffId);
            try (ResultSet rs = ps1.executeQuery()) {
                if (rs.next()) userId = rs.getInt("user_id");
            }
        }

        // 2. Update staff table
        try (PreparedStatement ps2 = con.prepareStatement(updateStaff)) {
            ps2.setString(1, name);
            ps2.setString(2, phone);
            ps2.setInt(3, roleId);
            if (categoryId != null) ps2.setInt(4, categoryId);
            else ps2.setNull(4, java.sql.Types.INTEGER);
            ps2.setInt(5, staffId);
            ps2.executeUpdate();
        }

        // 3. Update user table
        String sqlUser = updateUserBase;
        if (password != null && !password.isEmpty()) {
            sqlUser += ", password = ?";
        }
        sqlUser += updateUserWhere;

        try (PreparedStatement ps3 = con.prepareStatement(sqlUser)) {
            int index = 1;
            ps3.setString(index++, username);
            if (password != null && !password.isEmpty()) {
                ps3.setString(index++, password);
            }
            ps3.setInt(index++, userId); // user_id is always last
            ps3.executeUpdate();
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}

    // ==============================
    // DELETE STAFF
    // ==============================
    public void deleteStaff(int staffId) {

        String getUserId = "SELECT user_id FROM staff WHERE staff_id=?";
        String deleteStaff = "DELETE FROM staff WHERE staff_id=?";
        String deleteUser = "DELETE FROM user WHERE user_id=?";

        try (Connection con = DBConnect.getConnection()) {

            PreparedStatement ps1 = con.prepareStatement(getUserId);
            ps1.setInt(1, staffId);
            ResultSet rs = ps1.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("user_id");

                PreparedStatement ps2 = con.prepareStatement(deleteStaff);
                ps2.setInt(1, staffId);
                ps2.executeUpdate();

                PreparedStatement ps3 = con.prepareStatement(deleteUser);
                ps3.setInt(1, userId);
                ps3.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // ==============================
    // GET ROLE ID BY NAME
    // ==============================
    public int getRoleIdByName(String roleName) {
        String sql = "SELECT role_id FROM role WHERE role_name = ?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, roleName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("role_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0; // default if not found
    }

    // ==============================
    // GET CATEGORY ID BY NAME
    // ==============================
    public int getCategoryIdByName(String categoryName) {
        String sql = "SELECT category_id FROM complaintcategory WHERE category_name = ?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, categoryName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("category_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0; // default if not found
    }

    
    public Staff getStaffById(int staffId) {
        String sql = "SELECT staff_id, name, phone, role_id, category_id, user_id FROM staff WHERE staff_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Staff staff = new Staff();
                    staff.setStaff_id(rs.getInt("staff_id"));
                    staff.setName(rs.getString("name"));
                    staff.setPhone(rs.getString("phone"));
                    staff.setRole_id(rs.getInt("role_id"));
                    staff.setCategory_id(rs.getInt("category_id"));
                    staff.setUser_id(rs.getInt("user_id"));
                    return staff;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Staff> getStaffByCategoryId(int categoryId) {
        List<Staff> staffList = new ArrayList<>();
        String sql = "SELECT staff_id, name FROM staff WHERE category_id = ? ORDER BY name";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Staff staff = new Staff();
                    staff.setStaff_id(rs.getInt("staff_id"));
                    staff.setName(rs.getString("name"));
                    staffList.add(staff);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return staffList;
    }

    public int getTotalStaffCount() {
        String sql = "SELECT COUNT(*) as count FROM staff";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Add to your existing StaffDAO class

    public Map<String, Integer> getStaffCountByRole() {
        Map<String, Integer> stats = new HashMap<>();

        // Initialize all roles with 0
        stats.put("plumber", 0);
        stats.put("electrician", 0);
        stats.put("cleaner", 0);
        stats.put("security", 0);
        stats.put("maintenance", 0);

        String sql = "SELECT LOWER(r.role_name) as role_name, COUNT(s.staff_id) as count " +
                     "FROM staff s " +
                     "JOIN role r ON s.role_id = r.role_id " +
                     "GROUP BY r.role_name";

        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String roleName = rs.getString("role_name");
                int count = rs.getInt("count");

                // Map database role names to our stat keys
                if (roleName.contains("plumb")) {
                    stats.put("plumber", count);
                } else if (roleName.contains("electric")) {
                    stats.put("electrician", count);
                } else if (roleName.contains("clean")) {
                    stats.put("cleaner", count);
                } else if (roleName.contains("security") || roleName.contains("guard")) {
                    stats.put("security", count);
                } else if (roleName.contains("maintenance")) {
                    stats.put("maintenance", count);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return stats;
    }
    
    // ==============================
    // GET STAFF ID BY USER ID
    // ==============================
    public Integer getStaffIdByUserId(int userId) {
        String sql = "SELECT staff_id FROM staff WHERE user_id = ?";
        try (Connection con = DBConnect.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("staff_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
