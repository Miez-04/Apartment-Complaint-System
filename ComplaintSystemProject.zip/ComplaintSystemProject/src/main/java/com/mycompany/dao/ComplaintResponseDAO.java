package com.mycompany.dao;

import com.mycompany.controller.DBConnect;
import com.mycompany.model.ComplaintResponse;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ComplaintResponseDAO {

    public boolean addResponseAndResolve(ComplaintResponse response) {
        String insertSql = "INSERT INTO complaintresponse (complaint_id, staff_id, message, response_time) VALUES (?, ?, ?, NOW())";
        String updateStatusSql = "UPDATE complaint SET status='resolved' WHERE complaint_id=?";

        try (Connection conn = DBConnect.getConnection()) {
            conn.setAutoCommit(false); // start transaction

            try (PreparedStatement psInsert = conn.prepareStatement(insertSql);
                 PreparedStatement psUpdate = conn.prepareStatement(updateStatusSql)) {

                // Insert response
                psInsert.setInt(1, response.getComplaint_id());
                psInsert.setInt(2, response.getStaff_id());
                psInsert.setString(3, response.getMessage());
                int inserted = psInsert.executeUpdate();

                if(inserted > 0) {
                    // Update complaint status to resolved
                    psUpdate.setInt(1, response.getComplaint_id());
                    psUpdate.executeUpdate();
                }

                conn.commit(); // commit transaction
                return inserted > 0;

            } catch (Exception e) {
                conn.rollback(); // rollback if error occurs
                e.printStackTrace();
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
